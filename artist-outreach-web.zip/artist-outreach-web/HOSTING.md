# Where to host Artist Outreach web

*Researched on 8 October 2026, plans added on 12 October 2026. Prices change:
check the links before signing up.*

## The short answer

| Piece | Recommendation | Cost to start |
|---|---|---|
| Server (Node + Chromium) | **Railway** (Hobby plan) with the `Dockerfile` | ~$15-30/month depending on use |
| Database | **Neon** (you already use it in producer-radar) | €0 (Free plan) |
| Users / sign-in | **Already built** (our own Google OAuth) | €0 |
| Subscriptions | **Stripe** Checkout + Billing (see the Managed Payments trade-off below) | a % per charge, no fixed fee |
| Domain | whichever you like | ~€10-15/year |

Fixed total to start: **~$20-30/month** plus each sale's fees.

## Why

### The server can't go on Vercel

The engine needs a **process that stays up**: a Chromium kept open with the
Spotify session, searches that stream for minutes (SSE) and in-memory state
between requests. Vercel is serverless (functions born and killed per request),
so the engine doesn't fit there. Vercel would only make sense for a separate
marketing landing page.

### Railway vs Fly.io vs Render

| | Railway | Fly.io | Render |
|---|---|---|---|
| Model | actual usage per second | machine per second | fixed price per instance |
| 2 GB RAM | ~$10/GB-month of RAM used + ~$20/vCPU-month of CPU used | shared-cpu-8x 2 GB: $17.55/month · performance-1x 2 GB: $33/month | 1 CPU / 2 GB: $25/month |
| Minimum plan | Hobby: $5/month minimum (includes $5 of usage) | no plan, no free allowance | Hobby workspace $0 |
| Difficulty | the easiest: connect GitHub and it deploys the Dockerfile | CLI + `fly.toml` | easy |

**Railway** because it's the simplest to run and bills what it really uses
(Chromium at rest uses little). At 1-1.5 GB on average and low CPU you should
stay at $15-30/month. If usage ever spikes and you want a fixed price, the same
`Dockerfile` runs on Render or Fly without code changes.

A VPS (Hetzner and the like) is cheaper on paper, but the system, certificates,
backups and deploys become your job. Not worth the time right now.

### Database: Neon

Free: 100 CU-hours per project, autoscales up to 2 CU, suspends after 5 min
idle, no card. When it grows, Launch: $0.106/CU-hour and $0.35/GB-month, no
monthly minimum. Alternative: Railway's own Postgres (everything in one panel,
pay per use).

### Sign-in: already built, no provider

Clerk, Auth0 or Supabase Auth would handle sign-in, but they add another
provider, another bill and another place your users live. Google sign-in is
already implemented and tested (OAuth with PKCE, sessions in your database,
secure cookies). With the basic scopes (email and profile) Google doesn't
require the security review for sensitive scopes; you only fill in the consent
screen (name, logo, link to the privacy policy — the app serves `/privacy` and
`/terms`).

## Subscriptions: Stripe

### The plans

| | Monthly | Yearly (20% off) | Automated DMs |
|---|---|---|---|
| Starter | €7 | €67.20 | 10 a day |
| Pro | €17 | €163.20 | unlimited |

Monthly plans carry a **12-month minimum commitment**. How it works and its
limits are below, under *Risks*.

`scripts/stripe-setup.js` creates everything in Stripe (products, prices with
lookup keys, a Customer Portal configuration without cancellation, the
webhook). See the README.

### Taxes: Managed Payments or do it yourself

The real problem when selling software worldwide from Spain isn't charging,
it's **VAT in every country** (OSS in the EU, sales tax in the US, etc.). There
are two ways to get rid of it: a *merchant of record* (MoR) that sells in your
name and files the taxes, or doing it yourself.

| Option | Fees | Taxes |
|---|---|---|
| Stripe + **Managed Payments** | EU cards 1.5% + €0.25 (international 3.15% + €0.25, +2% with currency conversion) + Billing 0.7% + **3.5%** | Stripe is the MoR: calculates, collects and files in 80+ countries |
| Stripe without Managed Payments | the same without the 3.5% (+ Stripe Tax 0.5% if you use it) | you file them (OSS, etc.) |
| Paddle | 5% + $0.50 | Paddle is the MoR |
| Lemon Squeezy | 5% + $0.50 | MoR, but see below |

What a charge costs with a European card (VAT handling aside):

| Charge | With Managed Payments | Without |
|---|---|---|
| Starter €7/month | ~€0.65 (9.3%) | ~€0.40 (5.8%) |
| Pro €17/month | ~€1.22 (7.2%) | ~€0.62 (3.7%) |
| Starter €67.20/year | ~€4.08 (6.1%) | ~€1.73 (2.6%) |
| Pro €163.20/year | ~€9.55 (5.9%) | ~€3.84 (2.4%) |

The fixed €0.25 per charge weighs most on the €7 plan; yearly plans lose much
less to fees.

**The trade-off that matters here:** with Managed Payments on, customers see the
charge as `LINK.COM* …` and can also manage — and **cancel** — their
subscription from link.com, outside the app. The app's cancel button and the
portal configuration respect the 12-month commitment; link.com doesn't know about
it. So:

- If the commitment matters to you, keep `STRIPE_MANAGED_PAYMENTS=0` and handle
  VAT yourself (Stripe Tax + OSS filing, ideally with an accountant).
- If you'd rather not deal with VAT, turn Managed Payments on and accept that
  the commitment can be skipped there.

The code supports both; it's one environment variable. Lemon Squeezy (where the
desktop store is, pending KYC) belongs to Stripe since 2024, and Stripe presents
Managed Payments — built by the same team — as its migration path; starting the
web subscriptions there would mean building on something that's going to move.
Keep it only for existing desktop licences.

The Stripe account has to be in the name of whoever signs the KYC (the company
or its owner).

## Risks (read before launching)

1. **The 12-month commitment on monthly plans.**
   - *What the app enforces:* cancelling inside the first 12 months schedules the
     end for the end of month 12 and keeps billing until then; the Customer
     Portal can't cancel or switch plans; the commitment is shown on the plans
     page, in Checkout and in the terms.
   - *What it can't enforce:* a card that stops working (expired, blocked, a
     chargeback). Stripe retries, then the subscription becomes unpaid/canceled
     and access stops. Collecting the rest is a debt-collection matter, not a
     software one. With Managed Payments, cancellation from link.com (above).
   - *Consumer law:* if you sell to consumers (not only to businesses), EU and
     Spanish consumer rules are strict about clauses that make it hard to end a
     contract, and minimum terms are usually only accepted when they're clearly
     disclosed and tied to a benefit (for example a cheaper price than a
     no-commitment option). Here the only monthly option is the committed one.
     There's also the 14-day withdrawal right for online purchases. **Have a
     lawyer review the plans and the terms before launching.** A common, safer
     alternative is: monthly without commitment at a higher price, or
     "commitment = yearly plan".
2. **Spotify, now from a single IP.** The engine uses the Spotify web player's
   internal GraphQL, not its public API, which goes against their terms. On the
   desktop each user queried from home; on the web **every search from every
   user comes out of the server**. If Spotify throttles or blocks that IP, the
   whole product goes down at once. What to do: watch `/healthz` and the logs,
   have `BROWSER_PROXY` (a residential proxy) ready and, as the next technical
   step, cache artist pages in the database so two users with similar
   references don't repeat lookups.
3. **Instagram blocks datacenters.** From Railway, follower lookups will often
   fail. That's why verification can also go through the extension, with the
   user's own Instagram session. That uses their account (few lookups, with
   pauses): say so on the extension's page.
4. **Chrome Web Store.** The extension uses the `debugger` permission and
   automates sending Instagram DMs, which Meta's terms forbid. Expect a tough
   review and the possibility of rejection or removal. For now users install it
   from the app's download ("Load unpacked"); if you publish it, an *unlisted*
   listing is the cautious first step. Remove the localhost permission of the
   CRM's local bridge before submitting.
5. **Instagram accounts.** Automated sending can get the user's Instagram
   account limited or suspended. The terms say so; the 10/day Starter cap helps,
   unlimited Pro makes it more likely.
6. **GDPR.** You store users' emails and lists of artists (names, Instagram
   handles): personal data even if public. `/privacy` and `/terms` are
   templates filled from `LEGAL_*` — have them reviewed, and list your
   processors (Railway, Neon, Stripe, Google).
7. **A single replica.** Search state and the Chromium live in the process's
   memory. Scale by adding RAM/CPU, not replicas. With dozens of simultaneous
   searches the engine will need splitting into workers; not before.

## Sources

- [Railway — Pricing](https://railway.com/pricing)
- [Fly.io — Pricing](https://fly.io/pricing.md)
- [Render — Pricing](https://render.com/pricing)
- [Neon — Pricing](https://neon.com/pricing)
- [Stripe — Pricing (Spain)](https://stripe.com/es/pricing)
- [Stripe — Managed Payments](https://stripe.com/managed-payments)
- [Stripe Docs — Managed Payments: eligibility (countries, products)](https://docs.stripe.com/payments/managed-payments/eligibility)
- [Stripe Docs — Managed Payments: how it works](https://docs.stripe.com/payments/managed-payments/how-it-works)
- [Stripe Docs — Managed Payments: Checkout integration](https://docs.stripe.com/payments/managed-payments/set-up)
- [Paddle — Pricing](https://www.paddle.com/pricing)
- [Merchant of Record in 2026: Stripe, Paddle, Polar, and the Lemon Squeezy question (alexcloudstar.com)](https://alexcloudstar.com/blog/merchant-of-record-indie-saas-2026/)
