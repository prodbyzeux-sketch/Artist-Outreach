# Artist Outreach — web platform

The desktop app turned into a web platform: **Google sign-in, one account per
user, two Stripe plans, and the Instagram extension built into the app**.

The discovery engine is the one from `artist-outreach-v3.0.0` (v4.2.0): Spotify
bootstrap, BFS over related artists, Instagram verification, vote-based
affinity, saved pools. The Finder UI is the same (`public/app.js`). Around it:

- **Discover** — the Finder.
- **Outreach** — the extension's sending page, embedded in the app.
- **Inbox** — the extension's Instagram CRM, embedded in the app.
- **Plan & billing** — Starter / Pro, monthly or yearly, through Stripe.

```
artist-outreach-web/
├── server/
│   ├── index.js            ← routes, pages, security headers, graceful shutdown
│   ├── config.js           ← every environment variable (see .env.example)
│   ├── db/                 ← Postgres (or PGlite locally) + schema.sql
│   ├── auth/               ← Google sign-in (OAuth + PKCE), sessions, access
│   ├── billing/
│   │   ├── plans.js        ← the plan catalog: prices, limits, Stripe lookup keys
│   │   └── stripe.js       ← Checkout, cancel/resume/upgrade, portal, webhook
│   ├── ext/                ← the extension's API (/ext/v1/*) + the daily DM quota
│   ├── extensionPack.js    ← builds the extension zip for this domain
│   ├── engine/             ← the desktop server.js, now multi-user
│   └── lib/                ← the engine's pure modules
├── public/                 ← the Finder UI + platform.js (nav, extension, account),
│                             sign-in, plan & billing, terms, privacy
├── extension/              ← the Chrome extension (outreach + inbox + platform/)
├── scripts/stripe-setup.js ← creates the Stripe products, prices, portal and webhook
├── test/                   ← server tests (incl. a full simulated crawl and billing)
├── Dockerfile, railway.json, .env.example
├── HOSTING.md              ← where to host it, what it costs, risks
└── README.md
```

## Plans

| | Monthly | Yearly (20% off) | Automated DMs |
|---|---|---|---|
| **Starter** | €7 / month | €67.20 / year (instead of €84) | 10 a day |
| **Pro** | €17 / month | €163.20 / year (instead of €204) | unlimited |

- **Monthly plans have a 12-month minimum commitment.** They bill every month;
  cancelling before the 12th payment schedules the end of the subscription for
  the end of month 12 (Stripe `cancel_at`). After that, cancelling ends it at
  the end of the paid month. The commitment is stated on the plans page, in
  Stripe Checkout (custom text above the pay button) and in the terms.
- **Yearly plans** are paid up front; cancelling stops the next renewal.
- **Starter → Pro** is an upgrade in place (prorated, same interval, same
  commitment date). Downgrades aren't offered.
- **"Automated DMs"** are the messages the extension sends during a run (first
  messages and follow-ups). The allowance resets at midnight in the user's time
  zone and is enforced by the server: the extension claims one before each send
  and gives it back if the send doesn't happen.
- Everything else (discovery, Instagram verification, saved lists, export,
  Inbox) is the same on both plans.
- Admins (`ADMIN_EMAILS`) and servers without Stripe get Pro for free.

Prices live in one place, `server/billing/plans.js`. Changing a price means
changing it there and re-running `scripts/stripe-setup.js` (it moves the lookup
key to a new Stripe price; existing subscribers keep their old price).

The Stripe Customer Portal is configured **without** cancellation or plan
switching (those go through the app, so the commitment holds); it's for the
card, invoices and billing details.

## Try it on your Mac (5 minutes)

```bash
cd artist-outreach-web
npm install
npm run browsers            # downloads Chromium for Playwright (~150 MB), once
cp .env.example .env        # DEV_LOGIN=1 is already set
npm run dev
```

Open <http://localhost:3456> → *Sign in (development mode)* with any email.
Without `DATABASE_URL` it uses a local database (PGlite in `data/`), without
Stripe everyone has full access, and without Google only the development
sign-in works.

To try the extension locally: **Outreach** tab → *Download the extension*,
unzip, `chrome://extensions` → Developer mode → *Load unpacked*.

Tests: `npm test` (server), `npm run test:ext` (extension, fast) and
`npm run test:ext:browser` (extension, live headless Chrome, a few minutes).

## Deploy (Railway + Neon + Stripe)

Recommendations and prices in [HOSTING.md](HOSTING.md). Steps:

1. **Repo**: push `artist-outreach-web/` to a private GitHub repo.
2. **Database**: create a Neon project and copy the connection string
   (`postgres://…?sslmode=require`). Tables are created on start.
3. **Railway**: New Project → Deploy from GitHub → the repo. It uses the
   `Dockerfile` (the official Playwright image with Chromium). In *Variables*
   set the ones in `.env.example` with `NODE_ENV=production`, `DEV_LOGIN=0`,
   `DATABASE_URL` and `PUBLIC_URL` (Railway's domain or yours). Settings →
   Networking → *Generate domain* or add your own. Keep **1 replica**: searches
   and the Chromium live in memory.
4. **Google**: Google Cloud Console → APIs & Services → OAuth consent screen
   (external, email/profile scopes only, link to `/privacy` and `/terms`) →
   Credentials → OAuth client ID *Web application* → redirect URI
   `https://YOUR-DOMAIN/auth/google/callback`. Copy the ID and secret into
   `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`.
5. **Stripe** (test mode first, with `sk_test_…`):
   ```bash
   STRIPE_SECRET_KEY=sk_test_... node scripts/stripe-setup.js --url https://YOUR-DOMAIN --webhook
   ```
   It creates the two products (tax code `txcd_10103001`, SaaS), the four
   prices with their lookup keys, the Customer Portal configuration and the
   webhook, and prints `STRIPE_PORTAL_CONFIGURATION` and
   `STRIPE_WEBHOOK_SECRET`. Put those and `STRIPE_SECRET_KEY` in Railway. It is
   safe to run again. `--tax exclusive` if your prices should be before VAT
   (default: VAT included). When everything works, repeat with the live key.
6. **Legal**: set `LEGAL_COMPANY_NAME`, `LEGAL_CONTACT_EMAIL` and
   `LEGAL_ADDRESS`; they fill `/terms` and `/privacy`. Those pages are
   templates — have them reviewed before launch.
7. **Check**: `https://YOUR-DOMAIN/healthz` should say `"db":true` and, after a
   minute, `"spotify":true`. If Spotify doesn't start, check the logs
   (`[Spotify] Bootstrap…`).
8. **Extension**: users download it from the app, already pointed at your
   domain. When it's on the Chrome Web Store, set `EXTENSION_STORE_URL`.

## Endpoints

| Route | What for |
|---|---|
| `GET /login`, `GET /billing`, `GET /` | pages (sign-in, plan & billing, the app) |
| `GET /terms`, `GET /privacy` | legal pages (filled from `LEGAL_*`) |
| `GET /auth/google` → `/auth/google/callback`, `POST /auth/logout` | sign-in |
| `GET /api/me` | user, plan, billing state, where the extension comes from |
| `GET /billing/plans` | the plan catalog |
| `POST /billing/checkout` `{plan, interval}` | Stripe Checkout |
| `POST /billing/cancel`, `/billing/resume`, `/billing/upgrade`, `/billing/portal` | manage the subscription |
| `POST /billing/webhook` | Stripe events |
| `GET /api/quota` | today's automated-DM allowance |
| `GET /downloads/artist-outreach-extension.zip` | the extension, patched for this domain |
| `/api/*` (search, discover, artists, folders, seen, pool, feedback…) | the engine |
| `POST /api/ext/pair`, `POST /api/ext/revoke-all`, `GET /api/ext/status` | the extension, from the app |
| `GET /ext/v1/me`, `/folders`, `/prospects`, `/quota`; `POST /ext/v1/events`, `/ig-followers`, `/quota/claim`, `/quota/release` | the extension (Bearer) |
| `GET /api/admin/overview` | users per plan and engine state (admins) |
| `GET /healthz` | health check |

## What changed from the desktop app

| Desktop | Web |
|---|---|
| LemonSqueezy licence per machine | Google sign-in + Stripe subscription |
| `artists.json`, `config.json` on disk | Postgres, per user |
| `affinity/global.json`, `pools/*.json` | Postgres, per user (gzipped) |
| `ig-followers.json` | Postgres, **shared**: what one user verifies helps everyone |
| One user, one Chromium | One Chromium for everyone; at most `MAX_CONCURRENT_CRAWLS` searches at once (the rest wait their turn) and one per user |
| Instagram from the home IP | From the server if allowed, and **from the user's browser through the extension** (Instagram blocks datacenter IPs) |
| A separate extension | The extension's pages inside the app (Outreach, Inbox) |
| Seven UI languages | English only |
| Splash, auto-updater, DMG/EXE | Not needed: deploy and everyone has the latest version |
