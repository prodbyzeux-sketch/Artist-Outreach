// ── API client ────────────────────────────────────────────────────────────────
const api = {
  async getConfig() { return (await fetch('/api/config')).json() },
  async saveConfig(c) { return (await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)})).json() },
  // One live search at a time: without abort, a slow response could arrive
  // after a newer one and overwrite the dropdown with old results.
  _searchCtrl: null,
  async search(query) {
    this._searchCtrl?.abort()
    const ctrl = (this._searchCtrl = new AbortController())
    return (await fetch(`/api/search?${new URLSearchParams({query})}`, { signal: ctrl.signal })).json()
  },
  async saveArtist(a) {
    const ctrl = new AbortController()
    const t = setTimeout(() => ctrl.abort(), 10000)  // 10s timeout — never gets stuck
    try {
      const r = await fetch('/api/artists', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(a), signal: ctrl.signal })
      return await r.json()
    } finally { clearTimeout(t) }
  },
  async getArtists(p={}) { return (await fetch(`/api/artists?${new URLSearchParams(p)}`)).json() },
  async updateArtist(id,u) { return (await fetch(`/api/artists/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(u)})).json() },
  async deleteArtist(id) { return (await fetch(`/api/artists/${id}`,{method:'DELETE'})).json() },
  async stats() { return (await fetch('/api/stats')).json() },
  async enrich(name, mbid) { return (await fetch(`/api/enrich?${new URLSearchParams({name, mbid: mbid||''})}`)).json() },
  async igFollowers(url) { return (await fetch(`/api/ig?${new URLSearchParams({url})}`)).json() },
  async bulkSaveArtists(artists, referenceArtist) {
    return (await fetch('/api/artists/bulk', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ artists, referenceArtist }) })).json()
  }
}

// ── State ─────────────────────────────────────────────────────────────────────
const S = {
  refArtist: null,
  allArtists: [],
  // v2.0.5 — A Set parallel to allArtists for an O(1) lookup on every SSE message.
  // Before: S.allArtists.find(x => x.id === a.id) on each one → O(n²) in total with
  // searches of 3,000 artists. With many results the UI lagged.
  allArtistIds: new Set(),
  filtered: [], idx: 0,
  dislikedNeighbors: new Set(),   // "not similar" neighbourhood (3 hops) — excluded
  likedNeighbors: new Set(),      // "save" neighbourhood — moves up in the order
  affinity: new Map(),            // id → closeness to what was approved (server, graph propagation)
  affinityEps: 0,                 // tie band: below this IG/recency decides
  skippedIds: new Set(),          // ids the user has already seen — don't repeat
  persistentSeen: new Set(),      // ids seen in any session, loaded from the server
  discoverSessionId: null,        // identifier so the server can learn
  savingProspect: false,          // guard against a double click on Save
  restartTimer: null,             // debounce to restart when sliders change
  spMin: 0, spMax: 5000000,
  // The server still receives the IG range (it decides whether to spend
  // verification), but the user no longer controls it: its place on screen is the country's.
  igMin: 0, igMax: 5000000,
  countries: [],                  // chosen ISO codes; empty = all
  droppedAsSeen: 0,               // dropped because they were seen in earlier sessions
  // Parse screen: active tab and saved list
  pxTab: 'found',
  savedArtists: [],
  savedOnly: false,               // came in through the saved pool: there is no review
  folders: [],
  folderId: null,                 // folder open in Saved; null = all
  refFilter: null,                // reference artist filtered in Saved; null = all
  statusFilter: null,             // 'contacted' | 'pending' in Saved; null = all
  sel: new Set(),                 // batch selection (Saved only)
  selAnchor: null,                // fixed end of the shift range
  searchTimer: null,
  // Discovery
  discoverES: null,
  discovering: false,
  discoverVisited: 0,
  discoverQueue: 0,
  discoverSent: 0
}

// ── i18n ──────────────────────────────────────────────────────────────────────
const I18N = {
  en: {
    settings: 'Settings',
    sx_title: 'Who do you want to sound like?',
    sx_title_found: 'I found {n} artists for lock in\nwho sound like…',
    expand_player: 'Expand player', pause_player: 'Pause', remove: 'Remove',
    toast_undo_hint: 'skipped, ⌘Z to undo', toast_undone: 'Undone', toast_nothing_undo: 'Nothing to undo', toast_nothing_redo: 'Nothing to redo',
    pools: 'Pools', clear_history: 'Clear',
    pool_saved: 'Saved', pool_saved_sub: 'everything you kept',
    folder_all: 'All', folder_new: '+ Folder', folder_new_menu: 'New folder…',
    folder_name_ask: 'Folder name', folder_del: 'Delete folder',
    confirm_folder_del: 'Delete this folder? The artists inside stay saved.',
    move_to: 'Move to…', move_none: 'Remove from folder',
    clear_selection: 'Clear selection', sel_count: '{n} selected', sel_remove: 'Remove',
    sel_contacted: '✓ Contacted', sel_save_contacted: '✓ Save & contacted',
    toast_moved: 'moved', confirm_delete_many: 'Delete {n} artists?',
    from_lc: 'from', filter_by_ref: 'Filter by reference artist',
    ref_all: 'All searches', ref_none: 'No reference',
    hist_empty: 'No searches yet — pick an artist above.',
    new_search: 'New search', close: 'Close',
    rv_down: 'All results',
    tab_found: 'Found', tab_saved: 'Saved',
    copy_ig: '⧉ Instagram',
    px_empty_found: 'Nothing found yet',
    px_empty_found_sub: 'Results appear here while the search runs.',
    px_empty_saved: 'No saved artists yet',
    px_empty_saved_sub: 'Save prospects from the review screen or with “Save all”.',
    px_empty_folder: 'This folder is empty',
    px_empty_folder_sub: 'Select artists in All and move them here.',
    px_empty_filter: 'Nothing matches these filters',
    px_empty_filter_sub: 'Change the status or the search filter above.',
    filter_by_status: 'Filter by status',
    status_all: 'All statuses', status_pending: 'Not contacted', status_contacted: 'Contacted',
    edit_artist: 'Edit Artist', ig_handle: 'Instagram Handle',
    notes: 'Notes', cancel: 'Cancel',
    toast_copied: 'copied to clipboard',
    found_lc: 'found', checking_ig_lc: 'checking IG', contacted_lc: 'contacted',
    toast_no_ig_list: 'No Instagram handles in this list',
    similar_to: 'Similar to', monthly_listeners: 'Monthly listeners',
    instagram_followers: 'Instagram followers',
    audience_country: 'Audience country', all_countries: 'All countries',
    pick_on_map: 'Pick on map', pick_countries: 'Pick audience countries',
    search_country: 'Search country...', clear_selection: 'Clear', loading: 'Loading...',
    map_hint: '{n} artists match', map_hint_all: 'No country picked — everything shows',
    listened_in: 'Most listeners in {place}',
    search_artist_placeholder: 'Search artist name...',
    export_csv: 'Export CSV', save_all: 'Save all',
    skip: 'Skip', not_similar: 'Not Similar', save_prospect: 'Save', px_run: 'Collect list', px_stop: 'Stop', preview_lc: 'Preview',
    th_status: 'Status',
    mark_contacted: 'Mark as contacted', delete: 'Delete',
    open_spotify: 'Open on Spotify', open_ig: 'Open Instagram',
    edit: 'Edit', save_one: 'Save prospect',
    lastfm_key: 'Last.fm API key (fallback only)',
    save: 'Save',
    // v2.0.5 new keys
    reset_seen_lbl: 'Discovery history',
    reset_seen_info: 'The app remembers every artist you have seen so it never shows the same one twice across searches. If your searches are returning "no more artists to show", reset this history to start fresh. Your saved prospects are NOT affected.',
    reset_seen_btn: 'Reset seen history',
    toast_history_cleared: 'History cleared',
    toast_reset_failed: 'Reset failed',
    toast_network_error: 'Network error',
    toast_removed: 'removed',
    toast_saved: 'saved',
    toast_no_export: 'No artists to export',
    toast_exported: 'exported',
    toast_no_save: 'No artists to save',
    toast_error_saving: 'Error saving',
    toast_network_save: 'Network error saving prospect',
    toast_marked_contacted: 'Marked as contacted',
    toast_marked_many: 'marked as contacted',
    toast_saved_marked: 'saved and marked as contacted',
    toast_all_contacted: 'They are all contacted already',
    ask_copied: '{n} copied · mark as contacted?',
    ask_exported: '{n} exported · mark as contacted?',
    ask_copied_found: '{n} copied · save & mark as contacted?',
    ask_exported_found: '{n} exported · save & mark as contacted?',
    ask_mark: 'Mark', ask_save_mark: 'Save & mark', ask_dismiss: 'Dismiss',
    toast_deleted: 'Deleted',
    confirm_delete: 'Delete this artist?',
    confirm_reset_seen: 'Reset your discovery history?\n\nThis lets the app show you artists you already reviewed in past searches. Your SAVED prospects are NOT affected.',
    empty_search_start: 'Search for an artist to start',
    empty_no_more: "That's it — no more artists match your filters",
    empty_no_more_sub: 'All matching artists have already been reviewed. Adjust filters or search another reference artist.',
    empty_reset_seen: 'No more artists to show',
    empty_reset_seen_sub: 'Every similar artist has already been reviewed in previous sessions. Try a different reference artist.',
    empty_nothing: 'The collection came back empty',
    empty_nothing_sub: 'Spotify returned no similar artists this time — usually a rate limit. Run it again.',
    empty_all_reviewed: 'All artists reviewed',
    empty_all_reviewed_sub: 'Search a new artist or adjust filters',
    empty_reset_filters: 'Reset filters',
    connect_spotify: 'Connecting to Spotify…',
    connect_spotify_sub: 'Setting up the graph exploration',
    exploring_similar: 'Exploring similar artists…',
    verifying_ig: 'Verifying Instagram data…',
    connection_error: 'Connection error',
    try_again: 'Try again in a moment',
  },
}

// The platform is English-only. The dictionary layer stays (data-i18n keys
// in index.html go through t()), with one language.
function currentLang() {
  return 'en'
}
// Returns null when the key doesn't exist in any dictionary.
//
// It used to return the KEY ITSELF as a last resort. Combined with
// applyTranslations' `if (txt)` — which could never be false — the result was
// that any untranslated data-i18n OVERWROTE the correct text already in the
// HTML and showed the user "GENRE_MODE_LBL". It happened on the four keys of
// the genre and sound settings, i.e. exactly on the two star features of v3.0.0.
//
// With null, the guard is useful again: if the translation is missing the
// template's text is kept, and it is always correct English.
function t(key) {
  const lang = currentLang()
  return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || null
}
// For texts that get concatenated: if the key is missing we'd rather use the
// text the caller passes than break the sentence.
function tf(key, fallback) {
  return t(key) || fallback
}
function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const txt = t(el.dataset.i18n)
    if (txt) el.textContent = txt
  })
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const txt = t(el.dataset.i18nPlaceholder)
    if (txt) el.placeholder = txt
  })
  // Icon-only buttons: the name lives in the title and in aria-label.
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const txt = t(el.dataset.i18nTitle)
    if (txt) { el.title = txt; el.setAttribute('aria-label', txt) }
  })
}

// ── Persisting "already seen" ─────────────────────────────────────────────────
// The IDs shown in the Finder are recorded globally so they are NEVER shown
// again (even if the app is closed and reopened). They are sent to the server
// in batches every 2 seconds.
const _seenBuffer = new Set()
let _seenFlushTimer = null
function markSeen(id) {
  if (!id) return
  if (S.persistentSeen && S.persistentSeen.has(id)) return
  if (S.persistentSeen) S.persistentSeen.add(id)
  _seenBuffer.add(id)
  clearTimeout(_seenFlushTimer)
  _seenFlushTimer = setTimeout(flushSeen, 2000)
}
async function flushSeen() {
  if (!_seenBuffer.size) return
  const ids = [..._seenBuffer]
  _seenBuffer.clear()
  try {
    await fetch('/api/seen', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids })
    })
  } catch(e) {}
}
async function loadSeenIds() {
  try {
    const r = await fetch('/api/seen-ids')
    const { ids } = await r.json()
    if (Array.isArray(ids)) {
      S.persistentSeen = new Set(ids)
      console.log(`[seen] loaded ${S.persistentSeen.size} previously seen ids`)
    }
  } catch(e) {}
}
// Flush what's pending when the user closes the window
window.addEventListener('beforeunload', () => {
  if (_seenBuffer.size) {
    const ids = [..._seenBuffer]
    _seenBuffer.clear()
    navigator.sendBeacon('/api/seen', JSON.stringify({ ids }))
  }
})

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = n => n==null?'—':n>=1e6?(n/1e6).toFixed(1).replace(/\.0$/,'')+'M':n>=1000?(n/1000).toFixed(1).replace(/\.0$/,'')+'K':String(n)
const fmtDate = s => s?new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}):'—'
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
const ini = n => n?n[0].toUpperCase():'?'
const $ = id => document.getElementById(id)

function fmtBig(n) {
  return n >= 1e6 ? (n/1e6).toFixed(1)+'M' : n >= 1000 ? Math.round(n/1000)+'K' : String(n)
}

function igUsername(url) {
  if (!url) return ''
  return url.replace(/\/$/, '').split('/').pop().split('?')[0].replace('@', '')
}

function passesFilters(a) {
  const f = a.followers || 0
  if (f < S.spMin || f > S.spMax) return false

  // IG followers: the server already trims what arrives with a confirmed number,
  // but what comes in without one (_igPending, Instagram's rate limit) is
  // filtered here as soon as the batch brings the number. Without a number the
  // artist PASSES: not knowing isn't proof they don't fit, and treating null as
  // out of range is exactly what left searches at zero before 1.1.
  if (a.igFollowers != null && (a.igFollowers < S.igMin || a.igFollowers > S.igMax)) return false

  // Learning/user-action blocks — each one filters the artist out in any case
  if (S.dislikedNeighbors && S.dislikedNeighbors.has(a.id)) return false
  if (S.skippedIds && S.skippedIds.has(a.id)) return false
  if (S.persistentSeen && S.persistentSeen.has(a.id)) return false   // seen before

  // Audience country: an OUTPUT filter, like the listener range. It lives only
  // in the client — the server doesn't know about it and so it can't leak into
  // the choice of seeds (lib/seeds.js: an output filter put there leaves the
  // BFS without seeds and the search returns zero).
  //
  // Without city data the artist PASSES: absence of data isn't proof they don't
  // fit — the same principle as IG's pending vs out-of-range.
  if (S.countries.length && a.countries?.length && !a.countries.some(c => S.countries.includes(c))) return false

  return true
}

let toastT
function toast(msg, type='ok') {
  const el = $('toast')
  el.textContent = msg
  el.className = `toast show ${type}`
  clearTimeout(toastT)
  toastT = setTimeout(() => el.className='toast', 3000)
}

// A one-click suggestion with a countdown. It lasts longer than a toast because
// it has to be read and decided on, and it goes away on its own: whoever doesn't
// answer isn't left with a notice stuck in the corner. Only one lives at a time.
const ASK_MS = 10000
let askT
let _askRun = null

function ask(msg, label, onYes) {
  _askRun = onYes
  $('ask-msg').textContent = msg
  $('ask-yes').textContent = label
  $('ask').classList.remove('hidden')
  // Restart the bar: without removing and re-adding the animation, a second
  // notice inherited the time the previous one had left and went away early.
  const fill = $('ask-fill')
  fill.style.animation = 'none'
  void fill.offsetWidth
  fill.style.animation = ''
  clearTimeout(askT)
  askT = setTimeout(closeAsk, ASK_MS)
}

function closeAsk() {
  clearTimeout(askT)
  _askRun = null
  $('ask').classList.add('hidden')
}

// ── Screens ───────────────────────────────────────────────────────────────────
// Two screens: search (big heading + filters + projects) and results, which are
// in turn two scroll-snapped panels — review on top, parse below.
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(el => el.classList.toggle('active', el.id === id))
}

function showSearch() {
  stopDiscover()
  leaveSavedPool()
  showScreen('scr-search')
  $('tb-back').classList.add('hidden')
  $('rv-ctx').classList.add('hidden')
  // The preview belongs to the results: here there's no artist it would
  // match, so it goes quiet and hides.
  hideDock()
  $('dock-island').classList.add('hidden')
  syncDockNotch()
  silencePlayer()
  renderSearchTitle()
  renderHistory()
  renderCountryFilter()   // the pool may have grown while reviewing
  $('artist-input').focus()
}

function showResults() {
  stopTitleCounter()   // the number only runs while it's being looked at
  showScreen('scr-results')
  $('tb-back').classList.remove('hidden')
  $('rv-ctx').classList.remove('hidden')
  // Every search comes in through the review panel, not where the last one was left.
  $('snap').scrollTop = 0
}

// Saved pool: entered from the home screen and there's no reference artist,
// so the results screen keeps only the gallery.
async function openSavedPool() {
  S.savedOnly = true
  S.pxTab = 'saved'
  S.folderId = null
  S.refFilter = null
  S.statusFilter = null
  clearSelection()
  $('scr-results').classList.add('saved-only')
  showResults()
  syncParseTabs()
  await refreshSaved()
  await loadFolders()
}

function leaveSavedPool() {
  S.savedOnly = false
  S.folderId = null
  S.refFilter = null
  S.statusFilter = null
  clearSelection()
  $('scr-results').classList.remove('saved-only')
}

function scrollToParse() {
  $('panel-parse').scrollIntoView({ behavior: 'smooth' })
}

function scrollToReview() {
  $('panel-review').scrollIntoView({ behavior: 'smooth' })
}

// ── Pools (search history) ────────────────────────────────────────────────────
// A search's pool of artists only lives in memory, so here we store the
// reference artist and opening it relaunches the discovery.
// The storage key keeps its old name on purpose: renaming it would wipe the
// history of anyone who already has the app.
const HIST_KEY = 'ao_projects'
const HIST_MAX = 12

// Running total of artists uncovered, for the home screen's heading. Kept apart
// from the history because that one only stores 12 projects and can be cleared:
// this count never goes down.
const FOUND_KEY = 'ao_found_total'
let _foundTotal = null

function foundTotal() {
  if (_foundTotal !== null) return _foundTotal
  const stored = parseInt(localStorage.getItem(FOUND_KEY) ?? '', 10)
  if (Number.isFinite(stored)) return (_foundTotal = stored)
  // First start on an already-used app: seeded from the saved projects so what
  // has actually been done doesn't start from zero.
  _foundTotal = loadHistory().reduce((n, h) => n + (h.found || 0), 0)
  localStorage.setItem(FOUND_KEY, String(_foundTotal))
  return _foundTotal
}

function bumpFoundTotal() {
  _foundTotal = foundTotal() + 1
  localStorage.setItem(FOUND_KEY, String(_foundTotal))
}

// The heading's number. It is NOT the real total: it starts at 100, goes up on
// its own while the home screen is visible and is saved, so every visit shows it
// higher than the last. It stops at 9,999. The only thing still tied to reality
// is whether it appears: without a single collected artist the original heading stays.
const TITLE_KEY = 'ao_title_count'
const TITLE_FROM = 100
const TITLE_CAP = 9999
const TITLE_STEP_MS = 400   // lowering this speeds up the climb and brings the cap forward
let _titleTimer = 0

function titleCount() {
  const stored = parseInt(localStorage.getItem(TITLE_KEY) ?? '', 10)
  const n = Number.isFinite(stored) ? Math.max(TITLE_FROM, stored) : TITLE_FROM
  return Math.min(TITLE_CAP, n)
}

// The value runs in memory and is persisted when it STOPS, not on every tick:
// writing localStorage (synchronous I/O) every 400ms while the home screen is
// visible was pure wear. beforeunload covers closing with the counter running.
let _titleN = null
function stopTitleCounter() {
  clearInterval(_titleTimer)
  if (_titleN != null) { localStorage.setItem(TITLE_KEY, String(_titleN)); _titleN = null }
}
window.addEventListener('beforeunload', stopTitleCounter)

function renderSearchTitle() {
  const el = $('sx-title')
  if (!el) return
  stopTitleCounter()
  if (!foundTotal()) { el.textContent = tf('sx_title', 'Who do you want to sound like?'); return }

  const tpl = tf('sx_title_found', 'I found {n} artists for lock in\nwho sound like…')
  let n = titleCount()
  const put = () => { el.textContent = tpl.replace('{n}', n.toLocaleString()) }
  put()
  if (n >= TITLE_CAP) return

  _titleTimer = setInterval(() => {
    _titleN = ++n
    put()
    if (n >= TITLE_CAP) stopTitleCounter()
  }, TITLE_STEP_MS)
}

function loadHistory() {
  try {
    const raw = JSON.parse(localStorage.getItem(HIST_KEY) || '[]')
    return Array.isArray(raw) ? raw : []
  } catch (e) { return [] }
}

function pushHistory(artist) {
  if (!artist?.id) return
  const prev = loadHistory()
  const entry = {
    id: artist.id, name: artist.name, image: artist.image || null,
    followers: artist.followers || 0, url: artist.url || null,
    genres: artist.genres || [], ts: Date.now(),
    // Kept while the new collection runs; re-stamped when it finishes.
    found: prev.find(h => h.id === artist.id)?.found ?? null
  }
  const list = [entry, ...prev.filter(h => h.id !== artist.id)].slice(0, HIST_MAX)
  localStorage.setItem(HIST_KEY, JSON.stringify(list))
  renderHistory()
}

// How many artists the project produced. Only known when the collection
// finishes (or stops), so it is stamped onto the entry already saved.
function stampHistoryCount() {
  if (!S.refArtist?.id) return
  const list = loadHistory()
  const entry = list.find(h => h.id === S.refArtist.id)
  if (!entry) return
  entry.found = S.allArtists.length
  localStorage.setItem(HIST_KEY, JSON.stringify(list))
  renderHistory()
}

// The fixed pool of saved artists. It isn't a search, so it doesn't live in the
// history and "Clear" doesn't delete it: it is where every search ends up.
function savedPoolCard() {
  return `
    <button class="hist-card hist-card--saved" data-pool="saved">
      <div class="hist-ph">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M6 4h12a1 1 0 0 1 1 1v15l-7-4.2L5 20V5a1 1 0 0 1 1-1z"/>
        </svg>
      </div>
      <div class="hist-info">
        <span class="hist-name">${esc(tf('pool_saved', 'Saved'))}</span>
        <span class="hist-sub">${S.savedArtists.length.toLocaleString()} · ${esc(tf('pool_saved_sub', 'everything you kept'))}</span>
      </div>
    </button>`
}

function renderHistory() {
  const grid = $('hist-grid')
  if (!grid) return
  const list = loadHistory()
  $('hist-clear').classList.toggle('hidden', !list.length)
  if (!list.length) {
    grid.innerHTML = savedPoolCard() + `<p class="hist-empty">${tf('hist_empty', 'No searches yet — pick an artist above.')}</p>`
    bindPoolCards()
    return
  }
  grid.innerHTML = savedPoolCard() + list.map(h => {
    // Spotify's search no longer returns listeners, so the line can end up
    // without data: better to leave it out than to draw a dash.
    const top = h.followers ? fmt(h.followers) + ' monthly' : (h.genres || [])[0]
    return `
    <button class="hist-card" data-id="${esc(h.id)}">
      ${h.image
        ? `<img class="hist-img" src="${esc(h.image)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'hist-ph',textContent:'${esc(ini(h.name))}'}))">`
        : `<div class="hist-ph">${esc(ini(h.name))}</div>`}
      <div class="hist-info">
        <span class="hist-name">${esc(h.name)}</span>
        ${top ? `<span class="hist-meta">${esc(top)}</span>` : ''}
        <span class="hist-sub">${h.found ? h.found.toLocaleString() + ' found · ' : ''}${fmtDate(h.ts)}</span>
      </div>
    </button>`
  }).join('')

  bindPoolCards()
}

function bindPoolCards() {
  $('hist-grid').querySelectorAll('.hist-card').forEach(el => {
    el.addEventListener('click', () => {
      if (el.dataset.pool === 'saved') { openSavedPool(); return }
      const h = loadHistory().find(x => x.id === el.dataset.id)
      if (h) { $('artist-input').value = h.name; pickArtist(h) }
    })
  })
}

function clearHistory() {
  localStorage.removeItem(HIST_KEY)
  renderHistory()
}

// ── Range sliders ─────────────────────────────────────────────────────────────
// The slider visually represents the 0-50,000 range (the useful one for our
// case). The number inputs DO accept higher values up to the real maximum (5M).
// If the number goes over 50k, the slider's pin stays anchored at the top but
// the filter respects the typed value.
function initSlider(minId, maxId, minNId, maxNId, fillId, onChange) {
  const mn = $(minId), mx = $(maxId), mnN = $(minNId), mxN = $(maxNId), fill = $(fillId)
  const MAX_REAL = +mx.max      // real maximum allowed in the number inputs
  const SLIDER_CAP = 50000      // maximum value represented by the slider
  mn.max = SLIDER_CAP; mx.max = SLIDER_CAP
  mn.step = 100; mx.step = 100  // steps of 100 for smooth movement

  function updateFill() {
    const lo = +mn.value / SLIDER_CAP * 100
    const hi = +mx.value / SLIDER_CAP * 100
    fill.style.left = lo + '%'
    fill.style.width = (hi - lo) + '%'
  }

  // The visual fill follows the finger; onChange (re-filtering and re-sorting
  // the whole pool) goes through a short debounce — at 60Hz of input events it
  // was a full sort per frame during the whole drag.
  let changeT = null
  function fromSlider() {
    let lo = +mn.value, hi = +mx.value
    if (lo > hi) { if (this===mn) mn.value=hi; else mx.value=lo }
    lo = +mn.value; hi = +mx.value
    mnN.value = lo; mxN.value = hi
    updateFill()
    clearTimeout(changeT)
    changeT = setTimeout(() => onChange(lo, hi), 100)
  }

  function fromNum() {
    let lo = Math.max(0, Math.min(+mnN.value || 0, MAX_REAL))
    let hi = Math.max(0, Math.min(+mxN.value || MAX_REAL, MAX_REAL))
    if (lo > hi) hi = lo
    mnN.value = lo; mxN.value = hi
    // The slider stays ANCHORED at the top if the value exceeds it
    mn.value = Math.min(lo, SLIDER_CAP)
    mx.value = Math.min(hi, SLIDER_CAP)
    updateFill(); onChange(lo, hi)
  }

  mn.addEventListener('input', fromSlider.bind(mn))
  mx.addEventListener('input', fromSlider.bind(mx))
  mnN.addEventListener('change', fromNum)
  mxN.addEventListener('change', fromNum)

  // Initial state: read the input's real value and anchor the slider if it's over
  mn.value = Math.min(+mnN.value || 0, SLIDER_CAP)
  mx.value = Math.min(+mxN.value || SLIDER_CAP, SLIDER_CAP)
  updateFill()
}

// ── Artist search ─────────────────────────────────────────────────────────────
function initSearch() {
  const inp = $('artist-input'), dd = $('combo-dd')

  function closeDD() { dd.classList.add('hidden'); dd.innerHTML='' }

  inp.addEventListener('input', () => {
    clearTimeout(S.searchTimer)
    const q = inp.value.trim()
    if (!q) { closeDD(); return }

    S.searchTimer = setTimeout(async () => {
      dd.innerHTML = '<div class="dd-item"><div class="loading-row"><div class="spinner"></div><span>Searching...</span></div></div>'
      dd.classList.remove('hidden')

      let res
      try {
        res = await api.search(q)
      } catch (e) {
        if (e.name === 'AbortError') return   // replaced by a newer query
        res = { success: false, error: 'Network error' }
      }

      if (!res.success) {
        dd.innerHTML = `<div class="dd-err">${esc(res.error||'No results')}</div>`
        return
      }
      if (!res.artists?.length) {
        dd.innerHTML = '<div class="dd-msg">No artists found</div>'
        return
      }

      dd.innerHTML = res.artists.map(a => `
        <div class="dd-item" data-id="${a.id}" data-name="${esc(a.name)}"
          data-fol="${a.followers}" data-img="${a.image||''}"
          data-genres='${JSON.stringify(a.genres||[])}' data-url="${a.url||''}">
          ${a.image
            ? `<img src="${a.image}" onerror="this.style.display='none'">`
            : `<div class="dd-av">${ini(a.name)}</div>`}
          <div>
            <div class="dd-name">${esc(a.name)}</div>
            ${/* Spotify's search no longer returns listeners: it showed
                 "0 monthly listeners" even for Bad Bunny, and that line was
                 the only thing telling two namesake artists apart. Without
                 data, we don't draw a fake number. */
              a.followers > 0
                ? `<div class="dd-follow">${fmt(a.followers)} ${tf('monthly_listeners_lc', 'monthly listeners')}</div>`
                : ''}
          </div>
        </div>`).join('')

      dd.querySelectorAll('.dd-item[data-id]').forEach(el => {
        el.addEventListener('click', () => {
          pickArtist({ id:el.dataset.id, name:el.dataset.name, followers:+el.dataset.fol, image:el.dataset.img, genres:JSON.parse(el.dataset.genres), url:el.dataset.url })
          inp.value = el.dataset.name
          closeDD()
        })
      })
    }, 350)
  })

  document.addEventListener('click', e => {
    if (!e.target.closest('.combo-wrap')) closeDD()
  })
}

// ── Discovery ─────────────────────────────────────────────────────────────────
// Warn the user when the gap between reference and filter is odd (v1.1.5).
// Spotify's relatedArtists share the reference's listener level. If you search
// mainstream + a micro filter (or the other way round), almost nothing from the
// BFS fits and the few that come out are very weak bridges in the graph. We say
// so in a toast so the user adjusts the filters or changes the reference.
function warnIfFilterMismatch(artist) {
  const ref = artist?.monthlyListeners || 0
  if (!ref) return
  const min = S.spMin || 0
  const max = S.spMax || 5000000
  const format = n => n >= 1e6 ? (n/1e6).toFixed(1)+'M'
                     : n >= 1e3 ? Math.round(n/1e3)+'K'
                     : String(n)

  // Reference far above the filter (mainstream + micro filter)
  if (max > 0 && ref > max * 10) {
    toast(`${artist.name} has ~${format(ref)} listeners. Your filter goes up to ${format(max)}. Similar artists on Spotify tend to have listeners close to the reference — you may get few or noisy results.`, 'err')
    return
  }
  // Reference far below the filter (nano artist + big filter)
  if (min > 0 && ref < min / 10) {
    toast(`${artist.name} has ~${format(ref)} listeners. Your filter starts at ${format(min)}. This is a large gap — expect few results.`, 'err')
  }
}

async function pickArtist(artist) {
  S.refArtist = artist
  leaveSavedPool()
  S.pxTab = 'found'
  syncParseTabs()
  pushHistory(artist)
  setReviewBg(artist.banner || artist.image)
  showResults()
  S.idx = 0
  S.allArtists = []
  // Without this, if the new search starts again with the same artist that was
  // being viewed, renderArtist takes its "already painted" shortcut and never
  // touches the background: the screen kept the REFERENCE artist's banner that
  // this very function had just set.
  _lastRenderedArtistId = null
  _bgPrefetched.clear()
  S.allArtistIds.clear()   // v2.0.5 keep the parallel Set in sync
  S.filtered = []
  S.droppedAsSeen = 0
  _undoStack.length = 0        // the history belongs to the search being closed
  _redoStack.length = 0
  S.discoverVisited = 0
  S.discoverQueue = 0

  // v2.0.6 (Bug 14) — Cancel the previous search's IG batch in progress.
  // Without this, a batch that started right before the artist change kept
  // running and updated the NEW search's S.filtered. Real effect: artists of the
  // new search showed "3.4K followers" from a namesake of the previous one.
  // Very rare but possible.
  if (_batchTimer) { clearTimeout(_batchTimer); _batchTimer = null }
  _batchInFlight = false

  // v1.1.5 — remember the filters the search started with so scheduleRestart
  // can decide whether a slider change deserves a restart.
  S.lastServerSpMin = S.spMin
  S.lastServerSpMax = S.spMax
  S.lastServerIgMin = S.igMin
  S.lastServerIgMax = S.igMax

  // Mismatch warning — doesn't block the search, it only informs.
  warnIfFilterMismatch(artist)
  // Reset the learning: every search starts without the previous one's bias
  if (S.dislikedNeighbors) S.dislikedNeighbors.clear()
  if (S.likedNeighbors) S.likedNeighbors.clear()
  if (S.affinity) S.affinity.clear()
  S.affinityEps = 0
  if (S.skippedIds) S.skippedIds.clear()
  // A unique ID so the server knows what to "kill" in this search
  const oldSession = S.discoverSessionId
  S.discoverSessionId = (crypto.randomUUID && crypto.randomUUID()) || String(Date.now())+Math.random()
  // FULL reset: server caches + the previous session's state. In parallel:
  // they're independent and in series they added two round trips before showing anything.
  await Promise.all([
    fetch('/api/reset-caches', { method: 'POST' }).catch(() => {}),
    oldSession
      ? fetch('/api/session-reset', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ sessionId: oldSession }) }).catch(() => {})
      : null
  ])

  S.pxTab = 'found'
  syncParseTabs()
  renderParse()
  setArtistArea(`<div class="empty-state"><div class="spinner" style="margin:0 auto 12px"></div><p class="empty-title">${t('connect_spotify')}</p><p class="empty-sub">${t('connect_spotify_sub')}</p></div>`)

  const srcEl = $('f-src')
  if (srcEl) { srcEl.textContent = 'Spotify'; srcEl.className = 'f-src f-src--sp' }

  // Opening an already-collected pool does NOT search again: its artists are
  // restored and the user decides whether to keep collecting with "Collect list".
  // Before it always crawled, and since seenIds hides what was already shown the
  // second pass returned different people: what was found the first time was lost.
  const [restored] = await Promise.all([restorePool(artist.id), refreshSaved()])
  if (!restored) openDiscoverStream()
}

// Returns how many artists were restored (0 = new pool, it has to be crawled).
async function restorePool(refId) {
  let artists = []
  try {
    const r = await fetch(`/api/pool?refId=${encodeURIComponent(refId)}`).then(x => x.json())
    artists = (r?.success && Array.isArray(r.artists)) ? r.artists : []
  } catch (e) { return 0 }
  if (!artists.length) return 0

  for (const a of artists) {
    if (S.allArtistIds.has(a.id)) continue
    a._rand = Math.random()
    a._tier = releaseTier(a.latestRelease)
    if (a.affinity != null) absorbAffinity(a.id, a.affinity)
    S.allArtists.push(a)
    S.allArtistIds.add(a.id)
    // The ones left unverified (IG rate limit) are re-verified as in the live
    // stream; the rest already carry their saved number.
    if (a.instagram && a.igFollowers == null) a._igPending = true
  }
  S.discovering = false
  applyFilters()
  renderParse()
  updateContext()
  if (S.allArtists.some(a => a._igPending)) scheduleIGBatch()
  return artists.length
}

// Collecting is started and stopped from the gallery ("Collect list" button),
// so the stream lives apart from pickArtist: resuming it must not throw away
// the pool already gathered or the artist the user is reviewing.
function openDiscoverStream() {
  const artist = S.refArtist
  if (!artist) return
  if (S.discoverES) { S.discoverES.close(); S.discoverES = null }
  S.discovering = true
  updateContext()

  const params = new URLSearchParams({
    artistId: artist.id || '',
    artistName: artist.name || '',
    igMin: String(S.igMin || 0),
    igMax: String(S.igMax || 5000000),
    // v1.1.5: send the listener range so the server prioritises seeds inside
    // the filter and doesn't spend the BFS on out-of-range artists.
    listMin: String(S.spMin || 0),
    listMax: String(S.spMax || 5000000),
    // v2.1.3: genre filtering mode (off/loose/strict). Stored in localStorage
    // with default 'loose' (no longer used by the engine, see engine.js).
    genreMode: localStorage.getItem('ao_genre_mode') || 'loose',
    // v2.2.0: sound similarity threshold (off/loose/medium/strict).
    // 'medium' is the recommended default (no longer used by the engine, see engine.js).
    soundMode: localStorage.getItem('ao_sound_mode') || 'medium',
    sessionId: S.discoverSessionId || '',
  })
  const es = new EventSource(`/api/discover?${params}`)
  S.discoverES = es

  es.onmessage = e => {
    const msg = JSON.parse(e.data)

    if (msg.type === 'meta') return   // engine status: no longer shown in the UI

    if (msg.type === 'artist') {
      const a = msg.artist
      // v2.0.5 — O(1) lookup with a Set instead of .find (was O(n) → O(n²) in total)
      if (S.allArtistIds.has(a.id)) return
      if (S.skippedIds && S.skippedIds.has(a.id)) return
      if (S.dislikedNeighbors && S.dislikedNeighbors.has(a.id)) return
      // Counted so the empty screen can tell the truth: "you've already seen them
      // all" and "none arrived" are two different problems.
      if (S.persistentSeen && S.persistentSeen.has(a.id)) { S.droppedAsSeen++; return }
      a._rand = Math.random()
      if (a._tier == null) a._tier = releaseTier(a.latestRelease)
      // The server sends taste ON the card: the gallery sorts by sound from the
      // first artist, without waiting for the session's first vote.
      if (a.affinity != null) absorbAffinity(a.id, a.affinity)
      S.allArtists.push(a)
      S.allArtistIds.add(a.id)
      bumpFoundTotal()
      // If it comes in pending, start the verification batch
      if (a.instagram && a.igFollowers == null) scheduleIGBatch()
      if (passesFilters(a)) {
        S.filtered.push(a)
        sortUnreviewed()
        if (S.filtered.length === 1) renderArtist()
        updateContext()
      }
      // NO proactive fetch: the server already handles it with Pool A/B. Firing
      // hundreds of parallel fetches from the client saturated Chrome
      // (ERR_INSUFFICIENT_RESOURCES) and blocked the save's POST.
    }

    // The server chases on its own the numbers Instagram didn't confirm during
    // the crawl and sends them when it has them (Pool C). They arrive in bursts,
    // so re-filtering is grouped: each message triggers a full applyFilters of
    // the whole pool.
    if (msg.type === 'igFollowers') {
      const a = S.allArtists.find(x => x.id === msg.id)
      if (a && a.igFollowers == null) {
        a.igFollowers = msg.followers
        delete a._igPending
        const el = $(`ig-fol-${a.id}`)
        if (el) el.textContent = fmt(msg.followers) + ' followers'
        scheduleRefilter()
      }
    }

    if (msg.type === 'progress') {
      S.discoverVisited = msg.visited
      S.discoverQueue = msg.queue
      S.discoverSent = msg.sent || 0
      updateContext()
      // If there are no visible artists yet, refresh the adaptive message
      if (!S.filtered.length) renderArtist()
    }

    if (msg.type === 'done' || msg.type === 'error') {
      S.discovering = false
      S.discoverES = null
      updateContext()
      stampHistoryCount()
      if (!S.filtered.length) renderArtist()  // show empty state
    }
  }

  // v2.0.1 — A much less aggressive error handler.
  //
  // Before: any onerror killed the session and painted "Connection error",
  //         including the normal close after 'done' and the browser's
  //         transient reconnections during the 12-15s bootstrap.
  //
  // Now: we tell apart by readyState and by whether the ES is still current.
  //      We only show an error if the connection really closed (CLOSED)
  //      AND no artist arrived AND it wasn't replaced by another search.
  es.onerror = (evt) => {
    // If the user already started another search, this is an old ES — ignore it.
    if (S.discoverES !== es) return
    // Transient reconnection: the browser retries on its own, don't bother.
    if (es.readyState === EventSource.CONNECTING) return
    // Only treat it as a REAL error when the EventSource has closed.
    if (es.readyState !== EventSource.CLOSED) return

    S.discovering = false
    S.discoverES = null
    updateContext()
    if (!S.filtered.length) {
      setArtistArea(`<div class="empty-state"><p class="empty-title">${t('connection_error')}</p><p class="empty-sub">${t('try_again')}</p></div>`)
    }
  }
}

function stopDiscover() {
  if (S.discoverES) { S.discoverES.close(); S.discoverES = null }
  S.discovering = false
  updateContext()
  stampHistoryCount()
}

function toggleDiscover() {
  if (S.discovering) stopDiscover()
  else openDiscoverStream()
}

function updateContext() {
  if (!S.refArtist) return
  const total = S.filtered.length
  const pending = S.discoverQueue
  let meta = `${tf('similar_to', 'Similar to')} ${S.refArtist.name} · ${total.toLocaleString()} ${tf('found_lc', 'found')}`
  if (S.discovering && pending > 0) meta += ` · ${pending.toLocaleString()} ${tf('checking_ig_lc', 'checking IG')}…`
  else if (S.discovering) meta += ' …'
  $('rv-ctx').textContent = meta

  const run = $('px-run')
  run.textContent = S.discovering ? tf('px_stop', 'Stop') : tf('px_run', 'Collect list')
  run.classList.toggle('running', S.discovering)
  run.classList.toggle('hidden', runChipHidden())

  $('cnt-found').textContent = total
  syncBulkChips()
  scheduleParseRender()
}

// The SSE fires updateContext for every artist. Repainting the ~700 cards on
// every message isn't just expensive: it replaces the DOM under the cursor, so
// the open panel of the card you were looking at disappeared. We repaint at
// most once a second AND only if the parse panel is in view; scrolling down to
// it repaints immediately (see the scroll listener in init).
let _parseRenderTimer = null
let _parseRenderPending = false
// What came in from the stream while the gallery wasn't visible. It used to be
// caught up by repainting in the frame it was crossed into; now it's noted here
// and painted when the gesture stops (see the #snap listener).
let _parseDirty = false
function parsePanelVisible() {
  if (!$('scr-results').classList.contains('active')) return false
  if (S.savedOnly) return true   // in this mode the gallery is the only panel
  const snap = $('snap')
  return snap.scrollTop > snap.clientHeight / 2
}
function scheduleParseRender() {
  if (!parsePanelVisible()) { _parseDirty = true; return }
  if (_parseRenderTimer) return
  _parseRenderTimer = setTimeout(() => {
    _parseRenderTimer = null
    if (!parsePanelVisible()) return
    // With the cursor inside the grid, rebuilding it takes away the card the
    // user has open just as they're about to click one of its buttons.
    // It is postponed until the mouse leaves (mouseleave, see init).
    if ($('px-grid').matches(':hover')) { _parseRenderPending = true; return }
    renderParse()
  }, 1000)
}

// Background of the review screen: the banner of the artist being viewed.
// Two alternating layers to cross from one to the next without going through
// black, and the image isn't mounted until it has loaded — otherwise every jump flickered.
let _bgLayer = 0
let _bgUrl = null
function setReviewBg(url) {
  const layers = [$('rv-bg-a'), $('rv-bg-b')]
  if (!layers[0] || !layers[1] || url === _bgUrl) return
  _bgUrl = url

  if (!url) { layers.forEach(l => { l.classList.remove('on'); l.style.backgroundImage = '' }); return }

  const img = new Image()
  img.onload = () => {
    if (_bgUrl !== url) return   // the user already moved on to another artist
    const next = layers[_bgLayer ^ 1]
    next.style.backgroundImage = `url("${url}")`
    next.classList.add('on')
    layers[_bgLayer].classList.remove('on')
    _bgLayer ^= 1
  }
  // A photo that doesn't load left the PREVIOUS artist's on screen, which is
  // worse than no background: it looks like the app is showing someone else.
  img.onerror = () => {
    if (_bgUrl !== url) return
    layers.forEach(l => l.classList.remove('on'))
  }
  img.src = url
}

// The banner weighs more than the avatar and is seen whole at once, so the
// next artists' banners in the queue are preloaded.
const BG_PREFETCH = 8
const _bgPrefetched = new Set()
function prefetchBanners(from) {
  for (let i = 1; i <= BG_PREFETCH; i++) {
    const a = S.filtered[from + i]
    const url = a && (a.banner || a.image)
    if (!url || _bgPrefetched.has(url)) continue
    _bgPrefetched.add(url)
    new Image().src = url
  }
}

// IG follower verification in BATCHES — much faster than one by one. A single
// POST with up to 15 URLs; the server processes them in parallel (20 workers).
// A typical batch resolves in 1-3 seconds.
let _batchInFlight = false
let _batchTimer = null
// Web: each artist is tried at most IG_MAX_TRIES times. On the desktop the
// server took seconds per batch, which throttled this loop by itself; on the
// web, with server-side lookups off, it answers null instantly and the
// chaining below became one request every 150 ms forever.
const IG_MAX_TRIES = 3
let _batchBackoff = 150

function scheduleIGBatch() {
  if (_batchTimer || _batchInFlight) return
  _batchTimer = setTimeout(runIGBatch, _batchBackoff)   // batch up to 150ms
}

function applyIgFollowers(pending, results) {
  let changed = false
  for (const a of pending) {
    const f = results[a.instagram]
    if (f != null && a.igFollowers == null) {
      a.igFollowers = f
      delete a._igPending
      const el = $(`ig-fol-${a.id}`)
      if (el) el.textContent = fmt(f) + ' followers'
      changed = true
    }
  }
  return changed
}

async function runIGBatch() {
  _batchTimer = null
  if (_batchInFlight) return
  // Take the first 15 pending from the filtered pool, prioritising those near the current one
  const pending = []
  const start = S.idx
  const limit = 15
  for (let i = 0; i < S.filtered.length && pending.length < limit; i++) {
    const pos = (start + i) % S.filtered.length
    const a = S.filtered[pos]
    if (a && a.instagram && a.igFollowers == null && (a._igTries || 0) < IG_MAX_TRIES) pending.push(a)
  }
  if (!pending.length) return
  _batchInFlight = true
  let changed = false
  try {
    for (const a of pending) a._igTries = (a._igTries || 0) + 1
    const urls = pending.map(a => a.instagram)
    const r = await fetch('/api/ig-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ urls })
    })
    const { results } = await r.json()
    changed = applyIgFollowers(pending, results || {})

    // Web: what the server couldn't confirm (Instagram blocks datacenter IPs
    // a lot) is asked from the user's own browser through the extension, with
    // their own Instagram session. See platform.js.
    const left = pending.filter(a => a.igFollowers == null)
    if (left.length && window.AOExt && window.AOExt.ready()) {
      try {
        const extResults = await window.AOExt.lookupFollowers(left.map(a => a.instagram))
        if (applyIgFollowers(left, extResults)) changed = true
      } catch (e) {
        console.warn('[ig-batch] extension:', e.message)
      }
    }

    if (changed) {
      applyFilters()
      const cur = S.filtered[S.idx]
      if (cur) renderArtist()
    }
  } catch(e) {
    console.warn('[ig-batch] error:', e)
  } finally {
    _batchInFlight = false
    // A batch that resolved nothing makes the next one wait: the server and
    // the extension are rate-limited, or there's no way to know right now.
    _batchBackoff = changed ? 150 : 4000
    // If there are pending ones left, chain another batch
    const stillPending = S.filtered.some(a => a && a.instagram && a.igFollowers == null && (a._igTries || 0) < IG_MAX_TRIES)
    if (stillPending) scheduleIGBatch()
  }
}

// Compatible wrapper: calls the batch instead of going one by one
async function fetchIGFollowers(a) {
  if (!a || !a.instagram || a.igFollowers != null) return
  scheduleIGBatch()
}

// ── Filters ───────────────────────────────────────────────────────────────────
// v2.0.5 — dynamic. It used to be hardcoded to 2025 and in later years it would
// have treated a release from the previous year or older as "recent", without
// prioritising the current emerging artists.
// Freshness tier of the last release — a mirror of the server's lib/recency.js:
// 1-3 months = starting the next cycle, the pitch lands (top);
// >12 months = probably dormant (bottom); the rest — including something just
// released this month and those without data — in the middle, unordered.
// The tier is computed ONCE per artist when it enters the pool (a._tier) and the
// comparator reads it from there: computing it inside igFirst created two Dates
// per comparison — with 3,000 artists, ~70,000 objects on every slider move.
// A module-level "now" is correct: the tier boundaries move by months, not
// within a session.
const _tierNow = new Date()
// The city where they're listened to most. No data, no chip: a "—" takes the
// same space as data and says nothing.
function cityChip(topCity) {
  if (!topCity?.city) return ''
  const place = topCity.country
    ? `${topCity.city}, ${countryName(topCity.country)}`
    : topCity.city
  return `<span class="art-chip" title="${esc(t('listened_in').replace('{place}', place))}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M3 15v-3a9 9 0 0 1 18 0v3"/><path d="M21 15v3a2 2 0 0 1-2 2h-2v-5h4z"/><path d="M3 15v3a2 2 0 0 0 2 2h2v-5H3z"/>
      </svg>${esc(topCity.city)}</span>`
}

function releaseTier(latestRelease) {
  const year = latestRelease?.year
  if (!year) return 1
  const month = latestRelease.month || 12
  const months = (_tierNow.getFullYear() - year) * 12 + (_tierNow.getMonth() + 1 - month)
  if (months >= 1 && months <= 3) return 0
  if (months > 12) return 2
  return 1
}

function igFirst(a, b) {
  // 0. Closeness to what was approved. Replaces likedNeighbors' binary bit
  //    once there are votes: propagation through the graph covers that
  //    neighbourhood and also sinks the rejected one's, weighted instead of
  //    yes/no. Ties within the eps band are left to the criteria below — almost
  //    the whole pool scores near zero and must not reorder anything.
  if (S.affinity && S.affinity.size) {
    const aAf = S.affinity.get(a.id) || 0
    const bAf = S.affinity.get(b.id) || 0
    if (Math.abs(aAf - bAf) > S.affinityEps) return bAf - aAf
  } else {
    const aLik = S.likedNeighbors && S.likedNeighbors.has(a.id) ? 1 : 0
    const bLik = S.likedNeighbors && S.likedNeighbors.has(b.id) ? 1 : 0
    if (aLik !== bLik) return bLik - aLik
  }

  // 1. IG primero
  const aIg = !!a.instagram, bIg = !!b.instagram
  if (aIg !== bIg) return aIg ? -1 : 1
  // 2. Freshness tier: 1-3 months on top, >12 months at the bottom. Replaces the
  //    cut by year — within the middle tier the order is mixed on purpose, with
  //    no sub-sorting by date (v2.0.6/Bug 11 still stands: missing data isn't
  //    penalised, it falls into the middle tier).
  const aTier = a._tier ?? (a._tier = releaseTier(a.latestRelease))
  const bTier = b._tier ?? (b._tier = releaseTier(b.latestRelease))
  if (aTier !== bTier) return aTier - bTier
  // 3. Random order within the group
  return (a._rand || 0) - (b._rand || 0)
}

// Re-sort the portion of filtered the user hasn't reviewed yet (keeps current
// card stable). Deferred in batches: the SSE fires it for EVERY artist and
// sorting the whole queue per message was O(n·n log n) in a 3,000-artist crawl.
// One sort per second keeps the same final order; the gallery already repaints
// at that same rate (scheduleParseRender) and the deck is repaired in renderArtist.
let _sortTimer = null
function sortUnreviewed() {
  if (_sortTimer) return
  _sortTimer = setTimeout(() => {
    _sortTimer = null
    if (S.filtered.length < 2) return
    const pivot = S.idx + 1
    const unreviewed = S.filtered.slice(pivot).sort(igFirst)
    S.filtered = [...S.filtered.slice(0, pivot), ...unreviewed]
    renderArtist()   // only patches the deck if the current one didn't change (guard by id)
  }, 1000)
}

function applyFilters() {
  const currentArtist = S.filtered[S.idx]
  const newFiltered = S.allArtists.filter(passesFilters).sort(igFirst)

  if (!newFiltered.length) {
    S.filtered = newFiltered
    S.idx = 0
    updateContext(); renderArtist(); return
  }

  const currentId = currentArtist?.id
  const currentInNew = currentId ? newFiltered.findIndex(a => a.id === currentId) : -1

  if (currentInNew >= 0) {
    // The current one is still in the filter → keep focus, no re-render
    S.filtered = newFiltered
    S.idx = currentInNew
    updateContext()
  } else {
    // The current one left the filter (or there wasn't one) → move on
    S.filtered = newFiltered
    S.idx = Math.min(S.idx, newFiltered.length - 1)
    updateContext(); renderArtist()
  }
}

// The numbers from the server's backfill arrive in bursts, and every
// applyFilters re-sorts the whole pool: grouping them goes from one sort per
// message to one per burst. Same criterion as the sliders' debounce.
let _refilterTimer = null
function scheduleRefilter() {
  if (_refilterTimer) return
  _refilterTimer = setTimeout(() => {
    _refilterTimer = null
    applyFilters()
    if (S.filtered[S.idx]) renderArtist()
  }, 300)
}

// The vote comes back with the score of the WHOLE pool already collected, not
// only what's still in the verification queue: without sending poolIds, a "not
// similar" only reordered what hadn't arrived yet and the cards already on
// screen stayed where they were. Fire-and-forget: the user keeps reviewing and
// the reorder lands when it arrives.
// A score arriving on its own (artist payload, restored pool) goes into the
// map and widens the tie band if needed; a vote's response still rewrites
// everything in sendVote.
function absorbAffinity(id, v) {
  S.affinity.set(id, v)
  const band = Math.abs(v) * 0.05
  if (band > S.affinityEps) S.affinityEps = band
}

function sendVote(artistId, action) {
  if (!S.discoverSessionId) return
  fetch('/api/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      sessionId: S.discoverSessionId, artistId, action,
      poolIds: S.allArtists.map(x => x.id)
    })
  })
    .then(r => r.json())
    .then(({ affinity }) => {
      const entries = affinity ? Object.entries(affinity) : []
      if (!entries.length) return
      S.affinity = new Map(entries)
      // Relative tie band: the two measured pockets are ~2 orders of magnitude
      // apart, so 5% of the maximum falls well inside the same pocket and lets
      // IG/recency keep ordering within it.
      let maxAbs = 0
      for (const [, v] of entries) maxAbs = Math.max(maxAbs, Math.abs(v))
      S.affinityEps = maxAbs * 0.05
      applyFilters()
    })
    .catch(() => {})
}

// When the user changes the sliders (v1.1.5, refined):
//   1. Long debounce (2.5s) so we don't restart while they fine-tune the slider.
//   2. Threshold: only restart if the range changes significantly. If the
//      change is small (lowering the max from 5000 to 4998, or the min from 100
//      to 102), a local applyFilters() is enough — the pool already discovered
//      contains those artists and the filter trims them correctly. Restarting
//      would throw away 30s of BFS for nothing.
//   3. A big change (e.g. widening the max from 5,000 to 50,000, or moving the
//      min from 0 to 5,000) DOES need a restart because there are new artists
//      the server doesn't look for (because of the passesHeuristic heuristic)
//      that now belong in the filter.
//
// Threshold: any absolute change > 10% of the current range, OR any change that
// WIDENS the range (narrower never needs a restart). We remember the last
// values sent to the server to compare.
function rangeNeedsRestart(min, max, lastMin, lastMax) {
  const range = Math.max(1, lastMax - lastMin)
  const changed = Math.abs(min - lastMin) + Math.abs(max - lastMax)
  const expanded = min < lastMin || max > lastMax
  return changed > range * 0.10 || expanded
}

function scheduleRestart() {
  if (!S.refArtist || !S.discovering) return
  clearTimeout(S.restartTimer)

  // The two ranges the server uses to decide whom it looks for and whom it
  // verifies: moving either of them far enough leaves the crawl running with
  // filters that are no longer the user's.
  const majorChange =
    rangeNeedsRestart(S.spMin, S.spMax, S.lastServerSpMin ?? S.spMin, S.lastServerSpMax ?? S.spMax) ||
    rangeNeedsRestart(S.igMin, S.igMax, S.lastServerIgMin ?? S.igMin, S.lastServerIgMax ?? S.igMax)

  if (!majorChange) return  // fine tuning → a local applyFilters is enough, don't restart

  S.restartTimer = setTimeout(() => {
    if (!S.refArtist) return
    S.lastServerSpMin = S.spMin
    S.lastServerSpMax = S.spMax
    S.lastServerIgMin = S.igMin
    S.lastServerIgMax = S.igMax
    pickArtist(S.refArtist)   // full reset + relaunch the discovery with the new filters
  }, 2500)
}

// ── Artist card ───────────────────────────────────────────────────────────────
function setArtistArea(html) { $('art-area').innerHTML = html; syncActionButtons() }

// v2.1.2 — ID of the last artist PAINTED as a full card. Lets us avoid replacing
// the DOM if "renderArtist" is called with the same artist (typical during a
// search: every IG batch fires several redundant renderArtist calls). Without
// this guard the user sees the card flicker and the Spotify player restarts
// constantly.
let _lastRenderedArtistId = null

// ── Flight of the dismissed card ──────────────────────────────────────────────
// The real node is taken out of the flow and flies where the gesture sent it
// while renderArtist already paints the next one underneath: zero delay in the
// data, and if the user chains shortcuts, each card flies off its own way.
function flyOutCard(dir) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return
  if (parsePanelVisible()) return   // the action came from the gallery: the grid flies there
  const card = document.querySelector('#art-area .art-card')
  if (!card) return
  const r = card.getBoundingClientRect()
  card.remove()
  card.className = 'art-card art-ghost art-ghost--' + dir
  card.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;max-height:none;margin:0`
  document.body.appendChild(card)
  card.addEventListener('animationend', () => card.remove(), { once: true })
  setTimeout(() => card.remove(), 700)   // in case the animation never runs
}

// After a ⌘Z the card comes back from the side it left by. Set by undoLast
// right before renderArtist, which consumes it once.
let _enterDir = null

// The deck: the next artist in the queue peeks out behind the active card.
// Photo only — the data shows up once the card reaches the front.
function deckHTML() {
  const next = S.filtered[S.idx + 1]
  if (!next) return ''
  return `
    <div class="art-deck" data-id="${next.id}">
      ${next.image
        ? `<img class="art-photo" src="${next.image}" alt="" decoding="async" onerror="this.style.display='none'">`
        : `<div class="art-photo-ph">${ini(next.name)}</div>`}
    </div>`
}

function resetFilters() {
  const MAX = 5000000
  const SLIDER_CAP = 50000
  $('sp-min').value = 0
  $('sp-max').value = SLIDER_CAP
  $('sp-min-n').value = 0
  $('sp-max-n').value = MAX
  S.spMin = 0; S.spMax = MAX
  $('ig-min').value = 0
  $('ig-max').value = SLIDER_CAP
  $('ig-min-n').value = 0
  $('ig-max-n').value = MAX
  S.igMin = 0; S.igMax = MAX
  S.countries = []
  renderCountryFilter()
  document.querySelectorAll('.rng-fill').forEach(f => { f.style.left='0%'; f.style.width='100%' })
  if (S.allArtists.length) applyFilters()
}

// The dropdown is filled with the countries the pool ACTUALLY has, with their
// count: choosing blindly among two hundred countries and finding three are
// empty is worse than having no filter. Names come from Intl in the UI's
// language — no dictionary to maintain and no seven translations to write.
let _countryNames = null
function countryName(code) {
  try {
    _countryNames = _countryNames || new Intl.DisplayNames([currentLang()], { type: 'region' })
    return _countryNames.of(code) || code
  } catch (e) { return code }
}

// How many artists in the pool touch each country. It serves two purposes:
// painting the map by density and saying in the list where there's something —
// choosing blindly and finding the country empty is worse than no filter.
function countryCounts() {
  const counts = new Map()
  for (const a of S.allArtists) {
    for (const c of (a.countries || [])) counts.set(c, (counts.get(c) || 0) + 1)
  }
  return counts
}

function renderCountryFilter() {
  const box = $('cty-picked')
  if (!box) return
  const names = S.countries.map(countryName)
  // More than two names don't fit on one line and cutting mid-word says
  // nothing: the first two are named and the rest go as a count.
  const label = !names.length ? t('all_countries')
    : names.length <= 2 ? names.join(', ')
    : `${names.slice(0, 2).join(', ')} +${names.length - 2}`
  box.textContent = label
  box.title = names.join(', ')
  paintMiniMap()
}

function paintMiniMap() {
  const mini = $('cty-mini')
  if (!mini) return
  for (const p of mini.querySelectorAll('path')) p.classList.toggle('on', S.countries.includes(p.dataset.c))
}

function toggleCountry(code) {
  if (!code) return
  const i = S.countries.indexOf(code)
  if (i >= 0) S.countries.splice(i, 1)
  else S.countries.push(code)
  renderCountryFilter()
  syncMapSelection()
  if (S.allArtists.length) applyFilters()
}

// ── Country map ───────────────────────────────────────────────────────────────
//
// The SVG (Natural Earth, public domain, generated by tools/make_world_map.js)
// is fetched once and serves both maps: the filter's thumbnail and the big
// map. No map libraries.
let _worldSvg = null
let _mapLoaded = false
let _mapCounts = new Map()

function loadWorldSvg() {
  // If it fails the promise is forgotten: a rejected one in the cache leaves the
  // map dead forever, and the next attempt costs nothing.
  _worldSvg = _worldSvg || fetch('world.svg').then(r => r.text()).catch(e => { _worldSvg = null; throw e })
  return _worldSvg
}

async function mountMiniMap() {
  const mini = $('cty-mini')
  if (!mini || mini.firstChild) return
  // Without the ids: both maps are the same SVG and two copies of the same id
  // in a page is invalid HTML. The thumbnail only needs data-c.
  try { mini.innerHTML = (await loadWorldSvg()).replace(/ id="c-[^"]*"/g, '') } catch (e) { return }
  paintMiniMap()
}

async function openCountryMap() {
  $('map-overlay').classList.remove('hidden')
  const canvas = $('map-canvas')
  if (!_mapLoaded) {
    canvas.innerHTML = `<div class="loading-row"><div class="spinner"></div><span>${esc(t('loading'))}</span></div>`
    try {
      canvas.innerHTML = await loadWorldSvg()
      _mapLoaded = true
      canvas.addEventListener('click', e => {
        // A drag ends in a click on the country where you let go: moving the
        // map must not select it.
        if (_dragMoved) { _dragMoved = false; return }
        toggleCountry(e.target.closest('path')?.dataset.c)
      })
      canvas.addEventListener('mousemove', moveCountryTip)
      canvas.addEventListener('mouseleave', hideCountryTip)
      canvas.addEventListener('wheel', zoomMap, { passive: false })
      canvas.addEventListener('pointerdown', startMapDrag)
      canvas.addEventListener('pointermove', dragMap)
      canvas.addEventListener('pointerup', endMapDrag)
    } catch (e) {
      canvas.innerHTML = `<div class="px-empty"><p class="empty-sub">${esc(t('toast_network_error'))}</p></div>`
      return
    }
  }
  // Every opening starts with the whole world: coming back and finding
  // yourself inside an old zoom is more disorienting than it saves.
  resetMapView()
  renderCountryList()
  syncMapSelection()
  $('map-search').focus()
}

// ── Map zoom & pan ────────────────────────────────────────────────────────────
//
// The viewBox moves, not a CSS transform: the vector doesn't pixelate, clicks
// still land on the right country and no geometry has to be redone.
const MAX_ZOOM = 12
let _view = null
let _drag = null
let _dragMoved = false

function mapSvg() { return $('map-canvas').querySelector('svg') }

function resetMapView() {
  const svg = mapSvg()
  if (!svg) return
  // The world's measurements are read only once. The viewBox already carries
  // the zoom, and reading it again here would turn the current crop into "the
  // whole world": reopening the map wouldn't undo anything.
  if (!_view) {
    const [, , W, H] = svg.getAttribute('viewBox').split(' ').map(Number)
    _view = { W, H }
  }
  Object.assign(_view, { x: 0, y: 0, w: _view.W, h: _view.H })
  applyMapView()
}

function applyMapView() {
  const v = _view
  // Back at the whole world the exact measurements are restored: otherwise each
  // zoom's rounding accumulates in the aspect ratio.
  if (v.w >= v.W) { v.w = v.W; v.h = v.H; v.x = 0; v.y = 0 }
  // The crop never leaves the world: panning reaches the edge and stops there.
  v.x = Math.min(Math.max(v.x, 0), v.W - v.w)
  v.y = Math.min(Math.max(v.y, 0), v.H - v.h)
  mapSvg().setAttribute('viewBox', `${v.x} ${v.y} ${v.w} ${v.h}`)
  $('map-canvas').classList.toggle('zoomed', v.w < v.W)
}

function zoomMap(e) {
  if (!_view) return
  e.preventDefault()
  // Through the matrix and not a rule of three on the rectangle: if the window
  // is short and the body narrows, the drawing leaves bands and only the matrix
  // knows where the cursor really landed.
  const ctm = mapSvg().getScreenCTM()
  if (!ctm) return
  const pt = new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse())
  const step = Math.min(Math.max(Math.exp(-e.deltaY * 0.0025), 0.5), 2)
  const w = Math.min(Math.max(_view.w / step, _view.W / MAX_ZOOM), _view.W)
  // The real factor is what's left after the caps; height follows width so the
  // aspect ratio doesn't change and the map doesn't stretch.
  const f = w / _view.w
  _view.x = pt.x - (pt.x - _view.x) * f
  _view.y = pt.y - (pt.y - _view.y) * f
  _view.w = w
  _view.h *= f
  applyMapView()
}

function startMapDrag(e) {
  // Cleared before deciding whether there's a drag: otherwise a pan done while
  // zoomed swallows the first click after going back to the whole world.
  _dragMoved = false
  if (!_view || _view.w >= _view.W) return
  _drag = { x: e.clientX, y: e.clientY }
  $('map-canvas').setPointerCapture(e.pointerId)
}

function dragMap(e) {
  if (!_drag) return
  const scale = mapSvg().getScreenCTM()?.a || 1
  const dx = e.clientX - _drag.x
  const dy = e.clientY - _drag.y
  if (Math.abs(dx) + Math.abs(dy) > 3) _dragMoved = true
  _drag.x = e.clientX
  _drag.y = e.clientY
  _view.x -= dx / scale
  _view.y -= dy / scale
  applyMapView()
}

function endMapDrag() { _drag = null }

function closeCountryMap() {
  hideCountryTip()
  $('map-overlay').classList.add('hidden')
}

// The SVG carries no names: at this size they'd overlap each other. The country
// is named on hover, with how many artists there are so nobody chooses blindly.
let _tipCode = null

function moveCountryTip(e) {
  const code = e.target.closest('path')?.dataset.c || null
  if (!code) return hideCountryTip()
  const tip = $('map-tip')
  if (code !== _tipCode) {
    _tipCode = code
    const n = _mapCounts.get(code) || 0
    tip.innerHTML = `${esc(countryName(code))}${n ? `<span class="cty-n">${n}</span>` : ''}`
    tip.classList.remove('hidden')
  }
  const box = tip.parentElement.getBoundingClientRect()
  const x = e.clientX - box.left
  const y = e.clientY - box.top
  // Near the right edge the label would leave the panel: it flips to the other side.
  const left = x + 14 + tip.offsetWidth > box.width ? x - 14 - tip.offsetWidth : x + 14
  tip.style.transform = `translate(${Math.max(0, left)}px, ${Math.max(0, y - tip.offsetHeight - 10)}px)`
}

function hideCountryTip() {
  _tipCode = null
  $('map-tip')?.classList.add('hidden')
}

// Density and selection travel as classes, not per-node styles: there are 236
// countries and repainting them one by one on every click is noticeable.
function syncMapSelection() {
  const counts = _mapCounts = countryCounts()
  const canvas = $('map-canvas')
  // The "many" step is relative to the pool, not a fixed number: in a small
  // search ten artists are already the bulk, in a big one they're noise.
  const busy = Math.max(...counts.values(), 0) / 5
  for (const p of canvas.querySelectorAll('path')) {
    const c = p.dataset.c
    const n = counts.get(c) || 0
    p.classList.toggle('has', n > 0)
    p.classList.toggle('many', n > 0 && n >= busy)
    p.classList.toggle('on', S.countries.includes(c))
  }
  const hint = $('map-hint')
  if (hint) {
    const matching = S.countries.length ? S.allArtists.filter(passesFilters).length : S.allArtists.length
    hint.textContent = S.countries.length
      ? tf('map_hint', '{n} artists match').replace('{n}', matching)
      : tf('map_hint_all', 'No country picked — everything shows')
  }
  for (const row of document.querySelectorAll('#map-list .cty-row')) {
    row.classList.toggle('on', S.countries.includes(row.dataset.c))
  }
}

function renderCountryList() {
  const list = $('map-list')
  if (!list) return
  const counts = countryCounts()
  const q = ($('map-search')?.value || '').trim().toLowerCase()
  const codes = [...$('map-canvas').querySelectorAll('path')].map(p => p.dataset.c)
  const rows = codes
    .map(c => ({ c, name: countryName(c), n: counts.get(c) || 0 }))
    .filter(r => !q || r.name.toLowerCase().includes(q) || r.c.toLowerCase() === q)
    // First where there are artists, and within that by count; the rest
    // alphabetical so they can be found.
    .sort((a, b) => (b.n - a.n) || a.name.localeCompare(b.name))
  list.innerHTML = rows.map(r =>
    `<button class="cty-row${S.countries.includes(r.c) ? ' on' : ''}" data-c="${esc(r.c)}">
       <span>${esc(r.name)}</span>${r.n ? `<span class="cty-n">${r.n}</span>` : ''}
     </button>`).join('')
}

function renderArtist() {
  // v2.1.2 — If we're going back to the empty state, reset the guard.
  if (!S.filtered.length || !S.filtered[S.idx]) {
    _lastRenderedArtistId = null
  }
  if (!S.filtered.length) {
    if (S.discovering) {
      // Adaptive message depending on the search's phase
      const found = S.allArtists.length
      const queue = S.discoverQueue
      let title, sub
      if (found === 0 && queue === 0) {
        title = t('connect_spotify')
        sub = t('connect_spotify_sub')
      } else if (found === 0) {
        title = t('exploring_similar')
        sub = `${queue.toLocaleString()} candidates`
      } else {
        title = t('verifying_ig')
        sub = `${queue.toLocaleString()} pending`
      }
      setArtistArea(`<div class="empty-state"><div class="spinner" style="margin:0 auto 12px"></div><p class="empty-title">${title}</p><p class="empty-sub">${sub}</p></div>`)
      return
    }
    if (S.refArtist) {
      // Discovery has finished. Here we tell apart:
      //   - If we've already SEEN artists (allArtists has content), the ones
      //     that fit the filter ran out / there are no more new ones.
      //   - If allArtists is empty, the filter left everything out or there
      //     aren't any.
      if (S.allArtists.length) {
        const counts = S.allArtists.map(a => a.followers||0).filter(n => n > 0)
        const lo = counts.length ? Math.min(...counts) : 0
        const hi = counts.length ? Math.max(...counts) : 0
        setArtistArea(`
          <div class="empty-state">
            <p class="empty-title">${t('empty_no_more')}</p>
            <p class="empty-sub">${t('empty_no_more_sub')}</p>
            <p class="empty-sub" style="margin-top:8px;opacity:.7">${fmtBig(lo)} – ${fmtBig(hi)} monthly listeners</p>
            <button class="btn-reset-filter" onclick="resetFilters()">${t('empty_reset_filters')}</button>
          </div>`)
      } else if (S.droppedAsSeen) {
        setArtistArea(`
          <div class="empty-state">
            <p class="empty-title">${t('empty_reset_seen')}</p>
            <p class="empty-sub">${t('empty_reset_seen_sub')}</p>
          </div>`)
      } else {
        // Not a single one arrived AND none was dropped as seen: the problem
        // isn't the history but that collecting brought nothing.
        setArtistArea(`
          <div class="empty-state">
            <p class="empty-title">${t('empty_nothing')}</p>
            <p class="empty-sub">${t('empty_nothing_sub')}</p>
            <button class="btn-reset-filter" onclick="openDiscoverStream()">${t('px_run')}</button>
          </div>`)
      }
    } else {
      setArtistArea(`<div class="empty-state"><p class="empty-title">${t('empty_search_start')}</p></div>`)
    }
    return
  }

  const a = S.filtered[S.idx]
  if (!a) {
    setArtistArea(`<div class="empty-state"><p class="empty-title">${t('empty_all_reviewed')}</p><p class="empty-sub">${t('empty_all_reviewed_sub')}</p></div>`)
    return
  }

  // v2.1.2 — If the current artist is the same as the one already painted, we
  // do NOT replace the DOM (avoids the visual "jump" and the player
  // restarting). We only update the dynamic fields:
  //   - IG followers (the number may have just arrived)
  if (_lastRenderedArtistId === a.id) {
    const igFolEl = $(`ig-fol-${a.id}`)
    if (igFolEl && a.igFollowers != null) {
      igFolEl.textContent = fmt(a.igFollowers)
    }
    // Somebody else may be next now (new artists streamed in, filters changed):
    // patch only the deck node, never the card — its player must not restart.
    const stack = document.querySelector('#art-area .art-stack')
    const deck = stack?.querySelector('.art-deck')
    if (stack && deck?.dataset.id !== S.filtered[S.idx + 1]?.id) {
      deck?.remove()
      stack.insertAdjacentHTML('afterbegin', deckHTML())
    }
    // Preloading the next one's IG still makes sense even without a re-render
    for (let i = 1; i <= 2; i++) {
      const next = S.filtered[S.idx + i]
      if (next && next.instagram && next.igFollowers == null) fetchIGFollowers(next)
    }
    return
  }

  // v2.0.2 — We do NOT mark as "seen in history" just because of rendering.
  // We used to, and the history filled up with hundreds of IDs on every search,
  // blocking results in the next one (reported bug: "No more artists to show"
  // with The Kid LAROI even though his graph has thousands of neighbours).
  //
  // Now it's only marked when the user MAKES an explicit DECISION:
  // Skip, Not similar or Save. Artists that just pass across the screen remain
  // available in future searches.
  // See skipArtist(), notSimilar() and saveProspect() below.

  const user = igUsername(a.instagram)
  const igSection = a.instagram
    ? `<a class="art-ig" href="${a.instagram}" target="_blank">
         <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">${ICON.ig}</svg>
         @${esc(user)}
         <span class="art-ig-fol" id="ig-fol-${a.id}">${a.igFollowers != null ? fmt(a.igFollowers) : '–'}</span>
       </a>`
    : `<div class="art-ig art-ig--none">No Instagram linked</div>`

  // v3.0.0 — Priority: soundScore (composite with learning) > soundSim (pure,
  // vs the reference) > popularity. The user sees the number the app filters by.
  const matchVal = a.soundScore != null ? Math.round(a.soundScore * 100) + '%'
                 : a.soundSim   != null ? Math.round(a.soundSim   * 100) + '%'
                 : (a.popularity || null)
  const matchLbl = (a.soundScore != null || a.soundSim != null) ? 'sound match' : 'match'

  // The release goes on its own line: as the meta's third element, when it
  // didn't fit it wrapped dragging its separator along — an orphan dot opening
  // the line.
  const rel = a.latestRelease
  const relLine = rel?.year
    ? `<div class="art-rel"><span>${esc(rel.name || '')}</span> · ${rel.year}</div>`
    : ''
  const meta = [
    `<span class="art-meta-i"><b>${fmt(a.followers)}</b> monthly</span>`,
    matchVal ? `<span class="art-meta-i"><b>${matchVal}</b> ${matchLbl}</span>` : ''
  ].join('')

  // WHERE THEY'RE LISTENED TO, not where they're from: the owner knows an
  // artist with Lagos as top city who is American. That's why the chip has
  // headphones and not a map pin, and the title spells it out.
  const citySection = cityChip(a.topCity)

  // v3.1 — The card IS the photo, as in the gallery below: the same language on
  // both screens. The info sits on the bottom gradient; no controls of its own
  // — the jump to Spotify already lives in the player above.
  setArtistArea(`
    <div class="art-stack">
      ${deckHTML()}
      <div class="art-card">
        ${a.image
          ? `<img class="art-photo" src="${a.image}" alt="" decoding="async" onerror="this.style.display='none'">`
          : `<div class="art-photo-ph">${ini(a.name)}</div>`}
        <div class="art-ov">
          <h2 class="art-name">${esc(a.name)}</h2>
          <div class="art-meta">${meta}</div>
          ${relLine}
          <div class="art-row">
            ${igSection}
            ${citySection}
          </div>
        </div>
      </div>
    </div>`)
  _lastRenderedArtistId = a.id   // v2.1.2 — mark as the last one painted
  if (_enterDir) {
    document.querySelector('#art-area .art-card')?.classList.add('art-card--from-' + _enterDir)
    _enterDir = null
  }

  // The artist's own background: their Spotify banner, with the avatar as a
  // fallback for those without one (Spotify doesn't always give headerImage).
  setReviewBg(a.banner || a.image || null)
  prefetchBanners(S.idx)

  playSpotifyArtist(a.id)

  // Verify the current one's IG followers + preload the next 2 in the queue
  if (a.instagram && a.igFollowers == null) fetchIGFollowers(a)
  for (let i = 1; i <= 2; i++) {
    const next = S.filtered[S.idx + i]
    if (next && next.instagram && next.igFollowers == null) fetchIGFollowers(next)
  }
}

// ── Player ────────────────────────────────────────────────────────────────────
//
// v2.1.1 — Auto-play when the artist changes.
//
// Before: a static Spotify iframe embed. Changing artist updated the iframe's
//         src, but the user had to press play by hand for each one. Annoying
//         when you review 100 artists in a row.
//
// Now: we use the Spotify iFrame API (script loaded in index.html), which
//      exposes an EmbedController with programmatic loadUri() + play().
//      There's no longer a button to turn it on: whoever reviews artists one by
//      one wants to hear them, so the preview always lives in the top dock and
//      is fed by both the review and the gallery. To stop it, Spotify's own
//      embed.
let _spotifyController = null       // the EmbedController instance
let _spotifyApiReady = false        // true when the global script has loaded
let _pendingUriToLoad = null        // buffer in case the user changes before the API loads
let _apiPoll = null                 // poll waiting for Spotify's script

// The player belongs to the results screen, and EVERY audio start goes through
// here: the three that play late — the play() deferred 150ms, the controller
// that finishes being created and the API poll — fire when the user may already
// be back on search, i.e. AFTER showSearch's pause(). Checking only on entry
// left the preview playing over the home screen.
const playerAllowed = () => $('scr-results').classList.contains('active')
const safePlay = () => {
  if (!playerAllowed() || !_spotifyController) return
  try { _spotifyController.play() } catch (e) {}
}

// Immediate silence and cancelling whatever was about to play on its own.
function silencePlayer() {
  if (_apiPoll) { clearInterval(_apiPoll); _apiPoll = null }
  _pendingUriToLoad = null
  try { _spotifyController?.pause() } catch (e) {}
}

// Callback Spotify calls automatically when its script has loaded
window.onSpotifyIframeApiReady = (IFrameAPI) => {
  _spotifyApiReady = true
  window._SpotifyIFrameAPI = IFrameAPI
}

function createSpotifyController(uri) {
  if (!_spotifyApiReady || !window._SpotifyIFrameAPI) return
  const el = document.getElementById('spotify-embed')
  if (!el) return
  const options = {
    uri: uri,
    width: '100%',
    height: 80
  }
  window._SpotifyIFrameAPI.createController(el, options, (controller) => {
    _spotifyController = controller
    // Creating the controller takes a while: if the user went back to search
    // meanwhile, it stays created but muted.
    safePlay()
    // If the user changed artist while the controller was still being created,
    // apply the last pending URI.
    if (_pendingUriToLoad && _pendingUriToLoad !== uri) {
      try { controller.loadUri(_pendingUriToLoad) } catch (e) {}
      safePlay()
      _pendingUriToLoad = null
    }
  })
}

// v2.1.2 (Bug fix) — Keep the last URI loaded so loadUri() isn't called with the
// same URI twice (that restarted the song every time).
let _lastLoadedUri = null

function playSpotifyArtist(artistId) {
  if (!artistId) return
  // renderArtist keeps being called after going back to search — fired by the
  // stream's queue and the Instagram batches, which run on their own — and
  // without this guard the player reappeared floating over the home screen.
  if (!playerAllowed()) return
  showDock()
  syncDockNotch()
  $('dock-island').classList.remove('hidden', 'paused')
  markPlayingCard(artistId)
  document.querySelector('.gcard--paused')?.classList.remove('gcard--paused')
  const uri = `spotify:artist:${artistId}`
  // If the requested URI is ALREADY loaded, do nothing — the song keeps playing
  // calmly without restarting.
  if (uri === _lastLoadedUri) return
  _lastLoadedUri = uri
  if (_spotifyController) {
    // There's already a controller — change the URI and auto-play
    try {
      _spotifyController.loadUri(uri)
      // loadUri usually auto-plays after a small internal delay.
      // We call play() at 150ms just in case — safePlay because in those
      // 150ms the user has time to go back to search.
      setTimeout(safePlay, 150)
    } catch (e) {
      console.warn('[player] loadUri failed:', e)
    }
  } else if (_spotifyApiReady) {
    // API loaded but controller not created → create it with this URI
    createSpotifyController(uri)
  } else {
    // API not loaded yet → keep it for when it is
    _pendingUriToLoad = uri
    // Poll until the API loads (typically <1s after DOMContentLoaded).
    // Kept in _apiPoll so showSearch can cancel it: otherwise the poll stayed
    // alive up to 10s and created the controller — which auto-plays — with the
    // user already out of the results.
    if (_apiPoll) clearInterval(_apiPoll)
    _apiPoll = setInterval(() => {
      if (!_spotifyApiReady) return
      clearInterval(_apiPoll); _apiPoll = null
      if (playerAllowed()) createSpotifyController(_pendingUriToLoad || uri)
    }, 100)
    // Safety timeout
    setTimeout(() => { if (_apiPoll) { clearInterval(_apiPoll); _apiPoll = null } }, 10000)
  }
}

// Marks in the gallery which card is playing. The id is kept because the grid
// is rebuilt entirely and the state has to be repainted after every render.
let _playingId = null
function markPlayingCard(artistId) {
  _playingId = artistId
  document.querySelectorAll('#px-grid .gcard--playing').forEach(el => el.classList.remove('gcard--playing'))
  document.querySelector(`#px-grid .gcard[data-id="${artistId}"]`)?.classList.add('gcard--playing')

  // Content of the pill, which is the only visible part of the player in stage 2
  const a = parseList().find(x => x.id === artistId) || S.filtered.find(x => x.id === artistId)
  const img = a?.image || a?.spotify_image
  $('di-name').textContent = a?.name || ''
  $('di-img').style.backgroundImage = img ? `url("${img}")` : ''
  $('di-img').textContent = img ? '' : ini(a?.name || '')
}

// The button on the card that's already playing acts as play/pause: in stage 2
// the player is collapsed and its controls can't be reached.
function togglePreview(artistId) {
  if (artistId !== _playingId || !_spotifyController) { playSpotifyArtist(artistId); return }
  const card = document.querySelector(`#px-grid .gcard[data-id="${artistId}"]`)
  const paused = card?.classList.toggle('gcard--paused')
  $('dock-island').classList.toggle('paused', !!paused)
  try { paused ? _spotifyController.pause() : _spotifyController.resume() } catch (e) {}
}

// ── The player's notch in the gallery ─────────────────────────────────────────
// Stage 1 = you just moved down to the gallery (list not yet scrolled): the grid
// reserves a band at the top and the COLUMNS not under the player move up to
// fill it — all their rows, not just the first, so the channel stays straight.
// Stage 2 = you're already in the list: the player moves up to the edge and
// collapses into a pill, and the raised columns go back down to their place.
// See .gcard--lift, .player-dock.gone and .dock-island in styles.css.
const PX_STAGE2_AT = 28
let _pxStage = 1

function syncPxStage(force) {
  const body = $('px-body')
  const stage = body.scrollTop > PX_STAGE2_AT ? 2 : 1
  if (stage === _pxStage && !force) return
  _pxStage = stage
  body.classList.toggle('stage-2', stage === 2)
  const folded = stage === 2 && parsePanelVisible()
  $('player-dock').classList.toggle('gone', folded)
  $('dock-island').classList.toggle('show', folded)
}

// Going up to the review: with mandatory scroll-snap the browser demands a long
// gesture to unstick from the panel, and going back up felt stiff. With the
// list scrolled all the way up, one deliberate push switches screens — but it
// has to be ONE gesture: if the wheel events arrive spaced out the count
// restarts, so a slow brush doesn't end up adding up to the threshold.
const UP_EXIT_PX = 110
const UP_EXIT_GAP_MS = 220
const UP_EXIT_LOCK_MS = 700
let _upAccum = 0
let _upLastAt = 0
let _upLockUntil = 0

function onGalleryWheel(e) {
  if (!parsePanelVisible() || S.savedOnly) return   // with no review above there's nowhere to go
  if (e.deltaY >= 0 || $('px-body').scrollTop > 0) { _upAccum = 0; return }
  e.preventDefault()                       // we handle the gesture ourselves
  const now = Date.now()
  if (now < _upLockUntil) return           // trackpad inertia doesn't relaunch it
  if (now - _upLastAt > UP_EXIT_GAP_MS) _upAccum = 0
  _upLastAt = now
  _upAccum -= e.deltaY
  if (_upAccum < UP_EXIT_PX) return
  _upAccum = 0
  _upLockUntil = now + UP_EXIT_LOCK_MS
  scrollToReview()
}

// Which grid columns are free of the player. Resolved by COLUMN and not by
// measuring card by card: measuring each card meant touching the DOM after
// painting it, and with the stream repainting every second that was exactly
// what made the side ones flicker and jump.
//
// The player has NO fixed width here: it covers a central run of columns and
// stretches to fill it entirely. With a fixed width there were two dead strips
// on its sides — no cards fit there and it didn't cover them.
const DOCK_MIN_W = 400

function notchPlan() {
  const dock = $('player-dock'), grid = $('px-grid')
  // dockIsOut also covers the fade-out: the columns start going down at the
  // same time the player leaves, not once it has disappeared.
  if (dockIsOut() || !innerWidth) return null

  const cs = getComputedStyle(grid)
  const cols = cs.gridTemplateColumns.split(' ').map(parseFloat).filter(w => w > 0)
  if (cols.length < 3) return null   // with two columns there's no channel to open

  const gap = parseFloat(cs.columnGap) || 0
  const lefts = []
  let x = grid.getBoundingClientRect().left + parseFloat(cs.paddingLeft)
  cols.forEach(w => { lefts.push(x); x += w + gap })
  const rightOf = i => lefts[i] + cols[i]

  // The shortest run that gives it a usable width, always centred. Never the
  // whole row: without free columns there'd be no notch.
  for (let span = cols.length % 2 ? 1 : 2; span < cols.length; span += 2) {
    const a = (cols.length - span) >> 1
    const width = rightOf(a + span - 1) - lefts[a]
    if (width < DOCK_MIN_W) continue
    const free = new Set()
    cols.forEach((_, i) => { if (i < a || i >= a + span) free.add(i) })
    return { n: cols.length, free, width: Math.round(width) }
  }
  return null
}

// The plan's key, so the gallery isn't repainted when nothing changed. The
// width is quantised to 16px: in exact pixels, every tick of a resize would
// change the key and rebuild the whole grid mid-drag — the fine width is applied
// by syncDockPlacement without repainting.
let _notchKey = ''
function notchKeyOf(plan) { return plan ? `${plan.n}:${Math.round(plan.width / 16)}:${[...plan.free].join(',')}` : '' }

// The widening and the drop only apply in the gallery: up top there's no shelf
// to dodge and the player is the same width as the card (--dock-w).
function syncDockPlacement(plan) {
  const dock = $('player-dock')
  const inList = parsePanelVisible()
  dock.classList.toggle('in-list', inList)
  dock.style.width = (plan && inList) ? plan.width + 'px' : ''
}

// Off screen means both `hidden` and the fade-out: the shelf the player
// reserves at the top has to close WITH it, not 300 ms later.
function dockIsOut() {
  const cl = $('player-dock').classList
  return cl.contains('hidden') || cl.contains('dock-off')
}

function syncDockNotch() {
  document.body.classList.toggle('has-dock', !dockIsOut())
  applyNotch(notchPlan())
}

// The notch is ONLY classes. Before, if the plan changed, this called
// renderParse: the grid was rebuilt through innerHTML and the cards were born
// already moved aside — the player's channel didn't open, it appeared open all
// at once. Touching the class on the nodes already there, .gcard's transform
// transitions and the columns move aside as the player comes in.
function applyNotch(plan) {
  _notchKey = notchKeyOf(plan)
  const cards = document.querySelectorAll('#px-grid .gcard')
  // No cards, no band to reserve: the empty-gallery notice has no reason to
  // drop 144px to dodge a player that isn't covering anything.
  $('px-body').classList.toggle('has-dock', !!plan && cards.length > 0)
  syncDockPlacement(plan)
  cards.forEach((el, i) => el.classList.toggle('gcard--lift', !!plan && plan.free.has(i % plan.n)))
}

// Entering and leaving are transitions too: the player appeared with a
// display:block — out of nowhere and already in place — which was the most
// visible jerk on the screen. `.hidden` is kept for when it really must take no
// space, but it is now set at the end of the fade, not at the start.
const DOCK_FADE_MS = 300
let _dockHideT = null

function showDock() {
  const dock = $('player-dock')
  clearTimeout(_dockHideT)
  if (!dock.classList.contains('hidden') && !dock.classList.contains('dock-off')) return
  dock.classList.add('dock-off')
  dock.classList.remove('hidden')
  void dock.offsetWidth   // without the reflow the browser sees a single state and animates nothing
  dock.classList.remove('dock-off')
}

function hideDock() {
  const dock = $('player-dock')
  if (dock.classList.contains('hidden')) return
  dock.classList.add('dock-off')
  clearTimeout(_dockHideT)
  _dockHideT = setTimeout(() => dock.classList.add('hidden'), DOCK_FADE_MS)
}

// ── Bulk actions ──────────────────────────────────────────────────────────────
function exportDiscoveredCSV() {
  const list = parseList()
  if (!list.length) { toast(t('toast_no_export'), 'err'); return }
  const hdr = ['Name','Monthly Listeners','Instagram','IG Followers','Latest Release','Release Year','Spotify URL']
  // The year goes in its own column: stuck to the title in the same cell it
  // can't be sorted or filtered in a spreadsheet.
  const rows = list.map(a => {
    const rel = a.latestRelease || a.latest_release || null
    return [
      a.name,
      a.followers ?? a.spotify_followers ?? 0,
      a.instagram || a.instagram_handle || '',
      a.igFollowers ?? a.instagram_followers ?? '',
      rel?.name || '',
      rel?.year || '',
      a.url || a.spotify_url || ''
    ].map(v => `"${String(v ?? '').replace(/"/g,'""')}"`)
  })
  const csv = [hdr.join(','), ...rows.map(r => r.join(','))].join('\n')
  const el = document.createElement('a')
  el.href = URL.createObjectURL(new Blob([csv], {type:'text/csv'}))
  el.download = `artists-${(S.refArtist?.name||'discovery').replace(/\s+/g,'-')}-${new Date().toISOString().split('T')[0]}.csv`
  el.click()
  offerContacted(list, 'ask_exported', `${list.length} ${t('toast_exported')}`)
}

// "⧉ Instagram" — the real use case is pasting the list into an outreach tool,
// not opening profiles one by one.
async function copyIGHandles() {
  // Artist and handle travel together: the offer to mark them has to land
  // exactly on the ones that ended up in the clipboard, not the whole list
  // (those without Instagram aren't copied).
  const rows = parseList()
    .map(a => ({ a, handle: igUsername(a.instagram) || String(a.instagram_handle || '').replace('@','') }))
    .filter(r => r.handle)
  if (!rows.length) { toast(t('toast_no_ig_list'), 'err'); return }
  try {
    await navigator.clipboard.writeText(rows.map(r => r.handle).join('\n'))
  } catch (e) {
    toast(t('toast_network_error'), 'err')
    return
  }
  offerContacted(rows.map(r => r.a), 'ask_copied', `${rows.length} ${t('toast_copied')}`)
}

// Copying or exporting is the step before messaging them, so instead of a toast
// that only informs, we offer to close the loop. In the found pool nobody is in
// the database yet, so marking them means saving them: the button says so
// instead of doing it behind the user's back.
function offerContacted(list, key, doneMsg) {
  if (S.pxTab !== 'saved') {
    if (!list.length) { toast(doneMsg); return }
    ask(askText(key + '_found', list.length), tf('ask_save_mark', 'Save & mark'), () => saveAndContact(list))
    return
  }
  const ids = contactableIds(list)
  if (!ids.length) { toast(doneMsg); return }
  ask(askText(key, list.length), tf('ask_mark', 'Mark'), () => markContactedBatch(ids))
}

const askText = (key, n) => tf(key, '{n} · mark as contacted?').replace('{n}', n)

function contactableIds(list) {
  if (S.pxTab !== 'saved') return []
  return list.filter(a => a.status !== 'contacted').map(a => a.id)
}

async function saveAllToDB() {
  const artists = parseList()
  if (!artists.length) { toast(t('toast_no_save'), 'err'); return }
  const btn = $('btn-save-all')
  btn.dataset.saving = '1'
  btn.disabled = true
  const orig = btn.textContent
  btn.textContent = `Saving 0/${artists.length}…`
  const CHUNK = 50
  let added = 0, updated = 0, failed = 0
  for (let i = 0; i < artists.length; i += CHUNK) {
    btn.textContent = `Saving ${Math.min(i+CHUNK, artists.length)}/${artists.length}…`
    const chunk = artists.slice(i, i + CHUNK)
    try {
      const res = await api.bulkSaveArtists(chunk, S.refArtist?.name || null)
      if (res.success) { added += res.added || 0; updated += res.updated || 0 }
      else failed += chunk.length
    } catch(e) { failed += chunk.length }
  }
  btn.dataset.saving = ''
  btn.textContent = orig
  btn.disabled = false
  toast(`${added} saved${updated ? `, ${updated} updated` : ''}${failed ? `, ${failed} failed` : ''}`)
  await refreshSaved()
}

// ── Undo / redo ───────────────────────────────────────────────────────────────
// Skip, Not similar and Save take the artist out of the pool forever. One click
// too many lost it, so every action notes what has to be reverted and the
// position it was in.
const UNDO_MAX = 50
const _undoStack = []
const _redoStack = []
let _replaying = false

function pushUndo(entry) {
  if (_replaying) return          // redoing doesn't create a new entry
  _undoStack.push(entry)
  if (_undoStack.length > UNDO_MAX) _undoStack.shift()
  _redoStack.length = 0
}

// The counterpart of markSeen: if it isn't forgotten on the server too, the
// artist comes back now but disappears in the next session.
function forgetSeen(id) {
  _seenBuffer.delete(id)
  if (S.persistentSeen) S.persistentSeen.delete(id)
  fetch('/api/seen/forget', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ids: [id] })
  }).catch(() => {})
}

// Returns a batch's artists to the pool. They're reinserted in ASCENDING index
// order: by the time slot 7 is reached, 3 is already back, so each one lands
// where it was.
function restoreBatch(items) {
  for (const { artist, idx } of items) {
    if (S.skippedIds) S.skippedIds.delete(artist.id)
    forgetSeen(artist.id)
    if (!S.allArtistIds.has(artist.id)) { S.allArtists.push(artist); S.allArtistIds.add(artist.id) }
    S.filtered.splice(Math.min(idx, S.filtered.length), 0, artist)
  }
}

async function undoLast() {
  const e = _undoStack.pop()
  if (!e) { toast(tf('toast_nothing_undo', 'Nothing to undo')); return }

  // "Contacted" doesn't move anyone: only the field has to be restored.
  if (e.kind === 'contacted') {
    await api.updateArtist(e.artist.id, { status: e.prev.status, contacted_at: e.prev.contacted_at })
    _redoStack.push(e)
    armGridMorph()
    await refreshSaved()
    toast(`${tf('toast_undone', 'Undone')} — ${e.artist.name}`)
    return
  }

  // A batch goes back in groups by previous status — almost always just one —
  // instead of one PATCH per artist: marking two hundred and undoing it was two
  // hundred database writes.
  if (e.kind === 'contacted_batch') {
    const groups = new Map()
    for (const it of e.items) {
      const key = `${it.prev.status}|${it.prev.contacted_at || ''}`
      if (!groups.has(key)) groups.set(key, { prev: it.prev, ids: [] })
      groups.get(key).ids.push(it.id)
    }
    for (const g of groups.values()) await setBulkStatus(g.ids, g.prev.status, g.prev.contacted_at)
    _redoStack.push(e)
    armGridMorph()
    await refreshSaved()
    toast(`${tf('toast_undone', 'Undone')} — ${e.items.length}`)
    return
  }

  if (e.kind === 'batch') {
    if (e.op === 'save') {
      for (const { artist } of e.items) await api.deleteArtist(artist.id)
      await refreshSaved()
    }
    restoreBatch(e.items)
    _redoStack.push(e)
    armGridMorph()
    renderArtist(); updateContext(); renderParse()
    toast(`${tf('toast_undone', 'Undone')} — ${e.items.length}`)
    return
  }

  const a = e.artist
  if (S.skippedIds) S.skippedIds.delete(a.id)
  if (S.dislikedNeighbors) S.dislikedNeighbors.delete(a.id)
  forgetSeen(a.id)
  // The undone gesture's vote is withdrawn from the global pool — a cancelled
  // skip or not-similar must not keep sinking its neighbourhood.
  sendVote(a.id, 'unvote')
  if (e.kind === 'save') {
    await api.deleteArtist(a.id)
    await refreshSaved()
  }
  if (!S.allArtistIds.has(a.id)) {
    S.allArtists.push(a)
    S.allArtistIds.add(a.id)
  }
  S.idx = Math.min(e.idx, S.filtered.length)
  S.filtered.splice(S.idx, 0, a)

  _redoStack.push(e)
  _enterDir = { skip: 'left', nosim: 'down', save: 'right' }[e.kind] || null
  armGridMorph()
  renderArtist(); updateContext(); renderParse()
  toast(`${tf('toast_undone', 'Undone')} — ${a.name}`)
}

// Redo = repeat the same action on the same artist. The index is placed on it
// and the original action is called, so its logic isn't duplicated (server
// notices, neighbourhood learning, saving).
async function redoLast() {
  const e = _redoStack.pop()
  if (!e) { toast(tf('toast_nothing_redo', 'Nothing to redo')); return }

  if (e.kind === 'contacted') {
    _replaying = true
    try { await contacted(e.artist.id) } finally { _replaying = false }
    _undoStack.push(e)
    return
  }

  if (e.kind === 'contacted_batch') {
    if (!await setBulkStatus(e.items.map(i => i.id), 'contacted')) return
    _undoStack.push(e)
    armGridMorph()
    await refreshSaved()
    return
  }

  if (e.kind === 'batch') {
    if (e.op === 'save') {
      const res = await api.bulkSaveArtists(e.items.map(i => i.artist), S.refArtist?.name || null)
      if (!res?.success) { toast(res?.error || t('toast_error_saving'), 'err'); return }
      await refreshSaved()
    }
    applyBatchDrop(e.items)
    _undoStack.push(e)
    armGridMorph()
    renderArtist(); updateContext(); renderParse()
    return
  }

  const at = S.filtered.findIndex(x => x.id === e.artist.id)
  if (at < 0) return
  S.idx = at
  _replaying = true
  try {
    if (e.kind === 'skip') skipArtist()
    else if (e.kind === 'nosim') await notSimilar()
    else await saveProspect()
  } finally { _replaying = false }
  _undoStack.push(e)
}

// Takes an artist out of the pool without moving the card the user is looking
// at: it's discarded the same way from the review and from the gallery. It
// learns LITTLE, on purpose: a skip weighs -0.15 in the global pool of votes —
// ten skips in a pocket sink it like a not-similar, a single one barely grazes
// it. ⌘Z withdraws it completely ('unvote').
function dropFromPool(a) {
  const at = S.filtered.findIndex(x => x.id === a.id)
  if (at < 0) return false
  pushUndo({ kind: 'skip', artist: a, idx: at })
  sendVote(a.id, 'skip')
  S.filtered.splice(at, 1)
  S.allArtists = S.allArtists.filter(x => x.id !== a.id)
  S.allArtistIds.delete(a.id)   // v2.0.5 keep the Set in sync
  if (S.skippedIds) S.skippedIds.add(a.id)
  markSeen(a.id)   // v2.0.2 — an explicit user decision → do mark the history
  if (S.idx > at) S.idx--
  if (S.idx >= S.filtered.length) S.idx = Math.max(0, S.filtered.length - 1)
  renderArtist()
  updateContext()
  return true
}

function skipArtist() {
  const a = S.filtered[S.idx]
  if (!a) return
  flyOutCard('left')
  if (dropFromPool(a)) toast(`${a.name} — ${tf('toast_undo_hint', 'skipped, ⌘Z to undo')}`)
}

async function notSimilar() {
  if (!S.filtered.length) return
  const a = S.filtered[S.idx]
  if (!a) return
  flyOutCard('down')
  pushUndo({ kind: 'nosim', artist: a, idx: S.idx })
  // Anti-repeat shield: the ID itself goes into the Set IMMEDIATELY
  if (S.dislikedNeighbors) S.dislikedNeighbors.add(a.id)
  if (S.skippedIds) S.skippedIds.add(a.id)
  markSeen(a.id)   // v2.0.2 — an explicit decision → do mark the history
  S.filtered.splice(S.idx, 1)
  S.allArtists = S.allArtists.filter(x=>x.id!==a.id)
  S.allArtistIds.delete(a.id)   // v2.0.5
  if (S.idx >= S.filtered.length) S.idx = Math.max(0, S.filtered.length-1)
  renderArtist()
  toast(`${a.name} ${t('toast_removed')}`)

  // Tell the server RIGHT NOW with the artist's own ID, so it doesn't send it
  // again even if the related-ids fetch takes a while.
  if (S.discoverSessionId) {
    fetch('/api/session-dislike', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: S.discoverSessionId, ids: [a.id] })
    }).catch(() => {})

    // v2.3.0 — Active-learning feedback: the rejection sinks its region
    sendVote(a.id, 'not-similar')
  }

  // STRONG learning: kills the rejected artist's extended neighbourhood (3 hops).
  // Fire-and-forget so the user can keep reviewing without waiting.
  fetch(`/api/related-ids?threeHops=1&id=${encodeURIComponent(a.id)}`)
    .then(r => r.json())
    .then(({ ids }) => {
      if (!Array.isArray(ids) || !ids.length) return

      // BUG A fix (v1.1.5): protects the artist the user is looking at RIGHT
      // NOW from being removed automatically by neighbourhood. If N+1 happens to
      // be 3 hops from the rejected one, we don't want it to vanish before the
      // user has decided. The learning still applies to ALL the other
      // neighbours.
      const currentId = S.filtered[S.idx]?.id

      let added = 0
      const idsForServer = []
      for (const id of ids) {
        if (!id) continue
        if (id === currentId) continue                    // temporary whitelist
        if (S.dislikedNeighbors.has(id)) continue
        S.dislikedNeighbors.add(id); added++
        idsForServer.push(id)
      }
      if (added) {
        applyFilters()   // clears the ones already in the visible pool
        // Tell the server so it ALSO doesn't send us more of that neighbourhood
        if (S.discoverSessionId) {
          fetch('/api/session-dislike', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId: S.discoverSessionId, ids: idsForServer })
          }).catch(() => {})
        }
      }
    }).catch(() => {})
}

async function saveProspect() {
  if (!S.filtered.length) return
  if (S.savingProspect) return
  const a = S.filtered[S.idx]
  if (!a) return
  S.savingProspect = true
  try {
    const res = await api.saveArtist({...a, referenceArtist: S.refArtist?.name||null})
    console.log('[saveProspect] respuesta server:', res)
    if (res && res.success) {
      flyOutCard('right')
      toast(`${a.name} ${t('toast_saved')}`)
      pushUndo({ kind: 'save', artist: a, idx: S.idx })
      markSeen(a.id)   // v2.0.2 — an explicit decision → do mark the history

      // v2.3.0 — Positive feedback: the save lifts its region
      sendVote(a.id, 'save')
      // Take it out of the pool and move on
      S.filtered.splice(S.idx, 1)
      S.allArtists = S.allArtists.filter(x=>x.id!==a.id)
      S.allArtistIds.delete(a.id)   // v2.0.5
      if (S.idx >= S.filtered.length) S.idx = Math.max(0, S.filtered.length-1)
      renderArtist()
      // v2.0.6 (Bug 21) — local state is up to date BEFORE moving on: if the
      // user goes to Saved right after the save, they see the record. This used
      // to re-download the whole database on every ⌘→; now it grafts in the
      // record the server returns.
      upsertSavedLocal(res.record)

      // Positive learning: fire-and-forget so the flow isn't blocked.
      // BUG A fix (v1.1.5): the same temporary whitelist as in notSimilar for
      // symmetry — stops applyFilters' reorder from moving the focus when the
      // response arrives if, by a race, the user is already viewing the next one.
      fetch(`/api/related-ids?id=${encodeURIComponent(a.id)}`)
        .then(r => r.json())
        .then(({ ids }) => {
          if (!Array.isArray(ids) || !ids.length) return
          const currentId = S.filtered[S.idx]?.id
          let added = 0
          for (const id of ids) {
            if (!id) continue
            if (id === currentId) continue
            if (S.likedNeighbors.has(id)) continue
            S.likedNeighbors.add(id); added++
          }
          if (added) applyFilters()
        }).catch(() => {})
    } else {
      console.error('[saveProspect] server rejected:', res)
      toast((res && res.error) || t('toast_error_saving'), 'err')
    }
  } catch(e) {
    console.error('[saveProspect] exception:', e)
    toast(t('toast_network_save'), 'err')
  } finally {
    S.savingProspect = false
  }
}

// ── Parse screen ──────────────────────────────────────────────────────────────
// The gallery below. Two tabs over the same card component:
//   found — the live pool of the current discovery (the one that can be "parsed")
//   saved — the prospects already saved, which replace the old Database
const ICON = {
  spotify: '<circle cx="12" cy="12" r="9"/><path d="M7.6 10.4c2.9-.9 6.2-.7 8.6.8"/><path d="M8.4 13.6c2.3-.7 4.8-.5 6.7.7"/>',
  ig:      '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="3.6"/><circle cx="16.9" cy="7.1" r="1"/>',
  save:    '<path d="M12 5v14"/><path d="M5 12h14"/>',
  check:   '<path d="M20 6 9 17l-5-5"/>',
  edit:    '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  trash:   '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/>'
}
const gicon = (name, cls, action, id, label) =>
  `<button class="gbtn ${cls||''}" data-act="${action}" data-id="${esc(id)}" title="${esc(label)}" aria-label="${esc(label)}">
     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[name]}</svg>
   </button>`

// What the gallery shows. In Saved the two filters add up: the open folder and
// the search the artist came from.
function parseList() {
  if (S.pxTab !== 'saved') return S.filtered
  if (S.folderId == null) return savedUnderFilters()
  return savedUnderFilters().filter(a => (a.folder_id || null) === S.folderId)
}

// The saved artists that pass the bar's filters: which search they came from
// and whether they've been contacted. Folders count over this, not the total:
// with a filter on, a "3" that shows a single one when opened is worse than no
// number.
function savedUnderFilters() {
  let list = S.savedArtists
  if (S.refFilter != null) list = list.filter(a => (a.reference_artist || '') === S.refFilter)
  if (S.statusFilter === 'contacted') list = list.filter(a => a.status === 'contacted')
  else if (S.statusFilter === 'pending') list = list.filter(a => a.status !== 'contacted')
  return list
}

// Filter by reference artist. The options come from what's saved, so the list
// is rebuilt on every refresh.
function renderRefFilter() {
  const sel = $('ref-filter')
  if (!sel) return
  sel.classList.toggle('hidden', S.pxTab !== 'saved')
  if (S.pxTab !== 'saved') return

  const refs = [...new Set(S.savedArtists.map(a => a.reference_artist || ''))].sort((a, b) => a.localeCompare(b))
  const label = r => r || tf('ref_none', 'No reference')
  sel.innerHTML = `<option value="">${esc(tf('ref_all', 'All searches'))}</option>` +
    refs.map(r => `<option value="${esc(r)}"${S.refFilter === r ? ' selected' : ''}>${esc(label(r))}</option>`).join('')
  // The saved filter may have been left without artists after a deletion.
  if (S.refFilter != null && !refs.includes(S.refFilter)) { S.refFilter = null; sel.value = '' }
}

// The status filter does have fixed options: it only has to show in Saved and
// stay where the user put it after every repaint.
function renderStatusFilter() {
  const sel = $('status-filter')
  if (!sel) return
  sel.classList.toggle('hidden', S.pxTab !== 'saved')
  sel.value = S.statusFilter || ''
}

function syncParseTabs() {
  const saved = S.pxTab === 'saved'
  document.querySelectorAll('#px-tabs .seg-b').forEach(el =>
    el.classList.toggle('active', el.dataset.tab === S.pxTab))
  // "Save all" only makes sense over what was found: in Saved they're all there already.
  $('btn-save-all').style.display = saved ? 'none' : ''
  // Coming in through the pool there's no live pool to collect and no tabs to offer.
  $('px-tabs').classList.toggle('hidden', S.savedOnly)
  $('px-run').classList.toggle('hidden', runChipHidden())
  renderFolders()
  renderRefFilter()
  renderStatusFilter()
  syncBulkChips()
}

// Decided in one place because two apply it: syncParseTabs when switching tab
// and updateContext when collecting starts or stops.
function runChipHidden() {
  return S.savedOnly || (S.pxTab === 'saved' && !S.discovering)
}

// The three buttons on the right work over parseList(), so their state can't
// depend on there being a reference artist (in the pool there isn't one).
function syncBulkChips() {
  const list = parseList()
  $('btn-exp-csv').disabled = !list.length
  $('btn-save-all').disabled = !list.length || $('btn-save-all').dataset.saving === '1'
  $('btn-copy-ig').disabled = !list.some(a => a.instagram || a.instagram_handle)
}

// ── Carpetas ──────────────────────────────────────────────────────────────────
async function loadFolders() {
  try {
    const r = await (await fetch('/api/folders')).json()
    S.folders = (r.success && Array.isArray(r.folders)) ? r.folders : []
  } catch (e) { S.folders = [] }
  renderFolders()
}

function folderCount(id) {
  return savedUnderFilters().filter(a => (a.folder_id || null) === id).length
}

function renderFolders() {
  const rail = $('fold-rail')
  if (!rail) return
  rail.classList.toggle('hidden', S.pxTab !== 'saved')
  if (S.pxTab !== 'saved') return

  const chip = (id, label, n) =>
    `<button class="fold${(S.folderId ?? null) === id ? ' active' : ''}" data-fold="${id == null ? '' : esc(id)}">${esc(label)} <b>${n}</b></button>`

  const parts = [chip(null, tf('folder_all', 'All'), savedUnderFilters().length)]
  for (const f of S.folders) {
    parts.push(chip(f.id, f.name, folderCount(f.id)))
    if (S.folderId === f.id) parts.push(
      `<button class="fold-del" data-fold-del="${esc(f.id)}" title="${esc(tf('folder_del', 'Delete folder'))}" aria-label="${esc(tf('folder_del', 'Delete folder'))}">
         <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
       </button>`)
  }
  parts.push(`<button class="fold fold--new" data-fold-new="1">${esc(tf('folder_new', '+ Folder'))}</button>`)
  rail.innerHTML = parts.join('')

  // The rail keeps its scroll between repaints: when creating a folder the
  // field's focus pushed it to the right and "All" ended up half hidden.
  const active = rail.querySelector('.fold.active')
  if (!active) return
  const a = active.getBoundingClientRect(), r = rail.getBoundingClientRect()
  if (a.left < r.left) rail.scrollLeft -= (r.left - a.left) + 8
  else if (a.right > r.right) rail.scrollLeft += (a.right - r.right) + 8
}

async function createFolder(name) {
  try {
    const r = await (await fetch('/api/folders', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name })
    })).json()
    if (!r.success) { toast(r.error || t('toast_network_error'), 'err'); return null }
    S.folders.push(r.folder)
    return r.folder.id
  } catch (e) { toast(t('toast_network_error'), 'err'); return null }
}

async function deleteFolder(id) {
  if (!confirm(tf('confirm_folder_del', 'Delete this folder? The artists inside stay saved.'))) return
  try {
    await fetch(`/api/folders/${encodeURIComponent(id)}`, { method: 'DELETE' })
  } catch (e) { toast(t('toast_network_error'), 'err'); return }
  S.folders = S.folders.filter(f => f.id !== id)
  if (S.folderId === id) S.folderId = null
  armGridMorph()
  await refreshSaved()
  renderFolders()
}

// Electron had no window.prompt (it throws), so the name is asked for with a
// field placed right where the clicked button was — nicer than a dialog on the web too.
function askFolderName(anchor, cls, onName) {
  const inp = document.createElement('input')
  inp.className = cls
  inp.maxLength = 60
  inp.placeholder = tf('folder_name_ask', 'Folder name')
  anchor.replaceWith(inp)
  inp.focus()
  let done = false
  const finish = ok => {
    if (done) return
    done = true
    const name = inp.value.trim()
    onName(ok && name ? name : null)
  }
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') finish(true)
    else if (e.key === 'Escape') finish(false)
  })
  // Leaving the field cancels: creating a folder by accident because you clicked
  // outside is more annoying than having to type the name again.
  inp.addEventListener('blur', () => finish(false))
}

async function onFolderRailClick(e) {
  const del = e.target.closest('[data-fold-del]')
  if (del) { await deleteFolder(del.dataset.foldDel); return }

  const nu = e.target.closest('[data-fold-new]')
  if (nu) {
    askFolderName(nu, 'fold-input', async name => {
      if (name) await createFolder(name)
      renderFolders()
    })
    return
  }

  const chip = e.target.closest('[data-fold]')
  if (!chip) return
  S.folderId = chip.dataset.fold || null
  clearSelection()
  armGridMorph()
  renderFolders()
  renderParse()
  syncBulkChips()
}

// ── Grid morph ────────────────────────────────────────────────────────────────
// Actions "arm" the morph and the next renderParse goes through
// startViewTransition: the visible cards slide to their new position.
// It can't always be on: the stream drops cards in batches and the notch's
// re-planning is already animated in CSS.
let _gridMorphArmed = false
let _waveTimer = null
function armGridMorph() { _gridMorphArmed = true }

function withGridMorph(render) {
  const grid = $('px-grid')
  if (!document.startViewTransition || !parsePanelVisible() ||
      matchMedia('(prefers-reduced-motion: reduce)').matches) { render(); return }
  // Names only on the cards in frame: every name is a snapshot layer and with
  // hundreds the transition costs more than it shows.
  // Two passes — first measure all, then write: interleaving the
  // viewTransitionName write with the next getBoundingClientRect forced a
  // synchronous layout per card.
  const named = []
  const visible = []
  for (const c of grid.querySelectorAll('.gcard')) {
    const r = c.getBoundingClientRect()
    if (r.bottom > 0 && r.top < innerHeight && c.dataset.id) {
      visible.push(c)
      if (visible.length >= 40) break
    }
  }
  for (const c of visible) {
    c.style.viewTransitionName = 'g-' + c.dataset.id
    named.push(c.dataset.id)
  }
  const vt = document.startViewTransition(() => {
    render()
    for (const id of named) {
      const c = grid.querySelector(`.gcard[data-id="${CSS.escape(id)}"]`)
      if (c) c.style.viewTransitionName = 'g-' + id
    }
  })
  vt.finished.finally(() => {
    grid.querySelectorAll('.gcard').forEach(c => { c.style.viewTransitionName = '' })
  })
}

function renderParse() {
  _parseDirty = false
  if (_gridMorphArmed) {
    _gridMorphArmed = false
    withGridMorph(_renderParseNow)
    return
  }
  _renderParseNow()
}

function _renderParseNow() {
  const grid = $('px-grid')
  if (!grid) return
  const wasEmpty = !grid.querySelector('.gcard')
  const list = parseList()

  if (!list.length) {
    // With a filter on, empty doesn't mean "you have nothing saved": saying so
    // sent people looking for artists that were right there behind it.
    const filtered = S.pxTab === 'saved' && (S.statusFilter || S.refFilter != null)
    const key = S.pxTab !== 'saved' ? 'found' : filtered ? 'filter' : (S.folderId ? 'folder' : 'saved')
    grid.innerHTML = `
      <div class="px-empty">
        <p class="empty-title">${t('px_empty_' + key)}</p>
        <p class="empty-sub">${t('px_empty_' + key + '_sub')}</p>
      </div>`
    _notchKey = ''
    $('px-body').classList.remove('has-dock')   // no cards, no band to reserve
    syncDockPlacement(null)
    return
  }

  // The notch is resolved BEFORE generating the HTML and travels in each card's
  // class: if applied afterwards, every repaint from the stream would restart
  // the margin transition and the side columns would flicker.
  const notch = notchPlan()
  _notchKey = notchKeyOf(notch)
  $('px-body').classList.toggle('has-dock', !!notch)
  syncDockPlacement(notch)

  grid.innerHTML = list.map((a, i) => {
    const img       = a.image || a.spotify_image
    const listeners = a.followers ?? a.spotify_followers
    const igUrl     = a.instagram || (a.instagram_handle ? `https://www.instagram.com/${String(a.instagram_handle).replace('@','')}` : '')
    const igFol     = a.igFollowers ?? a.instagram_followers
    const spUrl     = a.url || a.spotify_url
    const saved     = S.pxTab === 'saved'

    const acts = saved
      ? (spUrl ? gicon('spotify', '', 'spotify', a.id, t('open_spotify')) : '') +
        (igUrl ? gicon('ig', '', 'ig', a.id, t('open_ig')) : '') +
        gicon('edit', '', 'edit', a.id, t('edit')) +
        (a.status !== 'contacted' ? gicon('check', '', 'contacted', a.id, t('mark_contacted')) : '') +
        gicon('trash', 'gbtn--del gbtn--last', 'delete', a.id, t('delete'))
      : (spUrl ? gicon('spotify', '', 'spotify', a.id, t('open_spotify')) : '') +
        (igUrl ? gicon('ig', '', 'ig', a.id, t('open_ig')) : '') +
        gicon('save', 'gbtn--last', 'save', a.id, t('save_one'))

    const tag = saved && a.status === 'contacted'
      ? `<span class="gcard-tag gcard-tag--contacted">${tf('contacted_lc', 'contacted')}</span>`
      : ''

    return `
      <article class="gcard${a.id === _playingId ? ' gcard--playing' : ''}${notch && notch.free.has(i % notch.n) ? ' gcard--lift' : ''}" data-id="${esc(a.id)}">
        ${img
          ? `<img class="gcard-img" src="${esc(img)}" alt="" loading="lazy" decoding="async" onerror="this.style.display='none'">`
          : `<div class="gcard-ph">${esc(ini(a.name))}</div>`}
        <button class="gcard-play" data-act="play" data-id="${esc(a.id)}" title="${esc(tf('preview_lc', 'Preview'))}">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z"/></svg>${esc(tf('preview_lc', 'Preview'))}
        </button>
        <button class="gcard-x" data-act="drop" data-id="${esc(a.id)}" title="${esc(tf('remove', 'Remove'))}" aria-label="${esc(tf('remove', 'Remove'))}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
        <div class="gcard-ov">
          <div class="gcard-acts">${acts}</div>
          <h3 class="gcard-name">${esc(a.name)}</h3>
          <div class="gcard-sub">
            <span>${fmt(listeners)}</span>
            ${igUrl ? `<span class="gcard-ig">@${esc(igUsername(igUrl))}${igFol != null ? ' · ' + fmt(igFol) : ''}</span>` : ''}
            ${a.topCity?.city ? `<span class="gcard-city" title="${esc(t('listened_in').replace('{place}', a.topCity.country ? `${a.topCity.city}, ${countryName(a.topCity.country)}` : a.topCity.city))}">${esc(a.topCity.city)}</span>` : ''}
            ${saved && a.reference_artist ? `<span class="gcard-ref">${esc(tf('from_lc', 'from'))} ${esc(a.reference_artist)}</span>` : ''}
            ${tag}
          </div>
        </div>
      </article>`
  }).join('')

  // Entrance wave only when going from empty to full (first opening of the pool
  // or the tab): on normal rebuilds it would flicker on every action.
  if (wasEmpty && parsePanelVisible()) {
    grid.classList.add('px-grid--wave')
    clearTimeout(_waveTimer)
    _waveTimer = setTimeout(() => grid.classList.remove('px-grid--wave'), 750)
  }

  syncSelection()   // the grid is rebuilt entirely: the state has to be repainted
}

// A single delegated listener for the whole gallery: with thousands of cards,
// attaching handlers per button on every repaint eats memory.
async function onParseAction(e) {
  const btn = e.target.closest('.gbtn, .gcard-play, .gcard-x')
  if (!btn) return
  const id = btn.dataset.id
  const a  = parseList().find(x => x.id === id)
  if (!a) return

  switch (btn.dataset.act) {
    case 'play':      togglePreview(a.id); break
    case 'spotify': {
      const url = a.url || a.spotify_url
      if (url) window.open(url, '_blank')
      break
    }
    case 'ig': {
      const url = a.instagram || `https://www.instagram.com/${String(a.instagram_handle || '').replace('@','')}`
      if (url) window.open(url, '_blank')
      break
    }
    case 'save':      await saveOneFromParse(a); break
    case 'edit':      editArtist(id); break
    case 'contacted': await contacted(id); break
    case 'delete':    await delArtist(id); break
    // The cross: in Saved it deletes from the database, in Found it takes out of the pool (reversible)
    case 'drop':
      if (S.pxTab === 'saved') await delArtist(id)
      else if (dropFromPool(a)) { armGridMorph(); renderParse(); toast(`${a.name} — ${tf('toast_undo_hint', 'skipped, ⌘Z to undo')}`) }
      break
  }
}

// ── Batch selection ───────────────────────────────────────────────────────────
// Three gestures: a plain click selects one, shift+click the range from the
// anchor, and dragging with the button down draws a rubber band. Cmd/Ctrl adds
// or removes single ones. Works in both tabs; what changes is the actions the bar offers.
const MARQUEE_MIN = 5
let _mq = null

function clearSelection() {
  if (!S.sel.size) return
  S.sel.clear()
  S.selAnchor = null
  syncSelection()
}

function syncSelection() {
  document.querySelectorAll('#px-grid .gcard').forEach(el =>
    el.classList.toggle('gcard--sel', S.sel.has(el.dataset.id)))
  syncSelBar()
}

// The bar floats over the window, not over the gallery: going up to the review
// it would be left hanging over a screen where it has no business. Separate from
// syncSelection so the rubber band can refresh it without going over every card.
function syncSelBar() {
  const bar = $('sel-bar')
  bar.classList.toggle('hidden', !S.sel.size || !parsePanelVisible())
  if (!S.sel.size) { $('sel-menu').classList.add('hidden'); return }
  $('sel-count').textContent = tf('sel_count', '{n} selected').replace('{n}', S.sel.size)

  // In the live pool there are no folders to move to or database to delete from:
  // what can be done with a batch is save it or get it out of the way.
  const saved = S.pxTab === 'saved'
  $('sel-save').classList.toggle('hidden', saved)
  $('sel-move').classList.toggle('hidden', !saved)
  // In the found pool the button also saves, and it has to say so.
  $('sel-contacted').textContent = saved
    ? tf('sel_contacted', '✓ Contacted')
    : tf('sel_save_contacted', '✓ Save & contacted')
  $('sel-del').textContent = saved ? t('delete') : tf('sel_remove', 'Remove')
}

function selectRange(fromId, toId) {
  const list = parseList()
  const i = list.findIndex(x => x.id === fromId)
  const j = list.findIndex(x => x.id === toId)
  if (i < 0 || j < 0) return
  const [lo, hi] = i <= j ? [i, j] : [j, i]
  S.sel = new Set(list.slice(lo, hi + 1).map(x => x.id))
  syncSelection()
}

// CONTENT coordinates, not the window's: that way the rubber band stays valid
// if the list scrolls while dragging.
function contentPoint(e) {
  const body = $('px-body')
  const r = body.getBoundingClientRect()
  return { x: e.clientX - r.left + body.scrollLeft, y: e.clientY - r.top + body.scrollTop }
}

function onGridMouseDown(e) {
  if (e.button !== 0) return
  if (e.target.closest('.gbtn, .gcard-play, .gcard-x')) return
  // Over the name and the handle TEXT selection wins: dragging there is
  // copying, not marking cards.
  if (e.target.closest('.gcard-name, .gcard-sub')) return
  const body = $('px-body')
  const br = body.getBoundingClientRect()
  const p = contentPoint(e)
  _mq = {
    x0: p.x, y0: p.y, moved: false,
    card: e.target.closest('.gcard'),
    add: e.shiftKey || e.metaKey || e.ctrlKey,
    base: new Set(S.sel),
    // The boxes are measured ONCE: with hundreds of cards, rereading them on
    // every mousemove forces the browser to recalculate layout every frame.
    boxes: [...document.querySelectorAll('#px-grid .gcard')].map(el => {
      const r = el.getBoundingClientRect()
      return { el, id: el.dataset.id, l: r.left - br.left + body.scrollLeft, t: r.top - br.top + body.scrollTop, w: r.width, h: r.height }
    })
  }
  document.addEventListener('mousemove', onGridMouseMove)
  document.addEventListener('mouseup', onGridMouseUp, { once: true })
}

function onGridMouseMove(e) {
  if (!_mq) return
  const p = contentPoint(e)
  if (!_mq.moved && Math.abs(p.x - _mq.x0) < MARQUEE_MIN && Math.abs(p.y - _mq.y0) < MARQUEE_MIN) return
  _mq.moved = true

  const l = Math.min(p.x, _mq.x0), t = Math.min(p.y, _mq.y0)
  const w = Math.abs(p.x - _mq.x0), h = Math.abs(p.y - _mq.y0)
  const box = $('marquee')
  box.style.cssText = `left:${l}px;top:${t}px;width:${w}px;height:${h}px`
  box.classList.remove('hidden')

  const next = _mq.add ? new Set(_mq.base) : new Set()
  for (const b of _mq.boxes) {
    if (b.l < l + w && b.l + b.w > l && b.t < t + h && b.t + b.h > t) next.add(b.id)
  }
  if (next.size !== S.sel.size || [...next].some(id => !S.sel.has(id))) {
    // Diff against the refs already measured: a full syncSelection re-queried
    // and went over hundreds of cards on every mousemove of the drag.
    for (const b of _mq.boxes) {
      const on = next.has(b.id)
      if (on !== S.sel.has(b.id)) b.el.classList.toggle('gcard--sel', on)
    }
    S.sel = next
    syncSelBar()
  }
}

function onGridMouseUp(e) {
  document.removeEventListener('mousemove', onGridMouseMove)
  const mq = _mq
  _mq = null
  if (!mq) return
  $('marquee').classList.add('hidden')
  if (mq.moved) return            // the rubber band has already made the selection

  if (!mq.card) { if (!mq.add) clearSelection(); return }
  const id = mq.card.dataset.id
  if (e.shiftKey && S.selAnchor) { selectRange(S.selAnchor, id); return }
  if (e.metaKey || e.ctrlKey) {
    S.sel.has(id) ? S.sel.delete(id) : S.sel.add(id)
  } else {
    S.sel = new Set([id])
  }
  S.selAnchor = id
  syncSelection()
}

function openSelMenu() {
  const menu = $('sel-menu')
  if (!menu.classList.contains('hidden')) { menu.classList.add('hidden'); return }
  menu.innerHTML = [
    ...S.folders.map(f => `<button data-move="${esc(f.id)}">${esc(f.name)}</button>`),
    S.folders.length ? '<hr>' : '',
    `<button data-move="">${esc(tf('move_none', 'Remove from folder'))}</button>`,
    `<button data-move-new="1">${esc(tf('folder_new_menu', 'New folder…'))}</button>`
  ].join('')
  menu.classList.remove('hidden')
}

async function moveSelection(folderId) {
  const ids = [...S.sel]
  if (!ids.length) return
  try {
    const r = await (await fetch('/api/artists/move', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids, folderId: folderId || null })
    })).json()
    if (!r.success) { toast(r.error || t('toast_network_error'), 'err'); return }
    toast(`${r.moved} ${tf('toast_moved', 'moved')}`)
  } catch (e) { toast(t('toast_network_error'), 'err'); return }
  $('sel-menu').classList.add('hidden')
  armGridMorph()
  await refreshSaved()
  renderFolders()
}

// What's selected in the live pool. Both actions leave ONE undo entry for the
// whole batch: with one per artist, a ⌘Z after marking forty brought back one
// and looked broken.
async function saveSelection() {
  const list = parseList().filter(a => S.sel.has(a.id))
  if (!list.length) return
  const items = list.map(a => ({ artist: a, idx: S.filtered.indexOf(a) }))
  const res = await api.bulkSaveArtists(list, S.refArtist?.name || null)
  if (!res?.success) { toast(res?.error || t('toast_error_saving'), 'err'); return }
  applyBatchDrop(items)
  pushUndo({ kind: 'batch', op: 'save', items })
  clearSelection()
  toast(`${list.length} ${t('toast_saved')} — ⌘Z`)
  armGridMorph()
  await refreshSaved()
  renderArtist(); updateContext(); renderParse()
}

// Mark the selected batch. The selection is released first: with the bar on
// top the result can't be seen on the cards below.
async function contactSelection() {
  const list = parseList().filter(a => S.sel.has(a.id))
  if (!list.length) return
  if (S.pxTab !== 'saved') { clearSelection(); await saveAndContact(list); return }
  const ids = contactableIds(list)
  if (!ids.length) { toast(tf('toast_all_contacted', 'They are all contacted already')); return }
  clearSelection()
  await markContactedBatch(ids)
}

function dropSelection() {
  const list = parseList().filter(a => S.sel.has(a.id))
  if (!list.length) return
  const items = list.map(a => ({ artist: a, idx: S.filtered.indexOf(a) }))
  applyBatchDrop(items)
  pushUndo({ kind: 'batch', op: 'drop', items })
  clearSelection()
  toast(`${list.length} — ${tf('toast_undo_hint', 'skipped, ⌘Z to undo')}`)
  armGridMorph()
  renderArtist(); updateContext(); renderParse()
}

// ALL the indices are taken before removing anyone: if they were read on the
// fly, each removal would shift the next ones and undo would bring them back skewed.
function applyBatchDrop(items) {
  for (const { artist } of items) {
    S.filtered = S.filtered.filter(x => x.id !== artist.id)
    S.allArtists = S.allArtists.filter(x => x.id !== artist.id)
    S.allArtistIds.delete(artist.id)
    if (S.skippedIds) S.skippedIds.add(artist.id)
    markSeen(artist.id)
  }
  if (S.idx >= S.filtered.length) S.idx = Math.max(0, S.filtered.length - 1)
}

async function deleteSelection() {
  const ids = [...S.sel]
  if (!ids.length) return
  if (!confirm(tf('confirm_delete_many', 'Delete {n} artists?').replace('{n}', ids.length))) return
  try {
    await fetch('/api/artists/bulk-delete', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids })
    })
  } catch (e) { toast(t('toast_network_error'), 'err'); return }
  toast(`${ids.length} ${t('toast_deleted')}`)
  clearSelection()
  armGridMorph()
  await refreshSaved()
  renderFolders()
}

async function onSelMenuClick(e) {
  const nu = e.target.closest('[data-move-new]')
  if (nu) {
    askFolderName(nu, 'sel-menu-input', async name => {
      if (!name) { $('sel-menu').classList.add('hidden'); return }
      const id = await createFolder(name)
      if (id) await moveSelection(id)
    })
    return
  }
  const to = e.target.closest('[data-move]')
  if (to) await moveSelection(to.dataset.move)
}

async function saveOneFromParse(a) {
  const res = await api.saveArtist({ ...a, referenceArtist: S.refArtist?.name || null })
  if (!res?.success) { toast(res?.error || t('toast_error_saving'), 'err'); return }
  toast(`${a.name} ${t('toast_saved')}`)
  markSeen(a.id)
  // Leaves the review pool just as if it had been saved from the card
  S.filtered = S.filtered.filter(x => x.id !== a.id)
  S.allArtists = S.allArtists.filter(x => x.id !== a.id)
  S.allArtistIds.delete(a.id)
  if (S.idx >= S.filtered.length) S.idx = Math.max(0, S.filtered.length - 1)
  renderArtist()
  upsertSavedLocal(res.record)
  updateContext()
  armGridMorph()
  renderParse()
}

// A single save doesn't need to re-download the whole database: the server
// returns the saved record and it's grafted in locally. The full refreshSaved
// is left for batches, deletions and undo.
function upsertSavedLocal(record) {
  if (!record) { refreshSaved(); return }   // server without `record`: safety net
  const i = S.savedArtists.findIndex(x => x.id === record.id)
  if (i >= 0) S.savedArtists[i] = { ...S.savedArtists[i], ...record }
  else S.savedArtists.unshift(record)
  $('cnt-saved').textContent = S.savedArtists.length
  renderRefFilter()
  if (S.pxTab === 'saved') { renderParse(); renderFolders() }
  syncBulkChips()
}

// Replaces refreshProspects + loadDB: a single list of saved artists that feeds
// the "Saved" tab and its counter.
async function refreshSaved() {
  let res
  try {
    res = await api.getArtists({})
  } catch (e) {
    console.error('[refreshSaved] fetch failed:', e)
    toast(t('toast_network_error'), 'err')
    return
  }
  S.savedArtists = (res.success && Array.isArray(res.artists)) ? res.artists : []
  $('cnt-saved').textContent = S.savedArtists.length
  // What was deleted or moved out of the open folder is no longer on screen: if
  // it stayed selected, the bar would count artists nobody can see.
  renderRefFilter()
  const visible = new Set(parseList().map(a => a.id))
  for (const id of S.sel) if (!visible.has(id)) S.sel.delete(id)
  if (S.pxTab === 'saved') { renderParse(); renderFolders() }
  syncSelection()
  syncBulkChips()
}

async function contacted(id) {
  const a = S.savedArtists.find(x => x.id === id)
  if (!a) return
  pushUndo({ kind: 'contacted', artist: a, prev: { status: a.status || 'saved', contacted_at: a.contacted_at || null } })
  await api.updateArtist(id, { status: 'contacted', contacted_at: new Date().toISOString() })
  toast(`${t('toast_marked_contacted')} — ⌘Z`)
  armGridMorph()
  await refreshSaved()
}

// Batch marking: used by the selection bar and by the suggestion that appears
// after copying or exporting. Like the other batch actions, it leaves ONE undo
// entry with each one's previous status.
async function markContactedBatch(ids) {
  const wanted = new Set(ids)
  const items = S.savedArtists
    .filter(a => wanted.has(a.id) && a.status !== 'contacted')
    .map(a => ({ id: a.id, prev: { status: a.status || 'saved', contacted_at: a.contacted_at || null } }))
  if (!items.length) { toast(tf('toast_all_contacted', 'They are all contacted already')); return }
  if (!await setBulkStatus(items.map(i => i.id), 'contacted')) return
  pushUndo({ kind: 'contacted_batch', items })
  toast(`${items.length} ${tf('toast_marked_many', 'marked as contacted')} — ⌘Z`)
  armGridMorph()
  await refreshSaved()
}

// Marking in the found pool: they don't exist in the database, so they're saved
// first. They leave the pool like any batch save and undo is the same: deleting
// the records also restores the status, with no separate entry.
async function saveAndContact(list) {
  if (!list.length) return
  const items = list.map(a => ({ artist: a, idx: S.filtered.indexOf(a) }))
  const res = await api.bulkSaveArtists(list, S.refArtist?.name || null)
  if (!res?.success) { toast(res?.error || t('toast_error_saving'), 'err'); return }
  // If the status fails they're already saved: they leave the pool anyway
  // (otherwise they'd be offered again) and setBulkStatus' error notice stands.
  const marked = await setBulkStatus(list.map(a => a.id), 'contacted')
  applyBatchDrop(items)
  pushUndo({ kind: 'batch', op: 'save', items })
  if (marked) toast(`${items.length} ${tf('toast_saved_marked', 'saved and marked as contacted')} — ⌘Z`)
  armGridMorph()
  await refreshSaved()
  renderArtist(); updateContext(); renderParse()
}

// `contactedAt` is only sent when undoing, to restore the original date.
async function setBulkStatus(ids, status, contactedAt) {
  try {
    const r = await (await fetch('/api/artists/bulk-status', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids, status, contactedAt })
    })).json()
    if (!r.success) { toast(r.error || t('toast_network_error'), 'err'); return false }
    return true
  } catch (e) { toast(t('toast_network_error'), 'err'); return false }
}

async function delArtist(id) {
  if (!confirm(t('confirm_delete'))) return
  await api.deleteArtist(id)
  toast(t('toast_deleted'))
  armGridMorph()
  await refreshSaved()
}

// ── Edit modal ────────────────────────────────────────────────────────────────
function editArtist(id) {
  const a = S.savedArtists.find(x=>x.id===id)
  if (!a) return
  $('edit-id').value = id
  $('edit-ig').value = a.instagram_handle||''
  $('edit-ig-f').value = a.instagram_followers||''
  $('edit-status').value = a.status||'saved'
  $('edit-notes').value = a.notes||''
  $('edit-overlay').classList.remove('hidden')
}

async function saveEdit() {
  const id = $('edit-id').value
  await api.updateArtist(id, {
    instagram_handle: $('edit-ig').value.trim()||null,
    instagram_followers: +$('edit-ig-f').value||null,
    status: $('edit-status').value,
    notes: $('edit-notes').value.trim()||null
  })
  toast(t('toast_saved'))
  $('edit-overlay').classList.add('hidden')
  refreshSaved()
}

// ── Settings ──────────────────────────────────────────────────────────────────
function openSettings() {
  $('set-lastfm').value = ''
  $('set-err').textContent = ''
  // v2.1.3 — genre mode
  const gm = $('set-genre-mode')
  if (gm) gm.value = localStorage.getItem('ao_genre_mode') || 'loose'
  // v2.2.0 — sound mode
  const sm = $('set-sound-mode')
  if (sm) sm.value = localStorage.getItem('ao_sound_mode') || 'medium'
  $('set-overlay').classList.remove('hidden')
  $('btn-set-close').focus()
}

function closeSettings() {
  $('set-overlay').classList.add('hidden')
}

async function saveSettings() {
  const key = $('set-lastfm').value.trim()
  if (!key) { $('set-err').textContent = 'Enter your Last.fm API key'; return }
  try {
    await api.saveConfig({ lastfmApiKey: key })
    $('set-err').textContent = ''
    toast('Settings saved')
  } catch(e) {
    $('set-err').textContent = 'Could not save'
  }
}

// v2.0.5 — Kbd labels by platform (Mac uses ⌘, Windows/Linux use Ctrl).
// The key logic in the keydown handler already supported `metaKey || ctrlKey`;
// here we only fix the visual labels that were hardcoded to Mac in the HTML.
function updateKbdLabels() {
  const isMac = navigator.platform.toLowerCase().includes('mac')
  const modKey = isMac ? '⌘' : 'Ctrl+'
  document.querySelectorAll('.f-hint').forEach(el => {
    // The original labels are ⌘←, ⌘↓, ⌘→ — we extract the final arrow.
    const arrow = el.textContent.replace(/[⌘Ctrl+]/g, '').trim()
    if (arrow) el.textContent = modKey + arrow
  })
}

// ── Init ──────────────────────────────────────────────────────────────────────
// Skip / Not similar / Save prospect only make sense with a card in front.
// Before, they stayed at full colour on the empty screen and while loading, and
// "Save Prospect" was the brightest element on screen exactly when there was
// nothing to save.
function syncActionButtons() {
  const has = !!(S.filtered && S.filtered[S.idx])
  ;['btn-skip', 'btn-nosim', 'btn-save'].forEach(id => {
    const b = $(id)
    if (b) b.disabled = !has
  })
}

async function init() {
  // i18n first: applies the strings to the DOM before anything else
  applyTranslations()
  renderSearchTitle()
  updateKbdLabels()

  // Seen history + saved + folders, in parallel: they're three independent
  // fetches and in series they delayed the first interactive frame.
  await Promise.all([loadSeenIds(), refreshSaved(), loadFolders()])

  initSlider('sp-min','sp-max','sp-min-n','sp-max-n','sp-fill',(lo,hi)=>{ S.spMin=lo; S.spMax=hi; if(S.allArtists.length) applyFilters(); scheduleRestart() })
  initSlider('ig-min','ig-max','ig-min-n','ig-max-n','ig-fill',(lo,hi)=>{ S.igMin=lo; S.igMax=hi; if(S.allArtists.length) applyFilters(); scheduleRestart() })

  // No scheduleRestart on any of them: the country filters what was ALREADY
  // collected, it doesn't change what gets collected. Restarting the crawl
  // here would throw away a good thirty seconds.
  renderCountryFilter()   // startup: the slot says "all", it isn't left empty
  mountMiniMap()
  $('cty-open').addEventListener('click', openCountryMap)
  $('map-close').addEventListener('click', closeCountryMap)
  $('map-overlay').addEventListener('click', e => { if (e.target.id === 'map-overlay') closeCountryMap() })
  $('map-search').addEventListener('input', renderCountryList)
  $('map-list').addEventListener('click', e => toggleCountry(e.target.closest('.cty-row')?.dataset.c))
  $('map-clear').addEventListener('click', () => {
    S.countries = []
    renderCountryFilter(); syncMapSelection(); renderCountryList()
    if (S.allArtists.length) applyFilters()
  })

  initSearch()
  renderHistory()
  $('artist-input').focus()

  // Navigation between screens
  $('tb-back').addEventListener('click', showSearch)
  $('rv-down').addEventListener('click', scrollToParse)
  // When the parse panel comes into view, what was found while it was hidden
  // has to be shown. Only on the crossing: repainting on every scroll event
  // would rebuild hundreds of cards per gesture.
  // None of this is done per frame: the event arrives on every frame of the
  // gesture and the only thing that really changes is crossing between panels.
  let wasParseVisible = false
  let _snapIdleT = null
  const SNAP_IDLE_MS = 140
  $('snap').addEventListener('scroll', () => {
    const now = parsePanelVisible()
    if (now !== wasParseVisible) {
      wasParseVisible = now
      if (now) {
        // The notch does come in now: it's classes, and they travel in the same
        // transition as the player. The empty grid is painted now too — there's
        // nothing to shake and without it you'd scroll down to a blank gallery.
        if (_parseDirty && !$('px-grid').querySelector('.gcard')) renderParse()
        else syncDockNotch()
        syncPxStage(true)
      } else {
        // Going back to the review the player reappears even if the list stayed
        // in stage 2, and gets the card's width back: the widening is only to
        // fit the gallery's notch.
        $('player-dock').classList.remove('gone')
        $('dock-island').classList.remove('show')
        syncDockPlacement(null)
      }
      syncSelection()   // goes over every card: only on the crossing
    }
    // And the expensive part — rebuilding the grid with what arrived while it
    // wasn't visible — waits for the gesture to stop. Doing it in the crossing
    // frame ate the first frames of the player's journey: that's what showed as
    // a jerk when going from the review to the gallery.
    clearTimeout(_snapIdleT)
    _snapIdleT = setTimeout(() => {
      if (!_parseDirty || !parsePanelVisible()) return
      armGridMorph()   // stopped now, the replacement can afford the crossing
      renderParse()
    }, SNAP_IDLE_MS)
  }, { passive: true })
  // The gallery's stage 1 ⇄ 2: the player's notch
  $('px-body').addEventListener('scroll', () => syncPxStage(), { passive: true })
  $('px-body').addEventListener('wheel', onGalleryWheel, { passive: false })
  // Debounce: without it, dragging the window's edge fired syncDockNotch (two
  // forced layouts and sometimes a grid rebuild) on every tick.
  let _resizeT = null
  addEventListener('resize', () => { clearTimeout(_resizeT); _resizeT = setTimeout(syncDockNotch, 100) })
  document.addEventListener('visibilitychange', () => { if (!document.hidden) syncDockNotch() })
  $('hist-clear').addEventListener('click', clearHistory)

  // Settings: a side sheet instead of a page, since there's no navigation rail
  $('btn-settings').addEventListener('click', openSettings)
  $('btn-set-close').addEventListener('click', closeSettings)
  $('set-overlay').addEventListener('click', e => { if (e.target === $('set-overlay')) closeSettings() })

  // Parse screen
  document.querySelectorAll('#px-tabs .seg-b').forEach(el =>
    el.addEventListener('click', () => {
      S.pxTab = el.dataset.tab
      S.folderId = null
      S.refFilter = null
      S.statusFilter = null
      clearSelection()
      armGridMorph()
      syncParseTabs(); renderParse(); updateContext()
    }))
  $('px-grid').addEventListener('click', onParseAction)
  $('px-grid').addEventListener('mousedown', onGridMouseDown)
  $('fold-rail').addEventListener('click', onFolderRailClick)
  $('sel-move').addEventListener('click', openSelMenu)
  $('sel-menu').addEventListener('click', onSelMenuClick)
  $('sel-save').addEventListener('click', saveSelection)
  $('sel-contacted').addEventListener('click', contactSelection)
  $('sel-del').addEventListener('click', () => S.pxTab === 'saved' ? deleteSelection() : dropSelection())
  $('sel-clear').addEventListener('click', clearSelection)
  $('ask-yes').addEventListener('click', () => { const run = _askRun; closeAsk(); run?.() })
  $('ask-no').addEventListener('click', closeAsk)
  $('ref-filter').addEventListener('change', e => {
    S.refFilter = e.target.value || null
    clearSelection()
    armGridMorph()
    renderFolders(); renderParse(); syncBulkChips()
  })
  $('status-filter').addEventListener('change', e => {
    S.statusFilter = e.target.value || null
    clearSelection()
    armGridMorph()
    renderFolders(); renderParse(); syncBulkChips()
  })
  document.addEventListener('mousedown', e => {
    if (!e.target.closest('#sel-bar')) $('sel-menu').classList.add('hidden')
  })
  $('px-grid').addEventListener('mouseleave', () => {
    if (!_parseRenderPending) return
    _parseRenderPending = false
    renderParse()
  })
  // The collapsed pill: the body takes the list back to the top (which is what
  // unfolds the player again) and the button on the right pauses.
  $('di-open').addEventListener('click', () => $('px-body').scrollTo({ top: 0, behavior: 'smooth' }))
  $('di-pause').addEventListener('click', () => togglePreview(_playingId))
  $('px-run').addEventListener('click', toggleDiscover)
  $('btn-exp-csv').addEventListener('click', exportDiscoveredCSV)
  $('btn-copy-ig').addEventListener('click', copyIGHandles)
  $('btn-save-all').addEventListener('click', saveAllToDB)
  syncParseTabs()

  $('btn-skip').addEventListener('click', skipArtist)
  $('btn-nosim').addEventListener('click', notSimilar)
  $('btn-save').addEventListener('click', saveProspect)
  syncActionButtons()

  document.addEventListener('keydown', e => {
    if (e.target.matches('input,select,textarea')) return
    if (e.metaKey || e.ctrlKey) {
      if (e.key==='ArrowLeft')  { e.preventDefault(); skipArtist() }
      if (e.key==='ArrowDown')  { e.preventDefault(); notSimilar() }
      if (e.key==='ArrowRight') { e.preventDefault(); saveProspect() }
      // With Shift the key arrives in upper case, hence the toLowerCase
      if (e.key.toLowerCase()==='z') { e.preventDefault(); e.shiftKey ? redoLast() : undoLast() }
      if (e.key.toLowerCase()==='a' && parsePanelVisible()) {
        e.preventDefault()
        S.sel = new Set(parseList().map(a => a.id))
        syncSelection()
      }
    }
  })

  // Escape closes whatever is open on top
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return
    if (!$('edit-overlay').classList.contains('hidden')) $('edit-overlay').classList.add('hidden')
    else if (!$('set-overlay').classList.contains('hidden')) closeSettings()
    else if (!$('sel-menu').classList.contains('hidden')) $('sel-menu').classList.add('hidden')
    else if (!$('ask').classList.contains('hidden')) closeAsk()
    else clearSelection()
  })

  $('btn-edit-cancel').addEventListener('click', () => $('edit-overlay').classList.add('hidden'))
  $('btn-edit-save').addEventListener('click', saveEdit)
  $('edit-overlay').addEventListener('click', e => { if(e.target===$('edit-overlay')) $('edit-overlay').classList.add('hidden') })

  $('btn-save-settings').addEventListener('click', saveSettings)

  // v2.1.3 — Genre mode change. Stored in localStorage and applied on the
  // NEXT search. If the user changes it while one is running, we warn with a
  // toast but don't relaunch automatically.
  const gmSel = $('set-genre-mode')
  if (gmSel) {
    gmSel.addEventListener('change', () => {
      localStorage.setItem('ao_genre_mode', gmSel.value)
      const label = { off: 'off', loose: 'loose', strict: 'strict' }[gmSel.value] || gmSel.value
      toast(`Genre mode: ${label}. Applies to next search.`)
    })
  }

  // v2.2.0 — Sound mode change (audio features). Like genre: applied on the
  // next search.
  const smSel = $('set-sound-mode')
  if (smSel) {
    smSel.addEventListener('change', () => {
      localStorage.setItem('ao_sound_mode', smSel.value)
      toast(`Sound match: ${smSel.value}. Applies to next search.`)
    })
  }

  // v2.0.1 — Reset the seen-artists history.
  // When the user piles up hundreds of "seenIds", searching a big mainstream
  // artist can return 0 results because all their neighbours were already shown
  // in earlier searches. This button empties seenIds without touching the
  // saved prospects.
  const resetSeenBtn = $('btn-reset-seen')
  if (resetSeenBtn) {
    resetSeenBtn.addEventListener('click', async () => {
      if (!confirm(t('confirm_reset_seen'))) return
      const origText = resetSeenBtn.textContent
      resetSeenBtn.disabled = true
      resetSeenBtn.textContent = '…'
      try {
        const r = await fetch('/api/reset-seen', { method: 'POST' })
        const data = await r.json()
        if (data.success) {
          // We also refresh the client's in-memory Set
          if (S.persistentSeen) S.persistentSeen.clear()
          toast(`${t('toast_history_cleared')} (${data.cleared})`)
        } else {
          toast(data.error || t('toast_reset_failed'), 'err')
        }
      } catch (e) {
        toast(t('toast_network_error'), 'err')
      } finally {
        resetSeenBtn.disabled = false
        resetSeenBtn.textContent = origText
      }
    })
  }
}

document.addEventListener('DOMContentLoaded', init)
