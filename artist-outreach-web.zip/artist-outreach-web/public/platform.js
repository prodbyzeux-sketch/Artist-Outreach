// platform.js — everything the web platform adds around the Finder UI (app.js
// is untouched apart from Instagram-via-extension in runIGBatch):
//
//   1. fetch: a 401 goes to sign-in and a 402 to the plans page. The session
//      cookie travels by itself (same origin), so app.js needs no changes.
//   2. App navigation — Discover (the Finder), Outreach and Inbox. Outreach and
//      Inbox are the extension's own pages, embedded here: Chrome only lets an
//      extension send Instagram DMs, so the extension does the sending and the
//      app is where you work.
//   3. Account menu (top right): plan, extension, billing, sign out.
//   4. Bridge to the extension: it injects a content script on this page
//      (extension/platform/bridge.js) and we talk over window.postMessage.
//      window.AOExt is what app.js uses.

;(function () {
  'use strict'

  // ── 1. fetch ───────────────────────────────────────────────────────────────
  const nativeFetch = window.fetch.bind(window)
  let redirecting = false
  window.fetch = async function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || ''
    const local = url.startsWith('/') && !url.startsWith('//')
    if (local && (url.startsWith('/api/stats') || url.startsWith('/api/quota'))) {
      init = { ...(init || {}), headers: { ...((init && init.headers) || {}), 'X-TZ-Offset': String(new Date().getTimezoneOffset()) } }
    }
    const res = await nativeFetch(input, init)
    if (local && !redirecting && (res.status === 401 || res.status === 402)) {
      redirecting = true
      location.href = res.status === 401
        ? '/login?next=' + encodeURIComponent(location.pathname + location.search + location.hash)
        : '/billing'
    }
    return res
  }

  const postJSON = (url, body) => nativeFetch(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}),
  }).then(r => r.json())

  const getJSON = (url, headers = {}) => nativeFetch(url, { headers }).then(r => r.json())

  // ── tiny DOM helper ────────────────────────────────────────────────────────
  function el(tag, attrs = {}, ...kids) {
    const n = document.createElement(tag)
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue
      if (k === 'class') n.className = v
      else if (k === 'html') n.innerHTML = v
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v)
      else n.setAttribute(k, v === true ? '' : v)
    }
    for (const k of kids) if (k != null && k !== false) n.append(k)
    return n
  }

  function flash(msg, kind = 'ok') {
    const t = document.getElementById('toast')
    if (!t) return
    t.textContent = msg
    t.className = `toast show ${kind}`
    setTimeout(() => { t.className = 'toast' }, 3500)
  }

  // ── 4. extension bridge ────────────────────────────────────────────────────
  const pending = new Map()
  let seq = 0
  const ext = { available: false, paired: false, email: null, version: null, id: null }

  function request(type, payload = {}, timeoutMs = 8000) {
    return new Promise((resolve, reject) => {
      const id = 'ao' + (++seq) + '_' + Date.now()
      const timer = setTimeout(() => { pending.delete(id); reject(new Error('the extension did not answer')) }, timeoutMs)
      pending.set(id, { resolve, reject, timer })
      window.postMessage({ source: 'ao-platform', id, type, ...payload }, location.origin)
    })
  }

  window.addEventListener('message', e => {
    if (e.source !== window || e.origin !== location.origin) return
    const d = e.data
    if (!d || d.source !== 'ao-ext') return
    if (d.type === 'hello') {
      Object.assign(ext, { available: true, paired: !!d.paired, email: d.email || null, version: d.version || null, id: d.extensionId || ext.id })
      onExtensionChange()
      return
    }
    if (d.id && pending.has(d.id)) {
      const p = pending.get(d.id)
      pending.delete(d.id)
      clearTimeout(p.timer)
      if (d.error) p.reject(new Error(d.error))
      else p.resolve(d)
    }
  })
  // In case the content script loaded before us and already said hello.
  window.postMessage({ source: 'ao-platform', type: 'ping' }, location.origin)

  const handleOf = url => {
    const m = String(url || '').match(/instagram\.com\/([A-Za-z0-9._]{1,30})/i)
    return m ? m[1].toLowerCase() : String(url || '').replace(/^@/, '').toLowerCase()
  }

  let pairing = null
  async function pair() {
    if (pairing) return pairing
    pairing = (async () => {
      const r = await postJSON('/api/ext/pair', { label: navigator.userAgent.includes('Edg/') ? 'Edge' : 'Chrome' })
      if (!r.success) throw new Error(r.error || 'pairing failed')
      const reply = await request('pair', { token: r.token, origin: location.origin }, 15000)
      if (!reply.ok) throw new Error(reply.error || 'pairing failed')
      ext.paired = true
      ext.email = reply.email || (me && me.email)
      onExtensionChange()
      return reply
    })().finally(() => { pairing = null })
    return pairing
  }

  window.AOExt = {
    // Can the extension read Instagram for us? Being installed is enough: the
    // lookup uses the browser's Instagram session, not our account.
    ready: () => ext.available,
    state: () => ({ ...ext }),
    // Instagram URLs → { url: followers }. Confirmed numbers also go to the
    // server (shared cache).
    async lookupFollowers(urls) {
      if (!ext.available || !urls.length) return {}
      const byHandle = new Map()
      for (const u of urls) { const h = handleOf(u); if (h) byHandle.set(h, u) }
      const reply = await request('ig-lookup', { usernames: [...byHandle.keys()] }, 90000)
      const out = {}
      for (const [h, v] of Object.entries(reply.results || {})) {
        if (Number.isInteger(v) && byHandle.has(h)) out[byHandle.get(h)] = v
      }
      if (Object.keys(out).length) postJSON('/api/ig-report', { results: out }).catch(() => {})
      return out
    },
    pair,
  }

  // ── state shared by the views ──────────────────────────────────────────────
  let me = null
  let extensionInfo = { storeUrl: null, downloadUrl: '/downloads/artist-outreach-extension.zip' }
  let quota = null
  const isChromium = !!window.chrome && /Chrome|Chromium|Edg\//.test(navigator.userAgent)

  function onExtensionChange() {
    renderMenu()
    renderPanel()
    // Signed in, extension installed, never connected: connect it now — the
    // user is already logged in here, there is nothing to ask.
    if (me && me.access && ext.available && !ext.paired && !pairing) {
      pair().then(() => flash('Extension connected to your account'))
        .catch(e => console.warn('[platform] auto-pair:', e.message))
    }
  }

  // ── 2. navigation ──────────────────────────────────────────────────────────
  const VIEWS = [
    { key: 'discover', label: 'Discover' },
    { key: 'outreach', label: 'Outreach' },
    { key: 'inbox', label: 'Inbox' },
  ]
  const PAGES = { outreach: 'outreach/src/app.html', inbox: 'crm/page/crm.html' }
  let view = 'discover'
  let nav = null, panel = null
  const frames = {}   // view → iframe (kept alive so switching keeps their state)

  function viewFromHash() {
    const h = location.hash.replace('#', '')
    return VIEWS.some(v => v.key === h) ? h : 'discover'
  }

  function setView(next, { push = true } = {}) {
    view = next
    if (push) history.replaceState(null, '', next === 'discover' ? location.pathname + location.search : '#' + next)
    document.body.classList.toggle('ao-in-panel', view !== 'discover')
    for (const b of nav.querySelectorAll('button')) b.setAttribute('aria-current', b.dataset.view === view ? 'page' : 'false')
    renderPanel()
    if (view === 'outreach') loadQuota()
  }

  function mountNav() {
    nav = el('nav', { class: 'ao-nav', 'aria-label': 'Artist Outreach' },
      ...VIEWS.map(v => el('button', { type: 'button', 'data-view': v.key, onclick: () => setView(v.key) }, v.label)))
    panel = el('section', { class: 'ao-panel', 'aria-live': 'polite' })
    document.body.append(panel, nav)
    window.addEventListener('hashchange', () => setView(viewFromHash(), { push: false }))
    setView(viewFromHash(), { push: false })
  }

  // ── Outreach / Inbox panel ─────────────────────────────────────────────────
  function card(...kids) { return el('div', { class: 'ao-card' }, ...kids) }

  function installCard() {
    if (!isChromium) {
      return card(
        el('h2', {}, 'Outreach runs in Chrome'),
        el('p', {}, 'Sending Instagram DMs needs the Artist Outreach browser extension, which works in Chrome and other Chromium browsers (Edge, Brave, Arc). Open Artist Outreach in one of them to use Outreach and Inbox.'))
    }
    const store = extensionInfo.storeUrl
    return card(
      el('h2', {}, 'Install the Artist Outreach extension'),
      el('p', {}, 'Instagram only lets a browser extension send DMs for you. Install it once — Outreach and Inbox then live right here, and your saved artists flow straight into your campaigns.'),
      store
        ? el('div', { class: 'ao-actions' }, el('a', { class: 'ao-btn primary', href: store, target: '_blank', rel: 'noopener' }, 'Add to Chrome'))
        : el('ol', { class: 'ao-steps' },
            el('li', {}, el('a', { class: 'ao-btn primary', href: extensionInfo.downloadUrl }, 'Download the extension'), ' and unzip it.'),
            el('li', {}, 'Open ', el('code', {}, 'chrome://extensions'), ' and switch on ', el('b', {}, 'Developer mode'), ' (top right).'),
            el('li', {}, 'Click ', el('b', {}, 'Load unpacked'), ' and choose the ', el('code', {}, 'artist-outreach-extension'), ' folder.'),
            el('li', {}, 'Come back here and reload the page.')),
      el('div', { class: 'ao-actions' }, el('button', { class: 'ao-btn', type: 'button', onclick: () => location.reload() }, "I've installed it — reload")))
  }

  function connectCard() {
    const other = ext.paired && ext.email && me && ext.email !== me.email
    return card(
      el('h2', {}, other ? 'The extension is connected to another account' : 'Connect the extension'),
      el('p', {}, other
        ? `It is signed in as ${ext.email}. Connect it to ${me.email} to use your plan and your saved artists.`
        : 'One click links the extension in this browser to your account.'),
      el('div', { class: 'ao-actions' }, el('button', {
        class: 'ao-btn primary', type: 'button', onclick: async ev => {
          const b = ev.currentTarget
          b.disabled = true
          b.textContent = 'Connecting…'
          try { await pair(); flash('Extension connected') }
          catch (e) { flash("Couldn't connect the extension — " + e.message, 'err'); b.disabled = false; b.textContent = 'Connect' }
        },
      }, other ? `Connect to ${me.email}` : 'Connect')))
  }

  function quotaBar() {
    if (!me) return null
    const plan = me.plan || {}
    let text, warn = false
    if (plan.dailyAutoDms == null) {
      text = `${plan.name || 'Pro'} · unlimited automated DMs` + (quota ? ` · ${quota.used} today` : '')
    } else if (quota) {
      text = `${plan.name} · ${quota.remaining} of ${quota.limit} automated DMs left today`
      warn = quota.remaining <= 2
    } else {
      text = `${plan.name} · ${plan.dailyAutoDms} automated DMs a day`
    }
    return el('div', { class: 'ao-quota' + (warn ? ' warn' : '') },
      el('span', {}, text),
      plan.key === 'starter' && me.billing.enabled ? el('a', { href: '/billing#upgrade', class: 'ao-quota-up' }, 'Upgrade to Pro') : null)
  }

  async function loadQuota() {
    try {
      const q = await getJSON('/api/quota', { 'X-TZ-Offset': String(new Date().getTimezoneOffset()) })
      if (q.success) { quota = q; const bar = panel.querySelector('.ao-quota'); if (bar) bar.replaceWith(quotaBar()) }
    } catch (_) {}
  }
  setInterval(() => { if (view === 'outreach' && document.visibilityState === 'visible') loadQuota() }, 60000)

  function renderPanel() {
    if (!panel || !me) return
    for (const f of Object.values(frames)) f.hidden = true
    if (view === 'discover') { panel.hidden = true; return }
    panel.hidden = false

    const head = panel.querySelector('.ao-panel-head') || el('div', { class: 'ao-panel-head' })
    head.replaceChildren(view === 'outreach' ? quotaBar() : el('span'))
    if (!head.isConnected) panel.prepend(head)

    let body = panel.querySelector('.ao-panel-body')
    if (!body) { body = el('div', { class: 'ao-panel-body' }); panel.append(body) }
    for (const c of body.querySelectorAll('.ao-card')) c.remove()

    const ready = ext.available && ext.id && ext.paired && (!ext.email || ext.email === me.email)
    if (!ext.available || !ext.id) { body.append(installCard()); return }
    if (!ready) { body.append(connectCard()); return }

    if (!frames[view]) {
      frames[view] = el('iframe', {
        class: 'ao-frame', title: view === 'outreach' ? 'Outreach' : 'Inbox',
        src: `chrome-extension://${ext.id}/${PAGES[view]}`,
        allow: 'clipboard-read; clipboard-write',
      })
      body.append(frames[view])
    }
    frames[view].hidden = false
  }

  // ── 3. account menu ────────────────────────────────────────────────────────
  let btn = null, menu = null

  function planLabel(u) {
    if (u.role === 'admin') return 'Admin · unlimited'
    if (!u.billing.enabled) return 'Free access'
    const status = { trialing: ' · trial', past_due: ' · payment due' }[u.billing.status] || ''
    if (!u.access) return 'No active plan'
    const interval = u.billing.interval === 'year' ? 'yearly' : u.billing.interval === 'month' ? 'monthly' : ''
    return `${u.plan.name || 'Plan'}${interval ? ' · ' + interval : ''}${status}`
  }

  function renderMenu() {
    if (!menu || !me) return
    const state = !ext.available ? 'Not installed'
      : !ext.paired ? 'Not connected'
      : (ext.email && ext.email !== me.email) ? 'Another account'
      : 'Connected'
    btn.classList.toggle('acct-dot', ext.available && state !== 'Connected')
    menu.replaceChildren(
      el('div', { class: 'acct-head' },
        el('div', { class: 'acct-email' }, me.email),
        el('div', { class: 'acct-plan' }, planLabel(me))),
      el('div', { class: 'acct-sec' },
        el('div', { class: 'acct-row' },
          el('span', {}, 'Extension'),
          el('span', { class: 'acct-pill' + (state === 'Connected' ? ' on' : '') }, state)),
        state !== 'Connected'
          ? el('button', { class: 'acct-link', type: 'button', onclick: () => { menu.setAttribute('hidden', ''); setView('outreach') } },
              ext.available ? 'Connect the extension' : 'Install the extension')
          : null),
      el('div', { class: 'acct-sec' },
        me.billing.enabled && me.role !== 'admin' ? el('a', { class: 'acct-link', href: '/billing' }, 'Plan & billing') : null,
        el('button', { class: 'acct-link', type: 'button', onclick: async () => {
          await nativeFetch('/auth/logout', { method: 'POST', headers: { Accept: 'application/json' } }).catch(() => {})
          location.href = '/login'
        } }, 'Sign out')),
    )
  }

  function mountAccount() {
    btn = el('button', { class: 'nav-btn nav-acct', id: 'btn-account', type: 'button', title: 'Account', 'aria-label': 'Account', 'aria-haspopup': 'true' })
    if (me.avatar) btn.append(el('img', { src: me.avatar, alt: '', referrerpolicy: 'no-referrer' }))
    else btn.append(el('span', { class: 'acct-initial' }, (me.name || me.email || '?').trim()[0].toUpperCase()))
    menu = el('div', { class: 'acct-menu', role: 'menu', hidden: true })
    btn.addEventListener('click', e => {
      e.stopPropagation()
      if (menu.hasAttribute('hidden')) { renderMenu(); menu.removeAttribute('hidden') } else menu.setAttribute('hidden', '')
    })
    document.addEventListener('click', e => { if (!menu.contains(e.target)) menu.setAttribute('hidden', '') })
    document.addEventListener('keydown', e => { if (e.key === 'Escape') menu.setAttribute('hidden', '') })
    document.body.append(btn, menu)
    renderMenu()
  }

  async function init() {
    try {
      const r = await nativeFetch('/api/me')
      if (r.status === 401) { location.href = '/login'; return }
      const j = await r.json()
      me = j.user
      if (j.extension) extensionInfo = { ...extensionInfo, ...j.extension }
      if (!me.access) { location.href = '/billing'; return }
      mountAccount()
      mountNav()
      onExtensionChange()
    } catch (e) {
      console.warn('[platform] /api/me:', e)
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init)
  else init()
})()
