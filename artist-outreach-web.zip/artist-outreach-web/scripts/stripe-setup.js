#!/usr/bin/env node
// Creates everything Artist Outreach needs in a Stripe account, idempotently:
//
//   - Products "Artist Outreach Starter" and "Artist Outreach Pro"
//     (tax code txcd_10103001 = SaaS, business use).
//   - Four EUR prices with lookup keys (the server finds them by key):
//       ao_starter_monthly  €7.00/month   (12-month commitment)
//       ao_starter_yearly   €67.20/year   (20% off €84)
//       ao_pro_monthly      €17.00/month  (12-month commitment)
//       ao_pro_yearly       €163.20/year  (20% off €204)
//   - A Customer Portal configuration WITHOUT cancel / plan switching, so the
//     commitment can't be skipped there (cancelling happens in the app).
//   - Optionally the webhook endpoint.
//
// Usage (test mode first, then live):
//   STRIPE_SECRET_KEY=sk_test_... node scripts/stripe-setup.js \
//     --url https://app.yourdomain.com [--webhook] [--tax inclusive|exclusive]
//
// --tax inclusive (default): €17 is what the customer pays, VAT included.
// --tax exclusive: VAT is added on top of €17 at checkout.

const { PLANS, PLAN_KEYS, INTERVALS, CURRENCY } = require('../server/billing/plans')

const TAX_CODE = 'txcd_10103001'
const APP_TAG = 'artist-outreach'
const WEBHOOK_EVENTS = [
  'checkout.session.completed',
  'customer.subscription.created',
  'customer.subscription.updated',
  'customer.subscription.deleted',
  'customer.subscription.paused',
  'customer.subscription.resumed',
  'invoice.paid',
  'invoice.payment_failed',
]

async function findProduct(stripe, plan) {
  const list = await stripe.products.list({ limit: 100, active: true })
  return list.data.find(p => p.metadata?.app === APP_TAG && p.metadata?.plan === plan) || null
}

async function setup(stripe, { url = null, webhook = false, tax = 'inclusive', log = console.log } = {}) {
  const out = { products: {}, prices: {}, portalConfiguration: null, webhookSecret: null, webhookId: null }

  for (const planKey of PLAN_KEYS) {
    const plan = PLANS[planKey]
    let product = await findProduct(stripe, planKey)
    if (!product) {
      product = await stripe.products.create({
        name: `Artist Outreach ${plan.name}`,
        description: plan.dailyAutoDms
          ? `Artist discovery and Instagram outreach — ${plan.dailyAutoDms} automated DMs per day.`
          : 'Artist discovery and Instagram outreach — unlimited automated DMs.',
        tax_code: TAX_CODE,
        metadata: { app: APP_TAG, plan: planKey },
      })
      log(`created product ${product.name} (${product.id})`)
    } else {
      log(`product ${product.name} exists (${product.id})`)
    }
    out.products[planKey] = product.id

    for (const interval of INTERVALS) {
      const def = plan.prices[interval]
      const existing = (await stripe.prices.list({ lookup_keys: [def.lookupKey], limit: 1 })).data[0]
      const same = existing && existing.unit_amount === def.amount && existing.currency === CURRENCY &&
        existing.recurring?.interval === interval && existing.active && existing.tax_behavior === tax
      if (same) {
        log(`price ${def.lookupKey} exists (${existing.id})`)
        out.prices[def.lookupKey] = existing.id
        continue
      }
      const price = await stripe.prices.create({
        product: product.id,
        currency: CURRENCY,
        unit_amount: def.amount,
        recurring: { interval },
        tax_behavior: tax,
        lookup_key: def.lookupKey,
        transfer_lookup_key: !!existing,
        nickname: `${plan.name} ${interval === 'month' ? 'monthly' : 'yearly'}`,
        metadata: { app: APP_TAG, plan: planKey, interval, commitment_months: String(def.commitmentMonths) },
      })
      log(`${existing ? 'replaced' : 'created'} price ${def.lookupKey} → ${price.id} (${(def.amount / 100).toFixed(2)} ${CURRENCY}/${interval})`)
      out.prices[def.lookupKey] = price.id
    }
  }

  // Customer Portal: card, invoices and billing details — no cancel, no plan switch.
  const portalParams = {
    business_profile: {
      headline: 'Artist Outreach — manage your billing',
      ...(url ? { privacy_policy_url: `${url}/privacy`, terms_of_service_url: `${url}/terms` } : {}),
    },
    features: {
      customer_update: { enabled: true, allowed_updates: ['email', 'address', 'tax_id', 'name'] },
      invoice_history: { enabled: true },
      payment_method_update: { enabled: true },
      subscription_cancel: { enabled: false },
      subscription_update: { enabled: false },
    },
    metadata: { app: APP_TAG },
  }
  const configs = await stripe.billingPortal.configurations.list({ limit: 100, active: true })
  const mine = configs.data.find(c => c.metadata?.app === APP_TAG)
  const portal = mine
    ? await stripe.billingPortal.configurations.update(mine.id, portalParams)
    : await stripe.billingPortal.configurations.create(portalParams)
  log(`${mine ? 'updated' : 'created'} portal configuration ${portal.id}`)
  out.portalConfiguration = portal.id

  if (webhook) {
    if (!url) throw new Error('--webhook needs --url')
    const target = `${url}/billing/webhook`
    const endpoints = await stripe.webhookEndpoints.list({ limit: 100 })
    const found = endpoints.data.find(e => e.url === target)
    if (found) {
      await stripe.webhookEndpoints.update(found.id, { enabled_events: WEBHOOK_EVENTS })
      log(`webhook ${target} exists (${found.id}) — its secret is in the Dashboard (Developers → Webhooks)`)
      out.webhookId = found.id
    } else {
      const created = await stripe.webhookEndpoints.create({ url: target, enabled_events: WEBHOOK_EVENTS, metadata: { app: APP_TAG } })
      log(`created webhook ${target} (${created.id})`)
      out.webhookId = created.id
      out.webhookSecret = created.secret
    }
  }
  return out
}

function parseArgs(argv) {
  const a = { url: null, webhook: false, tax: 'inclusive' }
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--url') a.url = String(argv[++i] || '').replace(/\/+$/, '')
    else if (argv[i] === '--webhook') a.webhook = true
    else if (argv[i] === '--tax') a.tax = argv[++i]
  }
  if (!['inclusive', 'exclusive'].includes(a.tax)) throw new Error('--tax must be inclusive or exclusive')
  if (a.url) new URL(a.url)
  return a
}

if (require.main === module) {
  (async () => {
    const key = process.env.STRIPE_SECRET_KEY
    if (!key) { console.error('Set STRIPE_SECRET_KEY (sk_test_... first, then sk_live_...).'); process.exit(1) }
    const args = parseArgs(process.argv.slice(2))
    const Stripe = require('stripe')
    const res = await setup(new Stripe(key), args)
    console.log('\nAdd these to your environment variables:\n')
    console.log(`STRIPE_PORTAL_CONFIGURATION=${res.portalConfiguration}`)
    if (res.webhookSecret) console.log(`STRIPE_WEBHOOK_SECRET=${res.webhookSecret}`)
    console.log(`\n(${key.startsWith('sk_live') ? 'LIVE' : 'TEST'} mode)`)
  })().catch(e => { console.error('Stripe setup failed:', e.message); process.exit(1) })
}

module.exports = { setup, parseArgs, WEBHOOK_EVENTS, TAX_CODE }
