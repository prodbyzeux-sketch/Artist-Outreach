// Google sign-in, sessions and access control.
//
// Flow: /auth/google → Google → /auth/google/callback → session cookie.
// No third-party auth library: it is the authorization-code flow with PKCE,
// and the id_token is received directly from Google's token endpoint over TLS
// (OIDC Core §3.1.3.7: in that case validating iss/aud/exp is enough).
//
// The cookie carries a random 32-byte token; the database only stores its
// sha256, so a leaked database does not hand out sessions.

const crypto = require('crypto')
const { PLANS, limitsFor } = require('../billing/plans')

const SESSION_COOKIE = 'ao_session'
const OAUTH_COOKIE = 'ao_oauth'
const GOOGLE_AUTH = 'https://accounts.google.com/o/oauth2/v2/auth'
const GOOGLE_TOKEN = 'https://oauth2.googleapis.com/token'

const b64url = buf => Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
const randomToken = (bytes = 32) => b64url(crypto.randomBytes(bytes))
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex')
const newUserId = () => 'u_' + randomToken(12)

function parseCookies(header) {
  const out = {}
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=')
    if (i < 0) continue
    const k = part.slice(0, i).trim()
    if (!k) continue
    try { out[k] = decodeURIComponent(part.slice(i + 1).trim()) } catch (_) {}
  }
  return out
}

function cookieString(name, value, { maxAge, secure, httpOnly = true, sameSite = 'Lax', path = '/' } = {}) {
  let c = `${name}=${encodeURIComponent(value)}; Path=${path}; SameSite=${sameSite}`
  if (httpOnly) c += '; HttpOnly'
  if (secure) c += '; Secure'
  if (maxAge != null) c += `; Max-Age=${Math.floor(maxAge)}`
  return c
}

function appendCookie(res, c) {
  const prev = res.getHeader('Set-Cookie')
  res.setHeader('Set-Cookie', prev ? [].concat(prev, c) : c)
}

// Internal paths only: "/x?y" yes, "//evil.com" or "https://..." no.
function safeNext(next) {
  if (typeof next !== 'string' || !next.startsWith('/') || next.startsWith('//') || next.startsWith('/\\')) return '/'
  return next.slice(0, 500)
}

function decodeJwtPayload(jwt) {
  const part = String(jwt || '').split('.')[1]
  if (!part) return null
  try { return JSON.parse(Buffer.from(part.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')) }
  catch (_) { return null }
}

// Can this user use the product? Admins, servers without billing (local
// development), or a live subscription. past_due counts as live: Stripe
// retries the charge for a few days and cutting access at the first failed
// card is hostile.
const LIVE = new Set(['active', 'trialing', 'past_due'])
function hasAccess(user, config) {
  if (!user) return false
  if (user.role === 'admin') return true
  if (!config.billingEnabled) return true
  return LIVE.has(user.sub_status)
}

function publicUser(user, config) {
  if (!user) return null
  const limits = limitsFor(user, config)
  const commitmentEnds = user.commitment_ends_at ? new Date(user.commitment_ends_at) : null
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    avatar: user.avatar_url,
    role: user.role,
    access: hasAccess(user, config),
    plan: {
      key: limits.plan,
      name: limits.plan ? PLANS[limits.plan].name : null,
      dailyAutoDms: limits.dailyAutoDms,
    },
    billing: {
      enabled: config.billingEnabled,
      status: user.sub_status || null,
      plan: user.plan || null,
      interval: user.plan_interval || null,
      currentPeriodEnd: user.sub_current_period_end || null,
      cancelScheduled: !!user.sub_cancel_at_period_end,
      endsAt: user.sub_cancel_at || null,
      commitmentEndsAt: commitmentEnds ? commitmentEnds.toISOString() : null,
      inCommitment: !!(commitmentEnds && commitmentEnds.getTime() > Date.now()),
      canTrial: config.stripe.trialDays > 0 && !user.had_trial,
      trialDays: config.stripe.trialDays,
    },
  }
}

function createAuth({ db, config, log = console.log, fetchImpl = fetch }) {
  const secure = config.publicUrl.startsWith('https://')
  const redirectUri = `${config.publicUrl}/auth/google/callback`

  // Short session → user cache: the client fires many requests in a row
  // (stream, Instagram batches, saves) and each would hit the database.
  const cache = new Map()   // sessionHash → { user, until }
  const CACHE_MS = 15 * 1000

  function invalidateUser(userId) {
    for (const [k, v] of cache) if (v.user.id === userId) cache.delete(k)
  }

  async function upsertGoogleUser({ sub, email, name, picture }) {
    email = String(email).toLowerCase()
    const role = config.adminEmails.includes(email) ? 'admin' : 'user'
    // By google_sub first; otherwise by email (an account created earlier
    // another way, e.g. the dev login) and the sub gets attached to it.
    const { rows } = await db.query('select * from users where google_sub = $1 or email = $2 order by (google_sub = $1) is true desc limit 1', [sub, email])
    if (rows[0]) {
      const u = rows[0]
      const { rows: up } = await db.query(
        `update users set google_sub = $2, email = $3, name = coalesce($4, name), avatar_url = coalesce($5, avatar_url),
                role = case when $6 = 'admin' then 'admin' else role end, last_login_at = now()
          where id = $1 returning *`,
        [u.id, sub, email, name || null, picture || null, role]
      )
      return up[0]
    }
    const { rows: ins } = await db.query(
      `insert into users (id, google_sub, email, name, avatar_url, role, last_login_at)
       values ($1, $2, $3, $4, $5, $6, now()) returning *`,
      [newUserId(), sub, email, name || null, picture || null, role]
    )
    log(`[auth] new user: ${email}${role === 'admin' ? ' (admin)' : ''}`)
    return ins[0]
  }

  async function createSession(res, user, userAgent) {
    const token = randomToken(32)
    const expires = new Date(Date.now() + config.sessionDays * 86400000)
    await db.query(
      'insert into sessions (id, user_id, expires_at, user_agent) values ($1, $2, $3, $4)',
      [sha256(token), user.id, expires.toISOString(), String(userAgent || '').slice(0, 300)]
    )
    appendCookie(res, cookieString(SESSION_COOKIE, token, { maxAge: config.sessionDays * 86400, secure }))
  }

  function allowedToSignIn(email) {
    email = String(email || '').toLowerCase()
    if (!config.allowedEmails.length) return true
    return config.allowedEmails.includes(email) || config.adminEmails.includes(email)
  }

  // ── middleware ─────────────────────────────────────────────────────────────
  async function loadUser(req, res, next) {
    req.user = null
    const token = parseCookies(req.headers.cookie)[SESSION_COOKIE]
    if (!token || token.length > 200) return next()
    const h = sha256(token)
    const hit = cache.get(h)
    if (hit && hit.until > Date.now()) { req.user = hit.user; req.sessionHash = h; return next() }
    try {
      const { rows } = await db.query(
        `select u.*, s.expires_at as session_expires from sessions s join users u on u.id = s.user_id
          where s.id = $1 and s.expires_at > now()`, [h])
      if (rows[0]) {
        req.user = rows[0]
        req.sessionHash = h
        cache.set(h, { user: rows[0], until: Date.now() + CACHE_MS })
        if (cache.size > 5000) cache.delete(cache.keys().next().value)
        // Sliding session: past half its life, it gets extended.
        const left = new Date(rows[0].session_expires).getTime() - Date.now()
        if (left < (config.sessionDays * 86400000) / 2) {
          const expires = new Date(Date.now() + config.sessionDays * 86400000)
          db.query('update sessions set expires_at = $2 where id = $1', [h, expires.toISOString()]).catch(() => {})
          appendCookie(res, cookieString(SESSION_COOKIE, token, { maxAge: config.sessionDays * 86400, secure }))
        }
      }
    } catch (e) {
      log(`[auth] could not read session: ${e.message}`)
    }
    next()
  }

  // Requests that change something must come from our own origin (Origin or
  // Sec-Fetch-Site). SameSite=Lax already blocks most; this closes the rest.
  function sameOrigin(req, res, next) {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next()
    const origin = req.headers.origin
    if (origin) {
      if (origin === config.publicOrigin) return next()
      return res.status(403).json({ error: 'bad_origin' })
    }
    const site = req.headers['sec-fetch-site']
    if (!site || site === 'same-origin' || site === 'none') return next()
    return res.status(403).json({ error: 'bad_origin' })
  }

  function requireUserApi(req, res, next) {
    if (!req.user) return res.status(401).json({ success: false, error: 'auth_required' })
    next()
  }

  function requireAccessApi(req, res, next) {
    if (!req.user) return res.status(401).json({ success: false, error: 'auth_required' })
    if (!hasAccess(req.user, config)) return res.status(402).json({ success: false, error: 'subscription_required' })
    next()
  }

  function requireUserPage(req, res, next) {
    if (!req.user) return res.redirect(302, '/login?next=' + encodeURIComponent(req.originalUrl))
    next()
  }

  function requireAccessPage(req, res, next) {
    if (!req.user) return res.redirect(302, '/login?next=' + encodeURIComponent(req.originalUrl))
    if (!hasAccess(req.user, config)) return res.redirect(302, '/billing')
    next()
  }

  // ── routes ─────────────────────────────────────────────────────────────────
  function mount(app) {
    app.get('/auth/google', (req, res) => {
      if (!config.googleEnabled) return res.status(503).send('Google sign-in is not configured (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET).')
      const state = randomToken(16)
      const verifier = randomToken(32)
      const challenge = b64url(crypto.createHash('sha256').update(verifier).digest())
      const nextUrl = safeNext(req.query.next)
      appendCookie(res, cookieString(OAUTH_COOKIE, JSON.stringify({ state, verifier, next: nextUrl }), { maxAge: 600, secure }))
      const params = new URLSearchParams({
        client_id: config.google.clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: 'openid email profile',
        state,
        code_challenge: challenge,
        code_challenge_method: 'S256',
        prompt: 'select_account',
      })
      res.redirect(302, `${GOOGLE_AUTH}?${params}`)
    })

    app.get('/auth/google/callback', async (req, res) => {
      const fail = (code, msg) => {
        log(`[auth] sign-in failed: ${msg}`)
        res.redirect(302, `/login?error=${encodeURIComponent(code)}`)
      }
      let saved = null
      try { saved = JSON.parse(parseCookies(req.headers.cookie)[OAUTH_COOKIE] || 'null') } catch (_) {}
      appendCookie(res, cookieString(OAUTH_COOKIE, '', { maxAge: 0, secure }))
      if (req.query.error) return fail('denied', `Google returned ${req.query.error}`)
      if (!saved || !saved.state || saved.state !== req.query.state) return fail('state', 'state mismatch (cookie lost or expired)')
      if (!req.query.code) return fail('code', 'no code')

      try {
        const r = await fetchImpl(GOOGLE_TOKEN, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            code: String(req.query.code),
            client_id: config.google.clientId,
            client_secret: config.google.clientSecret,
            redirect_uri: redirectUri,
            grant_type: 'authorization_code',
            code_verifier: saved.verifier,
          }),
        })
        const tok = await r.json().catch(() => ({}))
        if (!r.ok || !tok.id_token) return fail('token', `token endpoint ${r.status} ${tok.error || ''}`)
        const claims = decodeJwtPayload(tok.id_token)
        const now = Math.floor(Date.now() / 1000)
        if (!claims) return fail('token', 'unreadable id_token')
        if (!['accounts.google.com', 'https://accounts.google.com'].includes(claims.iss)) return fail('token', `iss ${claims.iss}`)
        if (claims.aud !== config.google.clientId) return fail('token', 'aud mismatch')
        if (!claims.exp || claims.exp < now) return fail('token', 'id_token expired')
        if (!claims.email || claims.email_verified === false) return fail('email', 'email not verified')
        if (!allowedToSignIn(claims.email)) return fail('invite', `${claims.email} is not on the access list`)

        const user = await upsertGoogleUser({ sub: claims.sub, email: claims.email, name: claims.name, picture: claims.picture })
        await createSession(res, user, req.headers['user-agent'])
        res.redirect(302, safeNext(saved.next))
      } catch (e) {
        fail('server', e.message)
      }
    })

    // Sign-in without Google, local only (DEV_LOGIN=1 and NODE_ENV != production).
    app.get('/auth/dev', async (req, res) => {
      if (!config.devLogin) return res.status(404).send('Not found')
      const email = String(req.query.email || 'dev@localhost').toLowerCase()
      if (!/^[^@\s]+@[^@\s]+$/.test(email)) return res.status(400).send('Invalid email')
      const user = await upsertGoogleUser({ sub: 'dev:' + email, email, name: email.split('@')[0], picture: null })
      await createSession(res, user, req.headers['user-agent'])
      res.redirect(302, safeNext(req.query.next))
    })

    app.post('/auth/logout', sameOrigin, async (req, res) => {
      if (req.sessionHash) {
        cache.delete(req.sessionHash)
        await db.query('delete from sessions where id = $1', [req.sessionHash]).catch(() => {})
      }
      appendCookie(res, cookieString(SESSION_COOKIE, '', { maxAge: 0, secure }))
      if ((req.headers.accept || '').includes('application/json')) return res.json({ success: true })
      res.redirect(302, '/login')
    })

    // /api/me lives in server/index.js (it adds app-level info).

    app.get('/auth/providers', (req, res) => res.json({ google: config.googleEnabled, dev: config.devLogin }))
  }

  // Expired sessions are cleaned up once a day.
  setInterval(() => { db.query('delete from sessions where expires_at < now()').catch(() => {}) }, 86400000).unref()

  return {
    mount, loadUser, sameOrigin,
    requireUserApi, requireAccessApi, requireUserPage, requireAccessPage,
    invalidateUser, hasAccess: u => hasAccess(u, config), publicUser: u => publicUser(u, config),
    limits: u => limitsFor(u, config),
  }
}

module.exports = { createAuth, parseCookies, safeNext, sha256, randomToken, hasAccess, decodeJwtPayload }
