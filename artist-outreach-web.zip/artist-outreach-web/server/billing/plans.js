// The plan catalog. One place that says what each plan costs, what it allows
// and which Stripe price it maps to.
//
//   Starter  €7/month  or €67.20/year (20% off €84)   — 10 automated DMs a day
//   Pro      €17/month or €163.20/year (20% off €204) — no limits
//
// Monthly plans carry a 12-month commitment: they bill every month, and a
// cancellation only takes effect once 12 months have been paid. Yearly plans
// are paid up front and simply don't renew when cancelled.
//
// Stripe prices are found by lookup key (created by scripts/stripe-setup.js),
// so no price IDs need to be copied into env vars. STRIPE_PRICE_<PLAN>_<INTERVAL>
// overrides a lookup when set.

const COMMITMENT_MONTHS = 12

const PLANS = {
  starter: {
    key: 'starter',
    name: 'Starter',
    dailyAutoDms: 10,
    features: [
      'Similar-artist discovery',
      'Instagram follower verification',
      'Saved lists, folders and CSV export',
      '10 automated DMs per day',
      'Inbox CRM for replies',
    ],
    prices: {
      month: { amount: 700, lookupKey: 'ao_starter_monthly', commitmentMonths: COMMITMENT_MONTHS },
      year: { amount: 6720, lookupKey: 'ao_starter_yearly', commitmentMonths: 0, fullPrice: 8400 },
    },
  },
  pro: {
    key: 'pro',
    name: 'Pro',
    dailyAutoDms: null, // unlimited
    features: [
      'Everything in Starter',
      'Unlimited automated DMs',
      'Follow-up sequences at any volume',
    ],
    prices: {
      month: { amount: 1700, lookupKey: 'ao_pro_monthly', commitmentMonths: COMMITMENT_MONTHS },
      year: { amount: 16320, lookupKey: 'ao_pro_yearly', commitmentMonths: 0, fullPrice: 20400 },
    },
  },
}

const CURRENCY = 'eur'
const INTERVALS = ['month', 'year']
const PLAN_KEYS = Object.keys(PLANS)

const isPlan = k => PLAN_KEYS.includes(k)
const isInterval = i => INTERVALS.includes(i)

// The public view of the catalog, for the billing page.
function publicCatalog() {
  return {
    currency: CURRENCY,
    commitmentMonths: COMMITMENT_MONTHS,
    plans: PLAN_KEYS.map(k => {
      const p = PLANS[k]
      return {
        key: k,
        name: p.name,
        dailyAutoDms: p.dailyAutoDms,
        features: p.features,
        prices: Object.fromEntries(INTERVALS.map(i => [i, {
          amount: p.prices[i].amount,
          fullPrice: p.prices[i].fullPrice || null,
          commitmentMonths: p.prices[i].commitmentMonths,
        }])),
      }
    }),
  }
}

// Resolves { plan, interval } → Stripe price id, and back. Built once at
// startup (and again if a lookup failed), then kept in memory.
function createPriceBook({ stripe, env = process.env, log = console.log }) {
  const byKey = new Map()   // `${plan}:${interval}` → price id
  const byPrice = new Map() // price id → { plan, interval }
  let loaded = false

  function set(plan, interval, id) {
    byKey.set(`${plan}:${interval}`, id)
    byPrice.set(id, { plan, interval })
  }

  async function load() {
    const missing = []
    for (const plan of PLAN_KEYS) {
      for (const interval of INTERVALS) {
        const override = env[`STRIPE_PRICE_${plan.toUpperCase()}_${interval === 'month' ? 'MONTHLY' : 'YEARLY'}`]
        if (override) set(plan, interval, override)
        else missing.push({ plan, interval, lookupKey: PLANS[plan].prices[interval].lookupKey })
      }
    }
    if (missing.length && stripe) {
      try {
        const res = await stripe.prices.list({ lookup_keys: missing.map(m => m.lookupKey), active: true, limit: 20 })
        for (const price of res.data) {
          const m = missing.find(x => x.lookupKey === price.lookup_key)
          if (m) set(m.plan, m.interval, price.id)
        }
      } catch (e) {
        log(`[billing] could not load prices from Stripe: ${e.message}`)
        return false
      }
    }
    const still = missing.filter(m => !byKey.has(`${m.plan}:${m.interval}`))
    if (still.length) log(`[billing] WARNING: no Stripe price for ${still.map(m => m.lookupKey).join(', ')} — run scripts/stripe-setup.js`)
    loaded = still.length === 0
    return loaded
  }

  return {
    load,
    get loaded() { return loaded },
    async priceId(plan, interval) {
      if (!byKey.has(`${plan}:${interval}`)) await load()
      return byKey.get(`${plan}:${interval}`) || null
    },
    // Unknown prices (a manual Dashboard price, an old plan) still map to a
    // plan via the price's own metadata when the webhook carries it.
    describe(price) {
      if (!price) return null
      const id = typeof price === 'string' ? price : price.id
      const known = byPrice.get(id)
      if (known) return known
      const md = typeof price === 'object' ? price.metadata || {} : {}
      if (isPlan(md.plan)) {
        const interval = price.recurring?.interval === 'year' ? 'year' : 'month'
        return { plan: md.plan, interval }
      }
      return null
    },
    _set: set,
  }
}

// What a user's plan allows. Admins and servers without billing get Pro.
function limitsFor(user, { billingEnabled }) {
  if (!user) return { plan: null, dailyAutoDms: 0 }
  if (user.role === 'admin' || !billingEnabled) return { plan: 'pro', dailyAutoDms: null }
  const plan = isPlan(user.plan) ? user.plan : 'starter'
  return { plan, dailyAutoDms: PLANS[plan].dailyAutoDms }
}

function addMonths(date, months) {
  const d = new Date(date)
  const day = d.getUTCDate()
  d.setUTCDate(1)
  d.setUTCMonth(d.getUTCMonth() + months)
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate()
  d.setUTCDate(Math.min(day, last))
  return d
}

module.exports = {
  PLANS, PLAN_KEYS, INTERVALS, CURRENCY, COMMITMENT_MONTHS,
  isPlan, isInterval, publicCatalog, createPriceBook, limitsFor, addMonths,
}
