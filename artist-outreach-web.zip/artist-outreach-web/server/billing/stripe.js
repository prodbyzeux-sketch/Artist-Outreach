// Subscriptions with Stripe.
//
//   GET  /billing/plans     the catalog (public)
//   POST /billing/checkout  Stripe Checkout for { plan, interval }
//   POST /billing/cancel    cancel, honouring the 12-month commitment of monthly plans
//   POST /billing/resume    undo a scheduled cancellation
//   POST /billing/upgrade   Starter → Pro on the same billing interval
//   POST /billing/portal    Stripe Customer Portal (card, invoices, billing details)
//   GET  /billing/return    back from Checkout: sync without waiting for the webhook
//   POST /billing/webhook   Stripe events
//
// Stripe is the source of truth; the subscription state is mirrored into the
// users table so access checks don't call Stripe on every request.
//
// The commitment: a monthly plan bills every month, and cancelling before the
// 12th payment schedules the end of the subscription for the end of month 12
// (Stripe `cancel_at`). The Customer Portal must therefore NOT offer
// cancellation — scripts/stripe-setup.js creates a portal configuration
// without it; set its id in STRIPE_PORTAL_CONFIGURATION.
//
// STRIPE_MANAGED_PAYMENTS=1 makes Stripe the merchant of record (it collects
// and files VAT/sales tax in each country, +3.5% per transaction). Note that
// with Managed Payments customers can also cancel from link.com, outside this
// app — the commitment can't be enforced there.

const express = require('express')
const { PLANS, isPlan, isInterval, publicCatalog, createPriceBook, addMonths } = require('./plans')

const LIVE = ['active', 'trialing', 'past_due']
const toIso = unix => (unix ? new Date(unix * 1000).toISOString() : null)

function createBilling({ db, config, auth, log = console.log, stripeClient = null, env = process.env }) {
  const enabled = config.billingEnabled
  let stripe = stripeClient
  if (!stripe && config.stripe.secretKey) {
    const Stripe = require('stripe')
    stripe = new Stripe(config.stripe.secretKey)
  }
  const prices = createPriceBook({ stripe, env, log })
  if (enabled) prices.load().catch(() => {})

  async function ensureCustomer(user) {
    if (user.stripe_customer_id) return user.stripe_customer_id
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name || undefined,
      metadata: { userId: user.id },
    })
    await db.query('update users set stripe_customer_id = $2 where id = $1', [user.id, customer.id])
    auth.invalidateUser(user.id)
    return customer.id
  }

  // Mirror one Stripe subscription onto the user who owns its customer.
  async function syncSubscription(sub) {
    if (!sub) return null
    const customerId = typeof sub.customer === 'string' ? sub.customer : sub.customer?.id
    const item = sub.items?.data?.[0]
    const described = prices.describe(item?.price) ||
      (isPlan(sub.metadata?.plan) ? { plan: sub.metadata.plan, interval: isInterval(sub.metadata?.interval) ? sub.metadata.interval : 'month' } : null)
    const plan = described?.plan || null
    const interval = described?.interval || null
    // Newer API versions keep the period on the item.
    const periodEnd = item?.current_period_end || sub.current_period_end || null
    const commitmentMonths = interval === 'month'
      ? parseInt(sub.metadata?.commitment_months ?? PLANS[plan]?.prices.month.commitmentMonths ?? 0, 10) || 0
      : 0
    const commitmentEnds = commitmentMonths && sub.start_date ? addMonths(new Date(sub.start_date * 1000), commitmentMonths).toISOString() : null
    const cancelAt = sub.cancel_at ? toIso(sub.cancel_at) : sub.cancel_at_period_end ? toIso(periodEnd) : null

    const params = [
      customerId, sub.status, plan, interval, item?.price?.id || null, sub.id,
      toIso(periodEnd), !!(sub.cancel_at_period_end || sub.cancel_at), cancelAt, commitmentEnds,
      sub.status === 'trialing' || !!sub.trial_end,
    ]
    const SET = `sub_status = $2, plan = $3, plan_interval = $4, plan_price = $5, stripe_subscription_id = $6,
                 sub_current_period_end = $7, sub_cancel_at_period_end = $8, sub_cancel_at = $9,
                 commitment_ends_at = $10, had_trial = had_trial or $11`
    let { rows } = await db.query(`update users set ${SET} where stripe_customer_id = $1 returning id, email`, params)
    // A customer created outside Checkout (Payment Link, Dashboard) is matched by metadata.
    const userIdMeta = sub.metadata?.userId || null
    if (!rows.length && userIdMeta) {
      ({ rows } = await db.query(
        `update users set stripe_customer_id = $1, ${SET} where id = $12 and (stripe_customer_id is null or stripe_customer_id = $1) returning id, email`,
        [...params, userIdMeta]))
    }
    for (const r of rows) {
      auth.invalidateUser(r.id)
      log(`[billing] ${r.email}: ${plan || '?'}/${interval || '?'} ${sub.status}`)
    }
    return rows[0] || null
  }

  // Several subscriptions are possible (an old cancelled one and a new one):
  // the live one wins.
  async function syncCustomer(customerId) {
    const list = await stripe.subscriptions.list({ customer: customerId, status: 'all', limit: 10 })
    const rank = s => ({ active: 5, trialing: 5, past_due: 4, unpaid: 3, incomplete: 2 }[s.status] || 1)
    const best = [...list.data].sort((a, b) => rank(b) - rank(a) || b.created - a.created)[0]
    if (best) return syncSubscription(best)
    await db.query(`update users set sub_status = 'canceled' where stripe_customer_id = $1`, [customerId])
    return null
  }

  async function currentSubscription(user) {
    if (user.stripe_subscription_id) {
      try { return await stripe.subscriptions.retrieve(user.stripe_subscription_id) } catch (_) {}
    }
    if (!user.stripe_customer_id) return null
    const list = await stripe.subscriptions.list({ customer: user.stripe_customer_id, status: 'all', limit: 10 })
    return list.data.find(s => LIVE.includes(s.status)) || null
  }

  function mount(app) {
    // The webhook needs the RAW body to verify the signature, so it is
    // mounted before the global express.json() (see server/index.js).
    app.post('/billing/webhook', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
      if (!enabled || !config.stripe.webhookSecret) return res.status(503).send('billing disabled')
      let event
      try {
        event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], config.stripe.webhookSecret)
      } catch (e) {
        log(`[billing] webhook with an invalid signature: ${e.message}`)
        return res.status(400).send('bad signature')
      }
      try {
        const { rows } = await db.query(
          'insert into stripe_events (id, type) values ($1, $2) on conflict do nothing returning id', [event.id, event.type])
        if (!rows.length) return res.json({ received: true, duplicate: true })

        const obj = event.data.object
        switch (event.type) {
          case 'checkout.session.completed': {
            if (obj.mode !== 'subscription') break
            const userId = obj.client_reference_id || obj.metadata?.userId
            const customerId = typeof obj.customer === 'string' ? obj.customer : obj.customer?.id
            if (userId && customerId) {
              await db.query('update users set stripe_customer_id = $2 where id = $1 and (stripe_customer_id is null or stripe_customer_id = $2)', [userId, customerId])
            }
            if (customerId) await syncCustomer(customerId)
            break
          }
          case 'customer.subscription.created':
          case 'customer.subscription.updated':
          case 'customer.subscription.deleted':
          case 'customer.subscription.paused':
          case 'customer.subscription.resumed':
            await syncSubscription(obj)
            break
          case 'invoice.paid':
          case 'invoice.payment_failed': {
            const customerId = typeof obj.customer === 'string' ? obj.customer : obj.customer?.id
            if (customerId) await syncCustomer(customerId)
            break
          }
          default:
            break
        }
        res.json({ received: true })
      } catch (e) {
        log(`[billing] error handling ${event.type}: ${e.message}`)
        // Let Stripe retry: forget that we saw it.
        await db.query('delete from stripe_events where id = $1', [event.id]).catch(() => {})
        res.status(500).send('error')
      }
    })

    app.get('/billing/plans', (req, res) => res.json({ success: true, enabled, ...publicCatalog() }))
  }

  function mountUserRoutes(app) {
    const guard = [auth.sameOrigin, auth.requireUserApi]
    const off = res => res.status(503).json({ success: false, error: 'billing_disabled' })
    const fail = (res, where, req, e) => {
      log(`[billing] ${where} ${req.user.email}: ${e.message}`)
      res.status(500).json({ success: false, error: e.message })
    }

    app.post('/billing/checkout', ...guard, async (req, res) => {
      if (!enabled) return off(res)
      try {
        const user = req.user
        if (LIVE.includes(user.sub_status)) return res.json({ success: false, error: 'already_subscribed' })
        const plan = isPlan(req.body?.plan) ? req.body.plan : null
        const interval = isInterval(req.body?.interval) ? req.body.interval : null
        if (!plan || !interval) return res.status(400).json({ success: false, error: 'plan_and_interval_required' })
        const price = await prices.priceId(plan, interval)
        if (!price) return res.status(503).json({ success: false, error: 'price_not_configured' })

        const def = PLANS[plan].prices[interval]
        const customer = await ensureCustomer(user)
        const meta = { userId: user.id, plan, interval, commitment_months: String(def.commitmentMonths) }
        const params = {
          mode: 'subscription',
          customer,
          client_reference_id: user.id,
          line_items: [{ price, quantity: 1 }],
          allow_promotion_codes: true,
          success_url: `${config.publicUrl}/billing/return?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${config.publicUrl}/billing?status=cancel`,
          subscription_data: { metadata: meta },
          metadata: meta,
        }
        // The commitment has to be stated where the customer pays, not only in our UI.
        if (def.commitmentMonths) {
          const euros = (def.amount / 100).toFixed(2).replace(/\.00$/, '')
          params.custom_text = { submit: { message:
            `Monthly plan with a ${def.commitmentMonths}-month commitment: you are billed €${euros} every month ` +
            `and your subscription can end after your ${def.commitmentMonths}th payment.` } }
        }
        if (config.stripe.trialDays > 0 && !user.had_trial) {
          params.subscription_data.trial_period_days = config.stripe.trialDays
        }
        if (config.stripe.managedPayments) params.managed_payments = { enabled: true }
        const session = await stripe.checkout.sessions.create(params)
        res.json({ success: true, url: session.url })
      } catch (e) { fail(res, 'checkout', req, e) }
    })

    app.post('/billing/cancel', ...guard, async (req, res) => {
      if (!enabled) return off(res)
      try {
        const sub = await currentSubscription(req.user)
        if (!sub || !LIVE.includes(sub.status)) return res.json({ success: false, error: 'no_subscription' })
        await syncSubscription(sub)
        const { rows } = await db.query('select commitment_ends_at from users where id = $1', [req.user.id])
        const commitmentEnd = rows[0]?.commitment_ends_at ? new Date(rows[0].commitment_ends_at) : null
        let updated
        if (commitmentEnd && commitmentEnd.getTime() > Date.now() + 60_000) {
          // Still inside the commitment: it ends with the 12th month, not before.
          updated = await stripe.subscriptions.update(sub.id, {
            cancel_at: Math.floor(commitmentEnd.getTime() / 1000),
            proration_behavior: 'none',
          })
        } else {
          updated = await stripe.subscriptions.update(sub.id, { cancel_at_period_end: true })
        }
        await syncSubscription(updated)
        const { rows: after } = await db.query('select sub_cancel_at from users where id = $1', [req.user.id])
        res.json({ success: true, endsAt: after[0]?.sub_cancel_at || null, commitment: !!(commitmentEnd && commitmentEnd > new Date()) })
      } catch (e) { fail(res, 'cancel', req, e) }
    })

    app.post('/billing/resume', ...guard, async (req, res) => {
      if (!enabled) return off(res)
      try {
        const sub = await currentSubscription(req.user)
        if (!sub || !LIVE.includes(sub.status)) return res.json({ success: false, error: 'no_subscription' })
        const params = sub.cancel_at && !sub.cancel_at_period_end ? { cancel_at: '' } : { cancel_at_period_end: false }
        const updated = await stripe.subscriptions.update(sub.id, params)
        await syncSubscription(updated)
        res.json({ success: true })
      } catch (e) { fail(res, 'resume', req, e) }
    })

    // Starter → Pro, same interval, charged the prorated difference now. The
    // commitment keeps its original start date. Downgrades are not offered.
    app.post('/billing/upgrade', ...guard, async (req, res) => {
      if (!enabled) return off(res)
      try {
        const sub = await currentSubscription(req.user)
        if (!sub || !LIVE.includes(sub.status)) return res.json({ success: false, error: 'no_subscription' })
        const item = sub.items?.data?.[0]
        const now = prices.describe(item?.price) || { plan: req.user.plan, interval: req.user.plan_interval }
        if (now.plan === 'pro') return res.json({ success: false, error: 'already_pro' })
        const interval = isInterval(now.interval) ? now.interval : 'month'
        const price = await prices.priceId('pro', interval)
        if (!price) return res.status(503).json({ success: false, error: 'price_not_configured' })
        const updated = await stripe.subscriptions.update(sub.id, {
          items: [{ id: item.id, price }],
          proration_behavior: 'always_invoice',
          metadata: { ...(sub.metadata || {}), plan: 'pro' },
        })
        await syncSubscription(updated)
        res.json({ success: true })
      } catch (e) { fail(res, 'upgrade', req, e) }
    })

    app.post('/billing/portal', ...guard, async (req, res) => {
      if (!enabled) return off(res)
      try {
        if (!req.user.stripe_customer_id) return res.json({ success: false, error: 'no_customer' })
        const params = { customer: req.user.stripe_customer_id, return_url: `${config.publicUrl}/billing` }
        if (config.stripe.portalConfiguration) params.configuration = config.stripe.portalConfiguration
        const portal = await stripe.billingPortal.sessions.create(params)
        res.json({ success: true, url: portal.url })
      } catch (e) { fail(res, 'portal', req, e) }
    })

    // Back from Checkout. The webhook may take a few seconds; ask Stripe
    // directly so the user gets in on the first try.
    app.get('/billing/return', auth.requireUserPage, async (req, res) => {
      if (!enabled) return res.redirect(302, '/')
      try {
        const session = await stripe.checkout.sessions.retrieve(String(req.query.session_id || ''))
        const customerId = typeof session.customer === 'string' ? session.customer : session.customer?.id
        const owner = session.client_reference_id || session.metadata?.userId
        if (owner === req.user.id && customerId) {
          await db.query('update users set stripe_customer_id = $2 where id = $1 and (stripe_customer_id is null or stripe_customer_id = $2)', [req.user.id, customerId])
          await syncCustomer(customerId)
        }
      } catch (e) {
        log(`[billing] return ${req.user.email}: ${e.message}`)
      }
      res.redirect(302, '/billing?status=success')
    })
  }

  return { mount, mountUserRoutes, syncSubscription, syncCustomer, prices, enabled }
}

module.exports = { createBilling }
