// All configuration comes from environment variables (see .env.example).
// One place reads them: the rest of the code gets this object and never
// touches process.env, so tests can boot the server with whatever they need.

const path = require('path')

const bool = (v, def = false) => {
  if (v == null || v === '') return def
  return /^(1|true|yes|on)$/i.test(String(v).trim())
}
const int = (v, def) => {
  const n = parseInt(v, 10)
  return Number.isFinite(n) ? n : def
}
const list = v => String(v || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean)

function loadConfig(env = process.env) {
  const port = int(env.PORT, 3456)
  const production = env.NODE_ENV === 'production'
  const publicUrl = (env.PUBLIC_URL || `http://localhost:${port}`).replace(/\/+$/, '')

  const cfg = {
    port,
    production,
    publicUrl,
    publicOrigin: new URL(publicUrl).origin,
    dataDir: path.resolve(env.DATA_DIR || path.join(__dirname, '..', 'data')),
    databaseUrl: env.DATABASE_URL || null,

    // ── Sign-in ────────────────────────────────────────────────────────────
    google: {
      clientId: env.GOOGLE_CLIENT_ID || null,
      clientSecret: env.GOOGLE_CLIENT_SECRET || null,
    },
    // Sign-in without Google for local development. Never in production.
    devLogin: bool(env.DEV_LOGIN) && !production,
    adminEmails: list(env.ADMIN_EMAILS),
    // When set, only these emails (and admins) can sign in: a closed beta.
    allowedEmails: list(env.ALLOWED_EMAILS),
    sessionDays: int(env.SESSION_DAYS, 30),

    // ── Subscriptions (Stripe) ─────────────────────────────────────────────
    // Plans and prices live in server/billing/plans.js; Stripe prices are
    // found by lookup key (scripts/stripe-setup.js creates them).
    stripe: {
      secretKey: env.STRIPE_SECRET_KEY || null,
      webhookSecret: env.STRIPE_WEBHOOK_SECRET || null,
      // Customer Portal configuration WITHOUT cancellation (bpc_...), so the
      // 12-month commitment can't be skipped from the portal.
      portalConfiguration: env.STRIPE_PORTAL_CONFIGURATION || null,
      // Stripe Managed Payments: Stripe is the merchant of record and handles
      // VAT/sales tax in each country (+3.5% per transaction).
      managedPayments: bool(env.STRIPE_MANAGED_PAYMENTS),
      trialDays: int(env.TRIAL_DAYS, 0),
    },

    // ── The extension ──────────────────────────────────────────────────────
    extension: {
      // Chrome Web Store listing, once published. Until then users download
      // the zip the server builds (/downloads/artist-outreach-extension.zip).
      storeUrl: env.EXTENSION_STORE_URL || null,
      downloadUrl: '/downloads/artist-outreach-extension.zip',
    },

    // ── Legal ──────────────────────────────────────────────────────────────
    legal: {
      company: env.LEGAL_COMPANY_NAME || '[Company name]',
      contactEmail: env.LEGAL_CONTACT_EMAIL || '[contact email]',
      address: env.LEGAL_ADDRESS || '[registered address]',
    },

    // ── Discovery engine ───────────────────────────────────────────────────
    engine: {
      // Searches at the same time (they share one Chromium). Each opens
      // several tabs; on a 2 GB machine 2-3 is a sensible ceiling.
      maxConcurrentCrawls: int(env.MAX_CONCURRENT_CRAWLS, 3),
      // Instagram lookups from the server. From datacenter IPs Instagram blocks
      // quickly; with the extension installed lookups happen in the user's
      // browser instead and this can be off.
      igServerLookups: bool(env.IG_SERVER_LOOKUPS, true),
      // Google search for Instagram handles Spotify doesn't link (Pool B).
      googleSearch: bool(env.GOOGLE_SEARCH, true),
      // Proxy for the engine's Chromium (Spotify/Instagram/Google). Optional.
      browserProxy: env.BROWSER_PROXY || null,
      bootstrapOnStart: bool(env.SPOTIFY_BOOTSTRAP_ON_START, true),
    },
  }

  cfg.billingEnabled = !!cfg.stripe.secretKey
  cfg.googleEnabled = !!(cfg.google.clientId && cfg.google.clientSecret)
  return cfg
}

module.exports = { loadConfig }
