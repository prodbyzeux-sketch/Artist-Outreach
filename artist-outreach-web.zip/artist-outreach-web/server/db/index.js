// Database access. Two engines behind the same interface:
//
//   DATABASE_URL set   → real Postgres (Neon, Supabase, Railway...).
//   No DATABASE_URL    → PGlite: Postgres compiled to WASM, stored in
//                        DATA_DIR/pglite. For local development and tests
//                        without installing anything. NOT for production.
//
// Both return { rows } and take $1, $2... parameters — the rest of the code
// doesn't know which one is underneath.

const fs = require('fs')
const path = require('path')

const SCHEMA = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8')

async function createDb({ databaseUrl, dataDir, memory = false, log = console.log } = {}) {
  let db
  if (databaseUrl) {
    const { Pool } = require('pg')
    const pool = new Pool({ connectionString: databaseUrl, max: 10, idleTimeoutMillis: 30_000 })
    pool.on('error', e => log(`[db] idle connection error: ${e.message}`))
    db = {
      kind: 'postgres',
      query: (text, params) => pool.query(text, params),
      exec: text => pool.query(text),
      close: () => pool.end(),
    }
  } else {
    const { PGlite } = require('@electric-sql/pglite')
    let pg
    if (memory) {
      pg = new PGlite()
    } else {
      const dir = path.join(dataDir, 'pglite')
      fs.mkdirSync(dir, { recursive: true })
      pg = new PGlite(dir)
    }
    await pg.waitReady
    db = {
      kind: 'pglite',
      query: (text, params) => pg.query(text, params),
      exec: text => pg.exec(text),
      close: () => pg.close(),
    }
    if (!memory) log(`[db] local PGlite at ${path.join(dataDir, 'pglite')} (development only)`)
  }
  await db.exec(SCHEMA)
  return db
}

// bytea arrives as a Buffer (pg) or a Uint8Array (PGlite).
const toBuffer = v => (v == null ? null : Buffer.isBuffer(v) ? v : Buffer.from(v))

module.exports = { createDb, toBuffer }
