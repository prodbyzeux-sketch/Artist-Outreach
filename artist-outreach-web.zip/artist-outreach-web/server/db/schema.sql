-- Artist Outreach web schema. Idempotent: it runs on every start.
-- For future changes, append "alter table ... add column if not exists"
-- statements at the end instead of editing the ones above.

create table if not exists users (
  id                       text primary key,
  google_sub               text unique,
  email                    text unique not null,
  name                     text,
  avatar_url               text,
  role                     text not null default 'user',      -- 'user' | 'admin'
  stripe_customer_id       text unique,
  plan                     text,                               -- price id de Stripe
  sub_status               text,                               -- trialing | active | past_due | canceled | ...
  sub_current_period_end   timestamptz,
  sub_cancel_at_period_end boolean not null default false,
  had_trial                boolean not null default false,
  created_at               timestamptz not null default now(),
  last_login_at            timestamptz
);

-- The cookie carries a random token; only its sha256 is stored here.
create table if not exists sessions (
  id          text primary key,
  user_id     text not null references users(id) on delete cascade,
  created_at  timestamptz not null default now(),
  expires_at  timestamptz not null,
  user_agent  text
);
create index if not exists sessions_user_idx on sessions(user_id);

-- Extension tokens (Bearer). Also only the hash.
create table if not exists ext_tokens (
  id           text primary key,
  user_id      text not null references users(id) on delete cascade,
  label        text,
  created_at   timestamptz not null default now(),
  last_used_at timestamptz
);
create index if not exists ext_tokens_user_idx on ext_tokens(user_id);

-- Saved prospects. `rec` is the record exactly as the client expects it
-- (same format as the desktop app's artists.json); the columns below are
-- derived from it to filter and index without duplicating the truth.
create table if not exists prospects (
  user_id      text not null references users(id) on delete cascade,
  id           text not null,
  seq          bigint generated always as identity,
  rec          jsonb not null,
  status       text generated always as (rec->>'status') stored,
  folder_id    text generated always as (rec->>'folder_id') stored,
  ig_handle    text generated always as (lower(ltrim(rec->>'instagram_handle', '@'))) stored,
  saved_at     text generated always as (rec->>'saved_at') stored,
  contacted_at text generated always as (rec->>'contacted_at') stored,
  updated_at   timestamptz not null default now(),
  primary key (user_id, id)
);
create index if not exists prospects_user_seq_idx on prospects(user_id, seq desc);
create index if not exists prospects_user_ig_idx on prospects(user_id, ig_handle);

create table if not exists folders (
  user_id text not null references users(id) on delete cascade,
  id      text not null,
  name    text not null,
  ts      bigint not null,
  primary key (user_id, id)
);

-- "Already shown to you": artists that must not come up in the Finder again.
create table if not exists seen (
  user_id   text not null references users(id) on delete cascade,
  artist_id text not null,
  primary key (user_id, artist_id)
);

create table if not exists user_config (
  user_id text primary key references users(id) on delete cascade,
  config  jsonb not null default '{}'::jsonb
);

-- Co-listening graph + the user's votes (lib/affinityStore.js), gzipped.
create table if not exists affinity (
  user_id    text primary key references users(id) on delete cascade,
  blob       bytea not null,
  updated_at timestamptz not null default now()
);

-- Results of each search by reference artist (lib/poolStore.js), gzipped.
create table if not exists pools (
  user_id    text not null references users(id) on delete cascade,
  ref_id     text not null,
  name       text,
  ts         bigint not null,
  blob       bytea not null,
  primary key (user_id, ref_id)
);

-- Confirmed Instagram follower counts. SHARED between users: a profile
-- verified by one saves the lookup for everyone else.
create table if not exists ig_cache (
  username  text primary key,
  followers integer not null,
  ts        bigint not null,
  source    text
);

-- What the extension did with each prospect (sent, failed, replied).
create table if not exists outreach_events (
  id          bigint generated always as identity primary key,
  user_id     text not null references users(id) on delete cascade,
  prospect_id text,
  handle      text not null,
  state       text not null,
  at          timestamptz not null,
  campaign    text,
  created_at  timestamptz not null default now()
);
create index if not exists outreach_events_user_idx on outreach_events(user_id, created_at desc);

-- Idempotencia de webhooks de Stripe.
create table if not exists stripe_events (
  id         text primary key,
  type       text,
  created_at timestamptz not null default now()
);

-- ── v5.1: plans, 12-month commitment, daily DM quota ────────────────────────
alter table users add column if not exists plan_interval text;            -- month | year
alter table users add column if not exists plan_price text;               -- Stripe price id
alter table users add column if not exists stripe_subscription_id text;
alter table users add column if not exists sub_cancel_at timestamptz;     -- when a scheduled cancellation takes effect
alter table users add column if not exists commitment_ends_at timestamptz;

-- Automated DMs sent per user and local day (the extension claims one before
-- each send). Starter is capped; Pro is only counted.
create table if not exists dm_usage (
  user_id text not null references users(id) on delete cascade,
  day     text not null,              -- YYYY-MM-DD in the user's timezone
  count   integer not null default 0,
  primary key (user_id, day)
);
