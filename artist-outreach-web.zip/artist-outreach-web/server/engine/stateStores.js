// Engine state that lived in data/ files on the desktop:
//
//   affinity/global.json   → table `affinity`  (per user: their graph and votes)
//   pools/<refId>.json     → table `pools`     (per user and reference artist)
//   ig-followers.json      → table `ig_cache`  (SHARED between all users)
//
// The formats are the same as lib/affinityStore.js and lib/poolStore.js,
// gzipped. The logic of when to write (debounce, flush at the end of a crawl)
// is kept exactly as it was in server.js.

const zlib = require('zlib')
const { toBuffer } = require('../db')
const { addEdge, propagate } = require('../lib/affinity')
const { serializeAffinity, deserializeAffinity } = require('../lib/affinityStore')
const { packArtist, unpackArtist, mergePool } = require('../lib/poolStore')

const gz = obj => zlib.gzipSync(Buffer.from(JSON.stringify(obj)))
const ungz = buf => JSON.parse(zlib.gunzipSync(toBuffer(buf)).toString('utf8'))

// ─── Affinity (per user) ─────────────────────────────────────────────────────
// One graph per user, as on the desktop: each user only sees what their own
// searches walked through, and their votes don't touch anyone else's ranking.
// Active users stay in RAM; the rest live in the database.
const AFFINITY_FLUSH_MS = 1500
const AFFINITY_HOT_MAX = 25

function createAffinityStores(db, log = console.log) {
  const hot = new Map()          // userId → store
  const loading = new Map()      // userId → Promise<store>

  async function flush(store) {
    if (!store) return
    clearTimeout(store.timer)
    store.timer = null
    if (!store.dirty) return
    store.dirty = false
    try {
      const blob = gz(serializeAffinity(store.adj, store.seeds, 'global'))
      await db.query(
        `insert into affinity (user_id, blob, updated_at) values ($1, $2, now())
         on conflict (user_id) do update set blob = excluded.blob, updated_at = now()`,
        [store.userId, blob]
      )
    } catch (e) {
      store.dirty = true
      log(`[affinity-store] ERROR guardando ${store.userId}: ${e.message}`)
    }
  }

  async function evictIfNeeded() {
    while (hot.size > AFFINITY_HOT_MAX) {
      const [oldestId, oldest] = hot.entries().next().value
      hot.delete(oldestId)
      await flush(oldest)
    }
  }

  async function read(userId) {
    const adj = new Map(), seeds = new Map()
    try {
      const { rows } = await db.query('select blob from affinity where user_id = $1', [userId])
      if (rows[0]) {
        const parsed = deserializeAffinity(ungz(rows[0].blob))
        if (parsed) {
          for (const [a, nbs] of parsed.adj) for (const b of nbs) addEdge(adj, a, b)
          for (const [id, v] of parsed.seeds) seeds.set(id, v)
        } else {
          log(`[affinity-store] ${userId}: blob corrupto — se empieza de cero`)
        }
      }
    } catch (e) {
      log(`[affinity-store] ${userId}: no se pudo leer (${e.message})`)
    }
    return { userId, adj, seeds, dirty: false, timer: null, seedsRev: 0, propMemo: null }
  }

  return {
    async load(userId) {
      const h = hot.get(userId)
      if (h) { hot.delete(userId); hot.set(userId, h); return h }   // LRU: al final
      if (loading.has(userId)) return loading.get(userId)
      const p = read(userId).then(async store => {
        hot.set(userId, store)
        loading.delete(userId)
        await evictIfNeeded()
        return store
      })
      loading.set(userId, p)
      return p
    },
    // Votes: valuable and rare → short debounce.
    touch(store) {
      store.dirty = true
      store.seedsRev++
      if (!store.timer) store.timer = setTimeout(() => flush(store), AFFINITY_FLUSH_MS)
    },
    // Crawl edges: they only mark dirty and are picked up by the next flush.
    absorbEdges(store, pairs) {
      for (const [a, b] of pairs || []) addEdge(store.adj, a, b)
      if (pairs && pairs.length) store.dirty = true
    },
    // Propagation is deterministic over (graph, votes): while they don't
    // change, the last result is reused.
    async propagateCached(store) {
      let edges = 0
      for (const s of store.adj.values()) edges += s.size
      const m = store.propMemo
      if (m && m.n === store.adj.size && m.edges === edges && m.seedsRev === store.seedsRev) return m.score
      const score = await propagate(store.adj, store.seeds)
      store.propMemo = { n: store.adj.size, edges, seedsRev: store.seedsRev, score }
      return score
    },
    flush,
    async flushAll() { for (const s of hot.values()) await flush(s) },
  }
}

// ─── Result pools (per user) ─────────────────────────────────────────────────
const POOL_FLUSH_MS = 4000

function createPoolStores(db, log = console.log) {
  const hot = new Map()   // userId → pool (one hot pool per user, as on the desktop)

  async function flush(pool) {
    if (!pool) return
    clearTimeout(pool.timer)
    pool.timer = null
    if (!pool.dirty) return
    pool.dirty = false
    try {
      const blob = gz({ v: 1, ref: pool.refId, artists: pool.artists.map(packArtist) })
      await db.query(
        `insert into pools (user_id, ref_id, name, ts, blob) values ($1, $2, $3, $4, $5)
         on conflict (user_id, ref_id) do update set name = excluded.name, ts = excluded.ts, blob = excluded.blob`,
        [pool.userId, pool.refId, pool.name || null, Date.now(), blob]
      )
    } catch (e) {
      pool.dirty = true
      log(`[pool-store] ERROR guardando ${pool.userId}/${pool.refId}: ${e.message}`)
    }
  }

  async function read(userId, refId) {
    try {
      const { rows } = await db.query('select name, ts, blob from pools where user_id = $1 and ref_id = $2', [userId, refId])
      if (!rows[0]) return null
      const j = ungz(rows[0].blob)
      if (j?.v !== 1 || !Array.isArray(j.artists)) return null
      return { name: rows[0].name || null, ts: Number(rows[0].ts) || null, artists: j.artists.filter(p => p?.i).map(unpackArtist) }
    } catch (e) {
      log(`[pool-store] ${userId}/${refId}: ilegible (${e.message})`)
      return null
    }
  }

  return {
    read,
    hot(userId, refId) {
      const p = hot.get(userId)
      return p && p.refId === refId ? p : null
    },
    async load(userId, refId, name) {
      const cur = hot.get(userId)
      if (cur && cur.refId === refId) { cur.name = name || cur.name; return cur }
      if (cur) await flush(cur)
      const stored = await read(userId, refId)
      const pool = { userId, refId, name: name || stored?.name || null, artists: stored?.artists || [], dirty: false, timer: null }
      hot.set(userId, pool)
      if (pool.artists.length) log(`[pool-store] ${pool.name || refId}: ${pool.artists.length} artistas recuperados`)
      return pool
    },
    add(pool, artist) {
      if (!pool || !artist?.id) return
      pool.artists = mergePool(pool.artists, [artist])
      pool.dirty = true
      if (!pool.timer) pool.timer = setTimeout(() => flush(pool), POOL_FLUSH_MS)
    },
    flush,
    async flushUser(userId) { await flush(hot.get(userId)) },
    async flushAll() { for (const p of hot.values()) await flush(p) },
  }
}

// ─── Instagram follower cache (shared) ───────────────────────────────────────
// username → { v: number|null, ts }. Confirmed counts go to the database; a null
// ("Instagram didn't answer right now") lives only in RAM, as on the desktop.
const IG_CACHE_FLUSH_MS = 10 * 1000

function createIgCache(db, { ttlMs, log = console.log } = {}) {
  const map = new Map()
  const pending = new Map()   // username → { v, ts, source }
  let timer = null

  async function flush() {
    clearTimeout(timer)
    timer = null
    if (!pending.size) return
    const batch = [...pending.entries()].map(([u, e]) => ({ u, f: e.v, t: e.ts, s: e.source || null }))
    pending.clear()
    try {
      await db.query(
        `insert into ig_cache (username, followers, ts, source)
           select e->>'u', (e->>'f')::int, (e->>'t')::bigint, e->>'s' from jsonb_array_elements($1::jsonb) e
         on conflict (username) do update set followers = excluded.followers, ts = excluded.ts, source = excluded.source`,
        [JSON.stringify(batch)]
      )
    } catch (e) {
      log(`[ig-cache] ERROR escribiendo: ${e.message}`)
    }
  }

  return {
    async warm() {
      try {
        const { rows } = await db.query('select username, followers, ts from ig_cache where ts > $1', [Date.now() - ttlMs])
        for (const r of rows) map.set(r.username, { v: r.followers, ts: Number(r.ts) })
        if (rows.length) log(`[ig-cache] ${rows.length} perfiles recuperados de la base`)
      } catch (e) {
        log(`[ig-cache] no se pudo leer: ${e.message}`)
      }
    },
    get: username => map.get(username),
    remember(username, v, source = 'server') {
      map.set(username, { v, ts: Date.now() })
      if (v == null) return
      pending.set(username, { v, ts: Date.now(), source })
      if (!timer) timer = setTimeout(flush, IG_CACHE_FLUSH_MS)
    },
    flush,
    size: () => map.size,
  }
}

module.exports = { createAffinityStores, createPoolStores, createIgCache }
