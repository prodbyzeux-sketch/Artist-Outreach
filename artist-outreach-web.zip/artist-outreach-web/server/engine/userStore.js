// Each user's data: what lived in artists.json ({ artists, seenIds, folders })
// and config.json on the desktop, now in Postgres with a user_id on every row.
// Responses keep EXACTLY the shape public/app.js expects, so the client
// didn't have to change.
//
// The gallery order mirrors the desktop: there a new save was unshifted and an
// existing one updated in place. Here `seq` is the insertion order and never
// changes on update → order by seq desc.

const now = () => new Date().toISOString()

function igHandleRecord(instagram) {
  if (!instagram) return null
  return '@' + String(instagram).replace(/.*instagram\.com\//, '').replace(/\//g, '').replace(/@/g, '')
}

// The same record server.js used to build when saving.
function recordFromArtist(artist, referenceArtist, ts = now()) {
  return {
    id: artist.id,
    name: artist.name,
    spotify_url: artist.url,
    spotify_followers: artist.followers,
    spotify_genres: artist.genres || [],
    spotify_image: artist.image,
    reference_artist: referenceArtist || null,
    instagram_handle: igHandleRecord(artist.instagram),
    instagram_followers: null,
    latest_release: artist.latestRelease || null,
    status: 'saved',
    notes: null,
    saved_at: ts,
    contacted_at: null,
  }
}

const isId = v => typeof v === 'string' && v.length > 0 && v.length < 200

function createUserStore(db) {
  const q = (text, params) => db.query(text, params)

  async function upsertRecords(userId, records) {
    // The same id twice in one batch would break ON CONFLICT ("cannot affect
    // row a second time"); on the desktop the second one updated the first.
    const byId = new Map()
    for (const r of records) {
      if (!r || !isId(r.id)) continue
      byId.set(r.id, { ...(byId.get(r.id) || {}), ...r })
    }
    if (!byId.size) return { added: 0, updated: 0, rows: [] }
    const { rows } = await q(
      `insert into prospects (user_id, id, rec)
         select $1, e->>'id', e from jsonb_array_elements($2::jsonb) with ordinality as t(e, ord) order by ord
       on conflict (user_id, id) do update set rec = prospects.rec || excluded.rec, updated_at = now()
       returning (xmax = 0) as inserted, rec`,
      [userId, JSON.stringify([...byId.values()])]
    )
    const added = rows.filter(r => r.inserted).length
    return { added, updated: rows.length - added, rows: rows.map(r => r.rec) }
  }

  return {
    recordFromArtist,

    async saveArtist(userId, artist) {
      const record = recordFromArtist(artist, artist.referenceArtist || null)
      const { rows } = await upsertRecords(userId, [record])
      const total = (await q('select count(*)::int as n from prospects where user_id = $1', [userId])).rows[0].n
      return { record: rows[0] || record, total }
    },

    async bulkSave(userId, artists, referenceArtist) {
      const ts = now()
      const records = artists.filter(a => a && isId(a.id)).map(a => recordFromArtist(a, referenceArtist, ts))
      const { added, updated } = await upsertRecords(userId, records)
      return { added, updated }
    },

    async listArtists(userId, { search, status } = {}) {
      const params = [userId]
      let where = 'user_id = $1'
      if (status) { params.push(status); where += ` and status = $${params.length}` }
      if (search) { params.push('%' + String(search).toLowerCase() + '%'); where += ` and lower(rec->>'name') like $${params.length}` }
      const { rows } = await q(`select rec from prospects where ${where} order by seq desc`, params)
      return rows.map(r => r.rec)
    },

    async getArtist(userId, id) {
      const { rows } = await q('select rec from prospects where user_id = $1 and id = $2', [userId, id])
      return rows[0]?.rec || null
    },

    async patchArtist(userId, id, body) {
      const allowed = ['instagram_handle', 'instagram_followers', 'status', 'notes', 'contacted_at']
      const patch = {}
      for (const k of allowed) if (body && body[k] !== undefined) patch[k] = body[k]
      if (!Object.keys(patch).length) return 0
      const { rows } = await q(
        `update prospects set rec = rec || $3::jsonb, updated_at = now() where user_id = $1 and id = $2 returning 1`,
        [userId, id, JSON.stringify(patch)]
      )
      return rows.length
    },

    // For the extension: adds outreach fields without going through the PATCH
    // allow-list (which is the UI's).
    async mergeRecord(userId, id, patch) {
      const { rows } = await q(
        `update prospects set rec = rec || $3::jsonb, updated_at = now() where user_id = $1 and id = $2 returning rec`,
        [userId, id, JSON.stringify(patch)]
      )
      return rows[0]?.rec || null
    },

    async deleteArtist(userId, id) {
      await q('delete from prospects where user_id = $1 and id = $2', [userId, id])
    },

    async bulkDelete(userId, ids) {
      const { rows } = await q(
        'delete from prospects where user_id = $1 and id = any($2::text[]) returning 1',
        [userId, ids.filter(isId)]
      )
      return rows.length
    },

    // contactedAt: undefined → if the status is 'contacted' it is set to now;
    // string|null → used as is (undoing a batch restores the original date).
    async bulkStatus(userId, ids, status, contactedAt) {
      const patch = { status }
      const explicit = contactedAt !== undefined
      const { rows } = await q(
        `update prospects
            set rec = rec || $3::jsonb
                      || case when $4::boolean then jsonb_build_object('contacted_at', $5::text)
                              when $3::jsonb->>'status' = 'contacted' then jsonb_build_object('contacted_at', $6::text)
                              else '{}'::jsonb end,
                updated_at = now()
          where user_id = $1 and id = any($2::text[])
          returning 1`,
        [userId, ids.filter(isId), JSON.stringify(patch), explicit, explicit ? contactedAt : null, now()]
      )
      return rows.length
    },

    async listFolders(userId) {
      const { rows } = await q('select id, name, ts from folders where user_id = $1 order by ts asc', [userId])
      return rows.map(r => ({ id: r.id, name: r.name, ts: Number(r.ts) }))
    },

    async createFolder(userId, name) {
      const folder = { id: 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name, ts: Date.now() }
      await q('insert into folders (user_id, id, name, ts) values ($1, $2, $3, $4)', [userId, folder.id, folder.name, folder.ts])
      return folder
    },

    // Deleting a folder does NOT delete its artists: they become unfiled again.
    async deleteFolder(userId, id) {
      await q('delete from folders where user_id = $1 and id = $2', [userId, id])
      await q(
        `update prospects set rec = rec || '{"folder_id": null}'::jsonb where user_id = $1 and folder_id = $2`,
        [userId, id]
      )
    },

    async moveArtists(userId, ids, folderId) {
      const target = folderId || null
      if (target) {
        const { rows } = await q('select 1 from folders where user_id = $1 and id = $2', [userId, target])
        if (!rows.length) throw new Error('unknown folder')
      }
      const { rows } = await q(
        `update prospects set rec = rec || jsonb_build_object('folder_id', $3::text), updated_at = now()
          where user_id = $1 and id = any($2::text[]) returning 1`,
        [userId, ids.filter(isId), target]
      )
      return rows.length
    },

    // Saved and contacted TODAY. `tzOffset` (minutes, like the browser's
    // Date#getTimezoneOffset) so "today" is the user's and not the server's.
    async stats(userId, tzOffset) {
      const since = new Date(Date.now() - 2 * 86400000).toISOString()
      const { rows } = await q(
        'select saved_at, contacted_at from prospects where user_id = $1 and (saved_at >= $2 or contacted_at >= $2)',
        [userId, since]
      )
      const off = Number.isFinite(tzOffset) ? tzOffset : new Date().getTimezoneOffset()
      const dayKey = iso => {
        if (!iso) return null
        const d = new Date(new Date(iso).getTime() - off * 60000)
        return isNaN(d) ? null : d.toISOString().slice(0, 10)
      }
      const today = dayKey(new Date().toISOString())
      let saved = 0, contacted = 0
      for (const r of rows) {
        if (dayKey(r.saved_at) === today) saved++
        if (dayKey(r.contacted_at) === today) contacted++
      }
      return { saved, contacted }
    },

    async countArtists(userId) {
      return (await q('select count(*)::int as n from prospects where user_id = $1', [userId])).rows[0].n
    },

    // ── seen ────────────────────────────────────────────────────────────────
    async seenIds(userId) {
      const { rows } = await q('select artist_id from seen where user_id = $1', [userId])
      return rows.map(r => r.artist_id)
    },

    async addSeen(userId, ids) {
      const clean = [...new Set(ids.filter(isId))]
      if (!clean.length) return { added: 0, total: await this.countSeen(userId) }
      const { rows } = await q(
        `insert into seen (user_id, artist_id) select $1, unnest($2::text[]) on conflict do nothing returning 1`,
        [userId, clean]
      )
      return { added: rows.length, total: await this.countSeen(userId) }
    },

    async forgetSeen(userId, ids) {
      await q('delete from seen where user_id = $1 and artist_id = any($2::text[])', [userId, ids.filter(isId)])
      return this.countSeen(userId)
    },

    async resetSeen(userId) {
      const { rows } = await q('delete from seen where user_id = $1 returning 1', [userId])
      return rows.length
    },

    async countSeen(userId) {
      return (await q('select count(*)::int as n from seen where user_id = $1', [userId])).rows[0].n
    },

    // ── config ──────────────────────────────────────────────────────────────
    async getConfig(userId) {
      const { rows } = await q('select config from user_config where user_id = $1', [userId])
      return rows[0]?.config || {}
    },

    async setConfig(userId, cfg) {
      await q(
        `insert into user_config (user_id, config) values ($1, $2::jsonb)
         on conflict (user_id) do update set config = excluded.config`,
        [userId, JSON.stringify(cfg && typeof cfg === 'object' ? cfg : {})]
      )
    },

    // ── for the extension ───────────────────────────────────────────────────
    async prospectsForOutreach(userId, { folderId, status } = {}) {
      const params = [userId]
      let where = `user_id = $1 and ig_handle is not null and ig_handle <> ''`
      if (folderId === 'none') where += ' and folder_id is null'
      else if (folderId) { params.push(folderId); where += ` and folder_id = $${params.length}` }
      if (status === 'pending') where += ` and coalesce(status, 'saved') <> 'contacted' and coalesce(status, '') <> 'not-similar'`
      else if (status === 'contacted') where += ` and status = 'contacted'`
      else if (status !== 'all') where += ` and coalesce(status, '') <> 'not-similar'`
      const { rows } = await q(`select rec from prospects where ${where} order by seq desc limit 5000`, params)
      return rows.map(r => r.rec)
    },

    async findByHandle(userId, handle) {
      const { rows } = await q('select id, rec from prospects where user_id = $1 and ig_handle = $2 limit 1', [userId, handle])
      return rows[0] || null
    },
  }
}

module.exports = { createUserStore, recordFromArtist, igHandleRecord }
