// API for the browser extension.
//
// Pairing: the user, signed in on the web, presses "Connect extension". The
// page asks for a token (POST /api/ext/pair, with its cookie) and hands it to
// the extension through postMessage (extension/platform/bridge.js). From then
// on the extension calls /ext/v1/* with "Authorization: Bearer <token>" and no
// cookies — which is why open CORS here exposes nothing.
//
//   GET  /ext/v1/me              who am I, my plan, do I have access
//   GET  /ext/v1/folders         saved-artist folders
//   GET  /ext/v1/prospects       prospects with Instagram, to import as a campaign
//   POST /ext/v1/events          what happened to each one: sent | failed | replied
//   POST /ext/v1/ig-followers    follower counts read in the user's browser
//   GET  /ext/v1/quota           today's automated-DM usage
//   POST /ext/v1/quota/claim     take one automated DM from today's allowance
//   POST /ext/v1/quota/release   give it back (the send didn't happen)

const express = require('express')
const { sha256, randomToken } = require('../auth')
const { createQuota } = require('./quota')

const STATES = new Set(['queued', 'sent', 'failed', 'replied'])
const RANK = { queued: 1, failed: 2, sent: 3, replied: 4 }
const handleOf = v => String(v || '').trim().replace(/^@/, '').replace(/.*instagram\.com\//i, '').replace(/[/?#].*$/, '').toLowerCase()

function createExtApi({ db, config, auth, userStore, igReport, log = console.log }) {
  const quota = createQuota(db)

  async function bearerUser(req, res, next) {
    const m = /^Bearer\s+(\S{20,200})$/.exec(req.headers.authorization || '')
    if (!m) return res.status(401).json({ success: false, error: 'auth_required' })
    try {
      const h = sha256(m[1])
      const { rows } = await db.query(
        'select u.* from ext_tokens t join users u on u.id = t.user_id where t.id = $1', [h])
      if (!rows[0]) return res.status(401).json({ success: false, error: 'invalid_token' })
      req.user = rows[0]
      db.query('update ext_tokens set last_used_at = now() where id = $1', [h]).catch(() => {})
      next()
    } catch (e) {
      res.status(500).json({ success: false, error: e.message })
    }
  }

  function needAccess(req, res, next) {
    if (!auth.hasAccess(req.user)) return res.status(402).json({ success: false, error: 'subscription_required' })
    next()
  }

  function cors(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type')
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    res.setHeader('Access-Control-Max-Age', '600')
    if (req.method === 'OPTIONS') return res.sendStatus(204)
    next()
  }

  function toLead(rec) {
    return {
      id: rec.id,
      name: rec.name || null,
      handle: handleOf(rec.instagram_handle),
      igFollowers: rec.instagram_followers ?? null,
      listeners: rec.spotify_followers ?? null,
      reference: rec.reference_artist || null,
      spotify: rec.spotify_url || null,
      status: rec.status || 'saved',
      folderId: rec.folder_id || null,
      outreach: rec.outreach_state || null,
    }
  }

  const tzOf = req => req.body?.tz ?? req.query?.tz ?? req.get('x-tz-offset')

  function mount(app) {
    // ── from the web app (cookie) ───────────────────────────────────────────
    app.post('/api/ext/pair', auth.sameOrigin, auth.requireUserApi, async (req, res) => {
      try {
        const token = randomToken(32)
        const label = String(req.body?.label || 'Chrome').slice(0, 60)
        await db.query('insert into ext_tokens (id, user_id, label) values ($1, $2, $3)', [sha256(token), req.user.id, label])
        res.json({ success: true, token, origin: config.publicOrigin })
      } catch (e) { res.status(500).json({ success: false, error: e.message }) }
    })

    app.post('/api/ext/revoke-all', auth.sameOrigin, auth.requireUserApi, async (req, res) => {
      const { rows } = await db.query('delete from ext_tokens where user_id = $1 returning 1', [req.user.id])
      res.json({ success: true, revoked: rows.length })
    })

    app.get('/api/ext/status', auth.requireUserApi, async (req, res) => {
      const { rows } = await db.query(
        'select count(*)::int as n, max(last_used_at) as last from ext_tokens where user_id = $1', [req.user.id])
      const ev = await db.query(
        `select state, count(*)::int as n from outreach_events where user_id = $1 group by state`, [req.user.id])
      res.json({ success: true, tokens: rows[0].n, lastUsedAt: rows[0].last, events: Object.fromEntries(ev.rows.map(r => [r.state, r.n])) })
    })

    app.get('/api/quota', auth.requireUserApi, async (req, res) => {
      const { plan, dailyAutoDms } = auth.limits(req.user)
      res.json({ success: true, plan, ...(await quota.status(req.user.id, dailyAutoDms, tzOf(req))) })
    })

    // ── from the extension (Bearer) ─────────────────────────────────────────
    const r = express.Router()
    r.use(cors)
    r.use(express.json({ limit: '1mb' }))
    r.use(bearerUser)

    r.get('/me', (req, res) => res.json({ success: true, user: auth.publicUser(req.user) }))

    r.get('/folders', needAccess, async (req, res) => {
      res.json({ success: true, folders: await userStore.listFolders(req.user.id) })
    })

    r.get('/prospects', needAccess, async (req, res) => {
      try {
        const status = ['pending', 'contacted', 'all', 'saved'].includes(req.query.status) ? req.query.status : 'pending'
        const folderId = typeof req.query.folder === 'string' && req.query.folder ? req.query.folder : null
        const recs = await userStore.prospectsForOutreach(req.user.id, { folderId, status })
        res.json({ success: true, prospects: recs.map(toLead).filter(l => l.handle) })
      } catch (e) { res.status(500).json({ success: false, error: e.message }) }
    })

    // Each event only moves a prospect forward: a late "sent" never undoes a
    // "replied". "sent" marks the artist contacted (like the gallery button)
    // if it wasn't already.
    r.post('/events', needAccess, async (req, res) => {
      try {
        const events = Array.isArray(req.body?.events) ? req.body.events.slice(0, 500) : []
        let updated = 0, unknown = 0
        for (const ev of events) {
          const state = String(ev?.state || '')
          const handle = handleOf(ev?.handle)
          if (!STATES.has(state) || !handle) continue
          const at = new Date(ev.at || Date.now())
          const atIso = isNaN(at) ? new Date().toISOString() : at.toISOString()

          let row = null
          if (typeof ev.prospectId === 'string' && ev.prospectId) {
            const rec = await userStore.getArtist(req.user.id, ev.prospectId)
            if (rec) row = { id: ev.prospectId, rec }
          }
          if (!row) row = await userStore.findByHandle(req.user.id, handle)

          await db.query(
            `insert into outreach_events (user_id, prospect_id, handle, state, at, campaign) values ($1, $2, $3, $4, $5, $6)`,
            [req.user.id, row?.id || null, handle, state, atIso, typeof ev.campaign === 'string' ? ev.campaign.slice(0, 120) : null])
          if (!row) { unknown++; continue }

          const prev = row.rec.outreach_state
          if (prev && (RANK[prev] || 0) > RANK[state]) continue
          const patch = { outreach_state: state, outreach_at: atIso }
          if (state === 'replied') patch.replied_at = atIso
          if ((state === 'sent' || state === 'replied') && row.rec.status !== 'contacted') {
            patch.status = 'contacted'
            patch.contacted_at = row.rec.contacted_at || atIso
          }
          if (state === 'failed' && ev.error) patch.outreach_error = String(ev.error).slice(0, 200)
          await userStore.mergeRecord(req.user.id, row.id, patch)
          updated++
        }
        res.json({ success: true, updated, unknown })
      } catch (e) { res.status(500).json({ success: false, error: e.message }) }
    })

    r.post('/ig-followers', needAccess, (req, res) => {
      const stored = igReport(req.body?.results)
      res.json({ success: true, stored })
    })

    r.get('/quota', needAccess, async (req, res) => {
      const { plan, dailyAutoDms } = auth.limits(req.user)
      res.json({ success: true, plan, ...(await quota.status(req.user.id, dailyAutoDms, tzOf(req))) })
    })

    r.post('/quota/claim', needAccess, async (req, res) => {
      try {
        const { plan, dailyAutoDms } = auth.limits(req.user)
        const result = await quota.claim(req.user.id, dailyAutoDms, tzOf(req))
        res.json({ success: true, plan, ...result, ...(result.ok ? {} : { error: 'daily_limit' }) })
      } catch (e) { res.status(500).json({ success: false, error: e.message }) }
    })

    r.post('/quota/release', needAccess, async (req, res) => {
      try { res.json({ success: true, released: await quota.release(req.user.id, req.body?.day) }) }
      catch (e) { res.status(500).json({ success: false, error: e.message }) }
    })

    app.use('/ext/v1', r)
  }

  return { mount }
}

module.exports = { createExtApi, handleOf }
