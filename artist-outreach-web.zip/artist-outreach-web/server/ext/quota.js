// Daily automated-DM quota.
//
// The extension claims one unit right before each automated send (first
// message or follow-up) and releases it if the send didn't happen. Claiming is
// a single atomic statement, so two browsers on the same account can't both
// squeeze past the limit. Pro (limit null) is only counted.
//
// "Day" is the user's local day: the extension sends its timezone offset
// (minutes, as Date#getTimezoneOffset).

const clampOffset = tz => {
  const n = parseInt(tz, 10)
  return Number.isFinite(n) ? Math.max(-840, Math.min(840, n)) : 0
}

function dayKey(tzOffset, now = Date.now()) {
  return new Date(now - clampOffset(tzOffset) * 60000).toISOString().slice(0, 10)
}

const isDay = d => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)

function createQuota(db) {
  async function used(userId, day) {
    const { rows } = await db.query('select count from dm_usage where user_id = $1 and day = $2', [userId, day])
    return rows[0]?.count || 0
  }

  return {
    dayKey,

    async status(userId, limit, tz) {
      const day = dayKey(tz)
      const n = await used(userId, day)
      return { day, used: n, limit, remaining: limit == null ? null : Math.max(0, limit - n) }
    },

    async claim(userId, limit, tz) {
      const day = dayKey(tz)
      if (limit != null && limit <= 0) return { ok: false, day, used: 0, limit, remaining: 0 }
      const { rows } = limit == null
        ? await db.query(
            `insert into dm_usage (user_id, day, count) values ($1, $2, 1)
             on conflict (user_id, day) do update set count = dm_usage.count + 1 returning count`, [userId, day])
        : await db.query(
            `insert into dm_usage (user_id, day, count) values ($1, $2, 1)
             on conflict (user_id, day) do update set count = dm_usage.count + 1 where dm_usage.count < $3
             returning count`, [userId, day, limit])
      if (!rows.length) return { ok: false, day, used: limit, limit, remaining: 0 }
      const n = rows[0].count
      return { ok: true, day, used: n, limit, remaining: limit == null ? null : Math.max(0, limit - n) }
    },

    // `day` is the one the claim returned, so a send that straddles midnight
    // gives the unit back to the right day.
    async release(userId, day) {
      if (!isDay(day)) return false
      const { rows } = await db.query(
        'update dm_usage set count = greatest(count - 1, 0) where user_id = $1 and day = $2 returning count', [userId, day])
      return rows.length > 0
    },
  }
}

module.exports = { createQuota, dayKey }
