// The extension users download from the app (GET /downloads/artist-outreach-extension.zip).
//
// Built from ../extension at runtime, so it is always the version this server
// ships, and patched with THIS server's origin — the extension only talks to,
// injects into and can be embedded by the origins it lists, and a copy pointed
// at app.example.com would do nothing on the real domain.
//
// The zip writer is a minimal one (deflate + CRC-32, no dependency).

const fs = require('fs')
const path = require('path')
const zlib = require('zlib')

const EXT_DIR = path.join(__dirname, '..', 'extension')
const BRIDGE = 'platform/bridge.js'
const EMBEDDABLE = ['outreach/src/app.html', 'crm/page/crm.html']

// Not part of what Chrome loads: tests, docs, the local CRM daemon, dev tools.
const SKIP_DIRS = new Set(['test', 'node_modules', '.git'])
const SKIP_PATHS = new Set(['crm/bridge', 'platform/set-origin.mjs'])
const skipFile = name => name.startsWith('.') || name.startsWith('._') || name.endsWith('.md') || name === 'package.json' || name === 'package-lock.json'

// `local` adds the development server, for a checkout loaded unpacked while
// developing (platform/set-origin.mjs). The download only lists its own origin.
function normalizeOrigins(list, { local = true } = {}) {
  return [...new Set([...list, ...(local ? ['http://localhost:3456'] : [])].map(o => new URL(o).origin))]
}

function patchConfig(source, origins) {
  const out = source.replace(
    /export const PLATFORM_ORIGINS = \[[\s\S]*?\];/,
    `export const PLATFORM_ORIGINS = [\n${origins.map(o => `  "${o}",`).join('\n')}\n];`)
  if (out === source && !source.includes(origins[0])) throw new Error('PLATFORM_ORIGINS not found in platform/config.js')
  return out
}

function patchManifest(source, origins) {
  const man = JSON.parse(source)
  const patterns = origins.map(o => `${o}/*`)
  const bridge = man.content_scripts.find(cs => cs.js.includes(BRIDGE))
  if (!bridge) throw new Error(`manifest.json has no content script ${BRIDGE}`)
  const old = new Set(bridge.matches)
  man.host_permissions = [...man.host_permissions.filter(p => !old.has(p)), ...patterns]
  bridge.matches = patterns
  const war = (man.web_accessible_resources || []).find(w => w.resources.some(r => EMBEDDABLE.includes(r)))
  if (war) war.matches = patterns
  return JSON.stringify(man, null, 2) + '\n'
}

function listFiles(dir = EXT_DIR, rel = '') {
  const out = []
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const relPath = rel ? `${rel}/${entry.name}` : entry.name
    if (SKIP_PATHS.has(relPath)) continue
    if (entry.isDirectory()) {
      if (!SKIP_DIRS.has(entry.name) && !entry.name.startsWith('.')) out.push(...listFiles(path.join(dir, entry.name), relPath))
    } else if (!skipFile(entry.name)) {
      out.push(relPath)
    }
  }
  return out.sort()
}

// ── zip ──────────────────────────────────────────────────────────────────────
const CRC_TABLE = (() => {
  const t = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c >>> 0
  }
  return t
})()

function crc32(buf) {
  let c = 0xffffffff
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function dosDateTime(d = new Date()) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2)
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
  return { time, date }
}

// entries: [{ name, data: Buffer }] → Buffer (a standard .zip, deflated)
function buildZip(entries, root = '') {
  const { time, date } = dosDateTime()
  const locals = [], centrals = []
  let offset = 0
  for (const { name, data } of entries) {
    const fileName = Buffer.from(root ? `${root}/${name}` : name, 'utf8')
    const deflated = zlib.deflateRawSync(data, { level: 9 })
    const useDeflate = deflated.length < data.length
    const body = useDeflate ? deflated : data
    const crc = crc32(data)

    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(0x0800, 6)            // UTF-8 names
    local.writeUInt16LE(useDeflate ? 8 : 0, 8)
    local.writeUInt16LE(time, 10)
    local.writeUInt16LE(date, 12)
    local.writeUInt32LE(crc, 14)
    local.writeUInt32LE(body.length, 18)
    local.writeUInt32LE(data.length, 22)
    local.writeUInt16LE(fileName.length, 26)
    local.writeUInt16LE(0, 28)
    locals.push(local, fileName, body)

    const central = Buffer.alloc(46)
    central.writeUInt32LE(0x02014b50, 0)
    central.writeUInt16LE(20, 4)
    central.writeUInt16LE(20, 6)
    central.writeUInt16LE(0x0800, 8)
    central.writeUInt16LE(useDeflate ? 8 : 0, 10)
    central.writeUInt16LE(time, 12)
    central.writeUInt16LE(date, 14)
    central.writeUInt32LE(crc, 16)
    central.writeUInt32LE(body.length, 20)
    central.writeUInt32LE(data.length, 24)
    central.writeUInt16LE(fileName.length, 28)
    central.writeUInt32LE(0, 30)               // extra, comment, disk
    central.writeUInt16LE(0, 34)
    central.writeUInt16LE(0, 36)
    central.writeUInt32LE(0, 38)               // attributes
    central.writeUInt32LE(offset, 42)
    centrals.push(central, fileName)

    offset += 30 + fileName.length + body.length
  }
  const cd = Buffer.concat(centrals)
  const end = Buffer.alloc(22)
  end.writeUInt32LE(0x06054b50, 0)
  end.writeUInt16LE(0, 4)
  end.writeUInt16LE(0, 6)
  end.writeUInt16LE(entries.length, 8)
  end.writeUInt16LE(entries.length, 10)
  end.writeUInt32LE(cd.length, 12)
  end.writeUInt32LE(offset, 16)
  end.writeUInt16LE(0, 20)
  return Buffer.concat([...locals, cd, end])
}

// The extension, patched for `publicOrigin`, as a zip whose single top folder
// is what users pick in chrome://extensions → "Load unpacked".
function packExtension(publicOrigin, { dir = EXT_DIR } = {}) {
  const origins = normalizeOrigins([publicOrigin], { local: false })
  const files = listFiles(dir)
  const entries = files.map(name => {
    let data = fs.readFileSync(path.join(dir, name))
    if (name === 'manifest.json') data = Buffer.from(patchManifest(data.toString('utf8'), origins))
    if (name === 'platform/config.js') data = Buffer.from(patchConfig(data.toString('utf8'), origins))
    return { name, data }
  })
  const version = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8')).version
  return { zip: buildZip(entries, 'artist-outreach-extension'), files: files.length, version }
}

let cached = null
function extensionZip(publicOrigin) {
  if (!cached || cached.origin !== publicOrigin) cached = { origin: publicOrigin, ...packExtension(publicOrigin) }
  return cached
}

const available = () => fs.existsSync(path.join(EXT_DIR, 'manifest.json'))

module.exports = { packExtension, extensionZip, patchConfig, patchManifest, normalizeOrigins, listFiles, buildZip, crc32, available, EXT_DIR }
