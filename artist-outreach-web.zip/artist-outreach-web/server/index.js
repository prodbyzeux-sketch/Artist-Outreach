// Artist Outreach — web server.
//
//   /login, /billing, /             pages (the Finder is the desktop app's UI)
//   /privacy, /terms                legal pages
//   /auth/*                         Google sign-in, sign-out
//   /billing/*                      Stripe Checkout, cancel/resume/upgrade, portal, webhook
//   /api/*                          the discovery engine (signed in + active plan)
//   /api/ext/*, /ext/v1/*           pairing with and talking to the extension
//   /downloads/artist-outreach-extension.zip   the extension, patched for this domain
//   /healthz                        for the hosting platform's health check

const path = require('path')
const fs = require('fs')
const express = require('express')
const { loadConfig } = require('./config')
const { createDb } = require('./db')
const { createUserStore } = require('./engine/userStore')
const { createAuth } = require('./auth')
const { createBilling } = require('./billing/stripe')
const { createExtApi } = require('./ext')
const extensionPack = require('./extensionPack')
const engine = require('./engine/engine')

const PUBLIC_DIR = path.join(__dirname, '..', 'public')

function securityHeaders(config) {
  return (req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff')
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin')
    res.setHeader('X-Frame-Options', 'DENY')
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
    if (config.publicUrl.startsWith('https://')) {
      res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains')
    }
    next()
  }
}

// Legal pages are templates filled from LEGAL_* env vars — have them reviewed.
function legalPage(file, config) {
  const tpl = fs.readFileSync(path.join(PUBLIC_DIR, file), 'utf8')
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))
  const html = tpl
    .replaceAll('{{COMPANY}}', esc(config.legal.company))
    .replaceAll('{{EMAIL}}', esc(config.legal.contactEmail))
    .replaceAll('{{ADDRESS}}', esc(config.legal.address))
    .replaceAll('{{URL}}', esc(config.publicUrl))
  return (req, res) => res.type('html').send(html)
}

async function createApp({ config = loadConfig(), db = null, stripeClient = null, fetchImpl = fetch, log = console.log } = {}) {
  db = db || await createDb({ databaseUrl: config.databaseUrl, dataDir: config.dataDir, log })
  const userStore = createUserStore(db)
  const auth = createAuth({ db, config, log, fetchImpl })
  const billing = createBilling({ db, config, auth, log, stripeClient })
  engine.configure({ db, userStore, config, log })
  const ext = createExtApi({ db, config, auth, userStore, igReport: engine.reportIgFollowers, log })

  const app = express()
  app.disable('x-powered-by')
  // Behind Railway/Fly/Render's proxy: correct req.secure and req.ip.
  app.set('trust proxy', 1)
  app.use(securityHeaders(config))

  // The Stripe webhook goes BEFORE the JSON parser: it needs the raw body.
  billing.mount(app)

  app.use(express.json({ limit: '2mb' }))
  app.use(auth.loadUser)

  app.get('/healthz', async (req, res) => {
    let dbOk = false
    try { await db.query('select 1'); dbOk = true } catch (_) {}
    const st = engine.status()
    res.status(dbOk ? 200 : 503).json({ ok: dbOk, db: dbOk, spotify: st.spotify, crawls: st.crawls })
  })

  // /api/me also tells the app where the extension comes from.
  app.get('/api/me', (req, res) => {
    if (!req.user) return res.status(401).json({ success: false, error: 'auth_required' })
    res.json({ success: true, user: auth.publicUser(req.user), extension: config.extension })
  })
  auth.mount(app)
  billing.mountUserRoutes(app)
  ext.mount(app)

  // ── the extension download ────────────────────────────────────────────────
  app.get(config.extension.downloadUrl, auth.requireUserPage, (req, res) => {
    if (!extensionPack.available()) return res.status(404).send('The extension is not bundled with this server.')
    try {
      const { zip, version } = extensionPack.extensionZip(config.publicOrigin)
      res.setHeader('Content-Type', 'application/zip')
      res.setHeader('Content-Disposition', `attachment; filename="artist-outreach-extension-${version}.zip"`)
      res.setHeader('Cache-Control', 'no-store')
      res.send(zip)
    } catch (e) {
      log(`[extension] could not pack: ${e.message}`)
      res.status(500).send('Could not build the extension download.')
    }
  })

  // ── pages ──────────────────────────────────────────────────────────────────
  const page = file => (req, res) => res.sendFile(path.join(PUBLIC_DIR, file))
  app.get('/login', (req, res, next) => (req.user ? res.redirect(302, '/') : next()), page('login.html'))
  app.get('/billing', auth.requireUserPage, page('billing.html'))
  app.get('/privacy', legalPage('privacy.html', config))
  app.get('/terms', legalPage('terms.html', config))
  app.get(['/', '/index.html'], auth.requireAccessPage, page('index.html'))

  // A minimal admin overview: how many people, and how the engine is doing.
  app.get('/api/admin/overview', auth.requireUserApi, async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'forbidden' })
    const users = await db.query(`select count(*)::int as total,
        count(*) filter (where sub_status in ('active','trialing','past_due'))::int as paying,
        count(*) filter (where sub_status in ('active','trialing','past_due') and plan = 'starter')::int as starter,
        count(*) filter (where sub_status in ('active','trialing','past_due') and plan = 'pro')::int as pro,
        count(*) filter (where created_at > now() - interval '7 days')::int as new7d from users`)
    res.json({ success: true, users: users.rows[0], engine: engine.status() })
  })

  // ── engine ─────────────────────────────────────────────────────────────────
  app.use('/api', auth.sameOrigin, auth.requireAccessApi, engine.router)

  // ── static files (no data in them: JS, CSS, images) ─────────────────────────
  app.use(express.static(PUBLIC_DIR, { index: false, maxAge: config.production ? '1h' : 0 }))
  app.use((req, res) => res.status(404).json({ error: 'not_found' }))

  return { app, db, config, engine }
}

async function main() {
  const config = loadConfig()
  if (!config.googleEnabled && !config.devLogin) {
    console.warn('[config] WARNING: neither Google (GOOGLE_CLIENT_ID/SECRET) nor DEV_LOGIN — nobody can sign in.')
  }
  if (!config.billingEnabled) {
    console.warn('[config] Stripe not configured: every signed-in user gets full access.')
  }
  if (config.production && !config.databaseUrl) {
    console.warn('[config] WARNING: production without DATABASE_URL — using local PGlite, NOT fit for production.')
  }
  const { app, db } = await createApp({ config })
  await engine.start()
  const server = app.listen(config.port, () => {
    console.log(`\x1b[32m✓ Artist Outreach web on ${config.publicUrl}\x1b[0m (port ${config.port})`)
  })
  // /api/discover streams for minutes: without this the proxy cuts it.
  server.keepAliveTimeout = 65_000
  server.headersTimeout = 66_000

  let closing = false
  const shutdown = async sig => {
    if (closing) return
    closing = true
    console.log(`[server] ${sig}: saving state and shutting down…`)
    server.close()
    const hard = setTimeout(() => process.exit(1), 15_000)
    hard.unref()
    try { await engine.shutdown() } catch (e) { console.log(`[server] engine shutdown: ${e.message}`) }
    try { await db.close() } catch (_) {}
    process.exit(0)
  }
  process.on('SIGTERM', () => shutdown('SIGTERM'))
  process.on('SIGINT', () => shutdown('SIGINT'))
}

if (require.main === module) {
  main().catch(e => { console.error(e); process.exit(1) })
}

module.exports = { createApp }
