const { test } = require('node:test')
const assert = require('node:assert')
const { addEdge, propagate, signalOver, SEED_LIKE, SEED_DISLIKE } = require('../server/lib/affinity')

// ─── graph building ───────────────────────────────────────────────────────────

const graphOf = pairs => {
  const adj = new Map()
  for (const [a, b] of pairs) addEdge(adj, a, b)
  return adj
}

test('addEdge links both directions', () => {
  const adj = graphOf([['a', 'b']])
  assert.ok(adj.get('a').has('b'))
  assert.ok(adj.get('b').has('a'))
})

test('addEdge is idempotent and ignores self-loops', () => {
  const adj = graphOf([['a', 'b'], ['a', 'b'], ['b', 'a'], ['a', 'a']])
  assert.strictEqual(adj.get('a').size, 1)
  assert.strictEqual(adj.get('b').size, 1)
})

// ─── propagate ────────────────────────────────────────────────────────────────
// Measured on the owner's own labels: neighbourhood structure separates his
// "trap-R&B" from "R&B but not trap" with 24 of 25 cross-pairs at zero overlap,
// a distinction no genre taxonomy carries. These tests pin the behaviour that
// makes that usable — ordering, decay with distance, and negative mass.

test('propagate returns an empty result for an empty graph', async () => {
  assert.strictEqual((await propagate(new Map(), new Map())).size, 0)
})

test('propagate scores everything zero when nothing is seeded', async () => {
  const adj = graphOf([['a', 'b'], ['b', 'c']])
  const s = await propagate(adj, new Map())
  for (const v of s.values()) assert.strictEqual(v, 0)
})

test('propagate ranks a seed above its neighbours', async () => {
  const adj = graphOf([['seed', 'near'], ['near', 'far']])
  const s = await propagate(adj, new Map([['seed', SEED_LIKE]]))
  assert.ok(s.get('seed') > s.get('near'))
})

test('propagate decays with distance from the seed', async () => {
  const adj = graphOf([['seed', 'h1'], ['h1', 'h2'], ['h2', 'h3']])
  const s = await propagate(adj, new Map([['seed', SEED_LIKE]]))
  assert.ok(s.get('h1') > s.get('h2'), 'hop 1 must beat hop 2')
  assert.ok(s.get('h2') > s.get('h3'), 'hop 2 must beat hop 3')
})

test('propagate gives nothing to a disconnected component', async () => {
  const adj = graphOf([['seed', 'near'], ['island', 'islet']])
  const s = await propagate(adj, new Map([['seed', SEED_LIKE]]))
  assert.strictEqual(s.get('island'), 0)
})

test('propagate sinks the neighbourhood of a disliked seed', async () => {
  // This is the whole point: one "not similar" click must cost a region, not
  // a single artist. Before this, sessionDislikes removed exactly one id.
  const adj = graphOf([['bad', 'nextToBad'], ['good', 'nextToGood']])
  const s = await propagate(adj, new Map([['good', SEED_LIKE], ['bad', SEED_DISLIKE]]))
  assert.ok(s.get('nextToBad') < 0, 'a disliked seed must drag its neighbour below zero')
  assert.ok(s.get('nextToGood') > s.get('nextToBad'))
})

test('propagate does not mutate the graph it is given', async () => {
  const adj = graphOf([['a', 'b']])
  const before = JSON.stringify([...adj].map(([k, v]) => [k, [...v]]))
  await propagate(adj, new Map([['a', SEED_LIKE]]))
  assert.strictEqual(JSON.stringify([...adj].map(([k, v]) => [k, [...v]])), before)
})

test('propagate leaves room for the rest of the server between iterations', async () => {
  // Node runs the SSE producer, the IG checks and this on one thread. Measured
  // before this: a vote on a 21k-node graph froze everything for ~10s and the
  // stream fell from 7 artists/s to 1.4. Propagation must give the loop a turn.
  // 30k nodes / 300k edges — sized so a full pass on the CSR implementation
  // still spends >20ms of real compute; smaller graphs finish too fast to
  // prove the yield happens.
  const pairs = []
  for (let i = 0; i < 30000; i++) for (let k = 1; k <= 10; k++) pairs.push([`a${i}`, `a${(i * 7 + k * 13) % 30000}`])
  const adj = graphOf(pairs)

  let ticks = 0
  const timer = setInterval(() => { ticks++ }, 1)
  const t0 = Date.now()
  await propagate(adj, new Map([['a5', SEED_LIKE]]))
  const took = Date.now() - t0
  clearInterval(timer)

  assert.ok(took > 20, `graph too small to prove anything (took ${took}ms)`)
  assert.ok(ticks > 0, `the event loop got no turn in ${took}ms of propagation`)
})

test('propagate sees edges added after a previous run on the same graph', async () => {
  // The CSR build is cached per graph object. The crawl keeps adding edges
  // between votes; a stale cache would leave every newly crawled artist
  // unscored forever, silently.
  const adj = graphOf([['seed', 'near']])
  await propagate(adj, new Map([['seed', SEED_LIKE]]))
  addEdge(adj, 'near', 'late')
  const s = await propagate(adj, new Map([['seed', SEED_LIKE]]))
  assert.ok(s.get('late') > 0, 'artist crawled after the first vote must get a score')
})

// ─── signalOver ───────────────────────────────────────────────────────────────
// With one global vote pool, a search can land in a region no vote reaches.
// Scores there are residue, orders of magnitude below real signal — measured:
// same-scene ~1e-2, cross-scene ≤1e-6. Sorting by residue orders the pool by
// hubbiness, which is worse than no ordering. The floor tells the two apart.

test('signalOver passes a pool near the votes and rejects a distant one', async () => {
  const pairs = []
  for (let i = 0; i < 20; i++) pairs.push([`near${i}`, `near${(i + 1) % 20}`])
  for (let i = 0; i < 20; i++) pairs.push([`far${i}`, `far${(i + 1) % 20}`])
  pairs.push(['near0', 'bridge'], ['bridge', 'bridge2'], ['bridge2', 'far0'])
  const adj = graphOf(pairs)
  const score = await propagate(adj, new Map([['near0', SEED_LIKE]]))
  assert.strictEqual(signalOver(score, [...Array(10)].map((_, i) => `near${i + 1}`)), true)
  assert.strictEqual(signalOver(score, ['far9', 'far10', 'far11']), false,
    'a pool the vote barely reaches must not be affinity-sorted')
})

test('signalOver is false for an empty pool or no scores at all', async () => {
  assert.strictEqual(signalOver(new Map(), ['a', 'b']), false)
  assert.strictEqual(signalOver(new Map([['a', 1]]), []), false)
})

test('propagate separates two clusters joined by one weak edge', async () => {
  // Mirrors the measured shape: two dense pockets, a single cross-link, and a
  // held-out member of the liked pocket that must still outrank every disliked
  // artist. Measured 5/5 on the real graph; this pins the same outcome.
  const pairs = []
  const clique = (nodes, tail) => {
    for (const n of nodes) for (const m of nodes) if (n < m) pairs.push([n, m])
    for (const n of nodes) pairs.push([n, `${tail}-leaf-${n}`])
  }
  const liked = ['p1', 'p2', 'p3', 'p4', 'held']
  const disliked = ['n1', 'n2', 'n3', 'n4', 'n5']
  clique(liked, 'pos')
  clique(disliked, 'neg')
  pairs.push(['p2', 'n5'])            // the one weak cross-link that leaked

  const adj = graphOf(pairs)
  const seeds = new Map([
    ...liked.filter(n => n !== 'held').map(n => [n, SEED_LIKE]),
    ...disliked.map(n => [n, SEED_DISLIKE])
  ])
  const s = await propagate(adj, seeds)
  for (const n of disliked) {
    assert.ok(s.get('held') > s.get(n), `held-out liked artist must outrank ${n}`)
  }
})
