const { test } = require('node:test')
const assert = require('node:assert')
const { serializeAffinity, deserializeAffinity } = require('../server/lib/affinityStore')
const { addEdge, SEED_LIKE, SEED_DISLIKE } = require('../server/lib/affinity')

const graphOf = pairs => {
  const adj = new Map()
  for (const [a, b] of pairs) addEdge(adj, a, b)
  return adj
}

// ─── round trip ───────────────────────────────────────────────────────────────

test('serialize→deserialize restores the exact graph and votes', () => {
  const adj = graphOf([['dr', 'pnd'], ['pnd', 'bryson'], ['dr', 'bryson'], ['solo', 'mate']])
  const seeds = new Map([['pnd', SEED_LIKE], ['solo', SEED_DISLIKE]])
  const back = deserializeAffinity(serializeAffinity(adj, seeds, 'Drake'))

  assert.deepStrictEqual(
    [...back.adj].map(([k, v]) => [k, [...v].sort()]).sort(),
    [...adj].map(([k, v]) => [k, [...v].sort()]).sort()
  )
  assert.deepStrictEqual([...back.seeds].sort(), [...seeds].sort())
})

test('round trip keeps graded weights, not just ±1', () => {
  const adj = graphOf([['a', 'b']])
  const seeds = new Map([['a', -0.15], ['b', 0.5]])
  const back = deserializeAffinity(serializeAffinity(adj, seeds, 'X'))
  assert.strictEqual(back.seeds.get('a'), -0.15)
  assert.strictEqual(back.seeds.get('b'), 0.5)
})

test('deserialize still rejects weights outside [-1, 1], zero or non-numeric', () => {
  const base = { v: 1, ids: ['a', 'b'], edges: [[0, 1]] }
  assert.strictEqual(deserializeAffinity({ ...base, votes: { a: 1.5 } }), null)
  assert.strictEqual(deserializeAffinity({ ...base, votes: { a: 0 } }), null)
  assert.strictEqual(deserializeAffinity({ ...base, votes: { a: 'yes' } }), null)
})

test('serialize keeps votes whose artist has no edges yet', () => {
  // A vote can arrive before the crawl has recorded the artist's edges; the
  // taste must survive the restart anyway.
  const adj = graphOf([['a', 'b']])
  const seeds = new Map([['floating', SEED_LIKE]])
  const back = deserializeAffinity(serializeAffinity(adj, seeds, 'X'))
  assert.strictEqual(back.seeds.get('floating'), SEED_LIKE)
})

// ─── compactness ──────────────────────────────────────────────────────────────

test('serialize stores each undirected edge once, as index pairs', () => {
  const adj = graphOf([['a', 'b'], ['b', 'c'], ['a', 'c']])
  const json = serializeAffinity(adj, new Map(), 'X')
  assert.strictEqual(json.edges.length, 3)
  for (const [i, j] of json.edges) {
    assert.ok(Number.isInteger(i) && Number.isInteger(j), 'edges must be index pairs, not id strings')
  }
})

// ─── the disk is a trust boundary ────────────────────────────────────────────
// A corrupt or foreign file must yield null (caller starts fresh, loudly),
// never a half-built graph and never a throw.

test('deserialize rejects garbage instead of crashing or half-loading', () => {
  assert.strictEqual(deserializeAffinity(null), null)
  assert.strictEqual(deserializeAffinity('not an object'), null)
  assert.strictEqual(deserializeAffinity({}), null)
  assert.strictEqual(deserializeAffinity({ v: 99, ids: [], edges: [], votes: {} }), null)
  assert.strictEqual(deserializeAffinity({ v: 1, ids: ['a'], edges: [[0, 5]], votes: {} }), null,
    'edge index out of range = corrupt file')
  assert.strictEqual(deserializeAffinity({ v: 1, ids: ['a', 'b'], edges: [[0, 1]], votes: { a: 7 } }), null,
    'a vote outside ±1 = corrupt file')
})
