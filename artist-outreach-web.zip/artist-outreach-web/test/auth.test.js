const test = require('node:test')
const assert = require('node:assert/strict')
const { startApp } = require('./helpers')
const { safeNext, decodeJwtPayload } = require('../server/auth')

const CLIENT_ID = 'test-client.apps.googleusercontent.com'
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url')
const idToken = claims => `${b64({ alg: 'RS256' })}.${b64(claims)}.sig`

// Fake fetch: only answers Google's token endpoint.
function fakeGoogle(claims, { status = 200, expectVerifier = true } = {}) {
  const calls = []
  const impl = async (url, init) => {
    if (url !== 'https://oauth2.googleapis.com/token') throw new Error('unexpected fetch ' + url)
    const body = new URLSearchParams(init.body)
    calls.push(Object.fromEntries(body))
    if (expectVerifier) assert.ok(body.get('code_verifier'), 'PKCE verifier')
    return new Response(JSON.stringify(status === 200 ? { id_token: idToken(claims), access_token: 'x' } : { error: 'invalid_grant' }), { status })
  }
  return { impl, calls }
}

async function googleLogin(app, client, next = '/') {
  const r1 = await client.get('/auth/google?next=' + encodeURIComponent(next))
  assert.equal(r1.status, 302)
  const loc = new URL(r1.headers.get('location'))
  assert.equal(loc.origin + loc.pathname, 'https://accounts.google.com/o/oauth2/v2/auth')
  assert.equal(loc.searchParams.get('client_id'), CLIENT_ID)
  assert.equal(loc.searchParams.get('code_challenge_method'), 'S256')
  assert.equal(loc.searchParams.get('redirect_uri'), `${app.base}/auth/google/callback`)
  const state = loc.searchParams.get('state')
  return client.get(`/auth/google/callback?code=abc&state=${state}`)
}

const env = { GOOGLE_CLIENT_ID: CLIENT_ID, GOOGLE_CLIENT_SECRET: 'secret', DEV_LOGIN: '0', ADMIN_EMAILS: 'boss@x.com' }
const now = () => Math.floor(Date.now() / 1000)

test('Google sign-in: state + PKCE, session, /api/me, logout', async () => {
  const g = fakeGoogle({ iss: 'https://accounts.google.com', aud: CLIENT_ID, exp: now() + 600, sub: 'g-1', email: 'Edu@X.com', email_verified: true, name: 'Edu', picture: 'https://p/x.png' })
  const app = await startApp(env, { fetchImpl: g.impl })
  try {
    const c = app.client()
    const r = await googleLogin(app, c, '/billing')
    assert.equal(r.status, 302)
    assert.equal(r.headers.get('location'), '/billing')
    assert.ok(c.jar.get('ao_session'))
    assert.equal(g.calls[0].client_secret, 'secret')

    const me = await (await c.get('/api/me')).json()
    assert.equal(me.user.email, 'edu@x.com')
    assert.equal(me.user.role, 'user')
    assert.equal(me.user.access, true)   // without Stripe configured: free access

    // the same sub comes back → same user
    const c2 = app.client()
    await googleLogin(app, c2)
    const me2 = await (await c2.get('/api/me')).json()
    assert.equal(me2.user.id, me.user.id)

    const out = await c.post('/auth/logout', undefined, { headers: { accept: 'application/json' } })
    assert.equal(out.status, 200)
    assert.equal((await c.get('/api/me')).status, 401)
    // the other session is still alive
    assert.equal((await c2.get('/api/me')).status, 200)
  } finally { await app.close() }
})

test('callback rejects a changed state, a foreign aud, an expired token and an unverified email', async () => {
  const cases = [
    [{ iss: 'accounts.google.com', aud: 'other', exp: now() + 600, sub: 's', email: 'a@x.com', email_verified: true }, 'token'],
    [{ iss: 'accounts.google.com', aud: CLIENT_ID, exp: now() - 10, sub: 's', email: 'a@x.com', email_verified: true }, 'token'],
    [{ iss: 'evil.com', aud: CLIENT_ID, exp: now() + 600, sub: 's', email: 'a@x.com', email_verified: true }, 'token'],
    [{ iss: 'accounts.google.com', aud: CLIENT_ID, exp: now() + 600, sub: 's', email: 'a@x.com', email_verified: false }, 'email'],
  ]
  for (const [claims, code] of cases) {
    const app = await startApp(env, { fetchImpl: fakeGoogle(claims).impl })
    try {
      const c = app.client()
      const r = await googleLogin(app, c)
      assert.equal(r.headers.get('location'), `/login?error=${code}`, JSON.stringify(claims))
      assert.equal(c.jar.get('ao_session'), undefined)
    } finally { await app.close() }
  }
  // a state that doesn't match the cookie
  const app = await startApp(env, { fetchImpl: fakeGoogle({}).impl })
  try {
    const c = app.client()
    await c.get('/auth/google')
    const r = await c.get('/auth/google/callback?code=abc&state=forged')
    assert.equal(r.headers.get('location'), '/login?error=state')
  } finally { await app.close() }
})

test('ALLOWED_EMAILS shuts the door on anyone not listed; ADMIN_EMAILS always gets in', async () => {
  const mk = email => fakeGoogle({ iss: 'accounts.google.com', aud: CLIENT_ID, exp: now() + 600, sub: 'sub-' + email, email, email_verified: true })
  for (const [email, ok] of [['out@x.com', false], ['in@x.com', true], ['boss@x.com', true]]) {
    const app = await startApp({ ...env, ALLOWED_EMAILS: 'in@x.com' }, { fetchImpl: mk(email).impl })
    try {
      const r = await googleLogin(app, app.client())
      assert.equal(r.headers.get('location'), ok ? '/' : '/login?error=invite', email)
    } finally { await app.close() }
  }
})

test('pages and API without a session', async () => {
  const app = await startApp({ DEV_LOGIN: '1' })
  try {
    const c = app.client()
    const r = await c.get('/')
    assert.equal(r.status, 302)
    assert.equal(r.headers.get('location'), '/login?next=%2F')
    assert.equal((await c.get('/api/artists')).status, 401)
    assert.equal((await c.get('/login')).status, 200)
    assert.equal((await c.get('/healthz')).status, 200)
    // static files without data are fine
    assert.equal((await c.get('/app.js')).status, 200)
    await c.login('dev@x.com')
    assert.equal((await c.get('/login')).headers.get('location'), '/')
    assert.equal((await c.get('/')).status, 200)
  } finally { await app.close() }
})

test('POST with a foreign Origin → 403', async () => {
  const app = await startApp()
  try {
    const c = await app.client().login('a@x.com')
    const r = await c.post('/api/folders', { name: 'x' }, { headers: { origin: 'https://evil.example' } })
    assert.equal(r.status, 403)
    const ok = await c.post('/api/folders', { name: 'x' })
    assert.equal((await ok.json()).success, true)
  } finally { await app.close() }
})

test('dev login does not exist in production', async () => {
  const app = await startApp({ DEV_LOGIN: '1', NODE_ENV: 'production' })
  try {
    assert.equal((await app.client().get('/auth/dev?email=a@x.com')).status, 404)
  } finally { await app.close() }
})

test('safeNext and decodeJwtPayload', () => {
  assert.equal(safeNext('/billing?x=1'), '/billing?x=1')
  assert.equal(safeNext('//evil.com'), '/')
  assert.equal(safeNext('https://evil.com'), '/')
  assert.equal(safeNext('/\\evil.com'), '/')
  assert.equal(safeNext(undefined), '/')
  assert.deepEqual(decodeJwtPayload(idToken({ a: 1 })), { a: 1 })
  assert.equal(decodeJwtPayload('garbage'), null)
})
