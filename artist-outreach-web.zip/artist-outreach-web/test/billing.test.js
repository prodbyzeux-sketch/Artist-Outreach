const test = require('node:test')
const assert = require('node:assert/strict')
const Stripe = require('stripe')
const { startApp } = require('./helpers')
const { setup } = require('../scripts/stripe-setup')
const { addMonths, publicCatalog } = require('../server/billing/plans')

const WH_SECRET = 'whsec_test_123'
const real = new Stripe('sk_test_dummy')   // only to sign/verify webhooks (local)

const PRICE_IDS = {
  ao_starter_monthly: 'price_sm', ao_starter_yearly: 'price_sy',
  ao_pro_monthly: 'price_pm', ao_pro_yearly: 'price_py',
}
const PRICE_META = {
  price_sm: { plan: 'starter', interval: 'month' }, price_sy: { plan: 'starter', interval: 'year' },
  price_pm: { plan: 'pro', interval: 'month' }, price_py: { plan: 'pro', interval: 'year' },
}

function fakeStripe() {
  const state = { customers: [], sessions: [], subs: new Map(), updates: [] }
  const priceObj = id => ({ id, metadata: PRICE_META[id], recurring: { interval: PRICE_META[id].interval } })
  return {
    state,
    webhooks: real.webhooks,
    customers: { create: async p => { const c = { id: 'cus_' + (state.customers.length + 1), ...p }; state.customers.push(c); return c } },
    prices: { list: async ({ lookup_keys }) => ({ data: lookup_keys.filter(k => PRICE_IDS[k]).map(k => ({ id: PRICE_IDS[k], lookup_key: k })) }) },
    checkout: {
      sessions: {
        create: async p => { const s = { id: 'cs_' + (state.sessions.length + 1), url: 'https://checkout.stripe.test/' + (state.sessions.length + 1), ...p }; state.sessions.push(s); return s },
        retrieve: async id => state.sessions.find(s => s.id === id),
      },
    },
    billingPortal: { sessions: { create: async p => { state.portal = p; return { url: 'https://billing.stripe.test/portal' } } } },
    subscriptions: {
      list: async ({ customer }) => ({ data: [...state.subs.values()].filter(s => s.customer === customer) }),
      retrieve: async id => [...state.subs.values()].find(s => s.id === id),
      update: async (id, params) => {
        state.updates.push({ id, params })
        const s = [...state.subs.values()].find(x => x.id === id)
        if (params.cancel_at !== undefined) s.cancel_at = params.cancel_at === '' ? null : params.cancel_at
        if (params.cancel_at_period_end !== undefined) s.cancel_at_period_end = params.cancel_at_period_end
        if (params.items) s.items.data[0].price = priceObj(params.items[0].price)
        if (params.metadata) s.metadata = params.metadata
        return s
      },
    },
    _sub(customer, priceId, status = 'active', extra = {}) {
      const start = extra.start_date || Math.floor(Date.now() / 1000) - 86400
      const s = {
        id: 'sub_' + customer, object: 'subscription', customer, status, cancel_at_period_end: false, cancel_at: null,
        created: start, start_date: start,
        metadata: { plan: PRICE_META[priceId].plan, interval: PRICE_META[priceId].interval, commitment_months: PRICE_META[priceId].interval === 'month' ? '12' : '0' },
        items: { data: [{ id: 'si_' + customer, price: priceObj(priceId), current_period_end: Math.floor(Date.now() / 1000) + 20 * 86400 }] },
        ...extra,
      }
      state.subs.set(customer, s)
      return s
    },
  }
}

const env = { STRIPE_SECRET_KEY: 'sk_test_dummy', STRIPE_WEBHOOK_SECRET: WH_SECRET, TRIAL_DAYS: '0', ADMIN_EMAILS: 'boss@x.com', STRIPE_PORTAL_CONFIGURATION: 'bpc_123' }

async function sendWebhook(app, event, { secret = WH_SECRET } = {}) {
  const payload = JSON.stringify(event)
  const header = real.webhooks.generateTestHeaderString({ payload, secret })
  return fetch(app.base + '/billing/webhook', {
    method: 'POST', headers: { 'content-type': 'application/json', 'stripe-signature': header }, body: payload,
  })
}

async function subscribe(app, stripe, c, plan, interval, extra) {
  const r = await (await c.post('/billing/checkout', { plan, interval })).json()
  assert.equal(r.success, true, JSON.stringify(r))
  const s = stripe.state.sessions.at(-1)
  stripe._sub(s.customer, s.line_items[0].price, 'active', extra)
  const back = await c.get('/billing/return?session_id=' + s.id)
  assert.equal(back.headers.get('location'), '/billing?status=success')
  return s
}

test('the catalog: €7 / €17 monthly, 20% off yearly', () => {
  const cat = publicCatalog()
  const starter = cat.plans.find(p => p.key === 'starter'), pro = cat.plans.find(p => p.key === 'pro')
  assert.equal(starter.prices.month.amount, 700)
  assert.equal(starter.prices.year.amount, 6720)
  assert.equal(starter.prices.year.amount, Math.round(700 * 12 * 0.8))
  assert.equal(pro.prices.month.amount, 1700)
  assert.equal(pro.prices.year.amount, 16320)
  assert.equal(pro.prices.year.amount, Math.round(20400 * 0.8))
  assert.equal(starter.dailyAutoDms, 10)
  assert.equal(pro.dailyAutoDms, null)
  assert.equal(starter.prices.month.commitmentMonths, 12)
  assert.equal(pro.prices.year.commitmentMonths, 0)
  assert.equal(addMonths(new Date('2026-01-31T10:00:00Z'), 1).toISOString(), '2026-02-28T10:00:00.000Z')
  assert.equal(addMonths(new Date('2026-10-12T10:00:00Z'), 12).toISOString(), '2027-10-12T10:00:00.000Z')
})

test('no subscription: API 402, / goes to /billing; admins always in', async () => {
  const stripe = fakeStripe()
  const app = await startApp(env, { stripeClient: stripe })
  try {
    const c = await app.client().login('user@x.com')
    assert.equal((await c.get('/api/artists')).status, 402)
    assert.equal((await c.get('/')).headers.get('location'), '/billing')
    assert.equal((await c.get('/billing')).status, 200)
    const plans = await (await c.get('/billing/plans')).json()
    assert.equal(plans.plans.length, 2)
    const boss = await app.client().login('boss@x.com')
    assert.equal((await boss.get('/api/artists')).status, 200)
    const me = (await (await boss.get('/api/me')).json()).user
    assert.equal(me.plan.key, 'pro')
  } finally { await app.close() }
})

test('monthly checkout states the commitment; webhook grants access with the right plan', async () => {
  const stripe = fakeStripe()
  const app = await startApp({ ...env, STRIPE_MANAGED_PAYMENTS: '1', TRIAL_DAYS: '7' }, { stripeClient: stripe })
  try {
    const c = await app.client().login('user@x.com')
    assert.equal((await (await c.post('/billing/checkout', { plan: 'gold', interval: 'month' })).json()).error, 'plan_and_interval_required')
    const r = await (await c.post('/billing/checkout', { plan: 'starter', interval: 'month' })).json()
    assert.equal(r.success, true)
    const s = stripe.state.sessions[0]
    assert.deepEqual(s.line_items, [{ price: 'price_sm', quantity: 1 }])
    assert.match(s.custom_text.submit.message, /12-month commitment.*€7 every month/)
    assert.deepEqual(s.managed_payments, { enabled: true })
    assert.equal(s.subscription_data.trial_period_days, 7)
    assert.equal(s.subscription_data.metadata.plan, 'starter')

    // yearly: no commitment text
    const c2 = await app.client().login('other@x.com')
    await c2.post('/billing/checkout', { plan: 'pro', interval: 'year' })
    assert.equal(stripe.state.sessions[1].line_items[0].price, 'price_py')
    assert.equal(stripe.state.sessions[1].custom_text, undefined)

    // bad signature → 400
    const sub = stripe._sub(s.customer, 'price_sm', 'trialing', { trial_end: 1 })
    assert.equal((await sendWebhook(app, { id: 'evt_bad', type: 'customer.subscription.created', data: { object: sub } }, { secret: 'whsec_x' })).status, 400)
    const ok = await sendWebhook(app, { id: 'evt_1', type: 'checkout.session.completed', data: { object: { mode: 'subscription', customer: s.customer, client_reference_id: s.client_reference_id } } })
    assert.equal(ok.status, 200)
    assert.equal((await c.get('/api/artists')).status, 200)
    const me = (await (await c.get('/api/me')).json()).user
    assert.equal(me.plan.key, 'starter')
    assert.equal(me.plan.dailyAutoDms, 10)
    assert.equal(me.billing.interval, 'month')
    assert.equal(me.billing.inCommitment, true)
    assert.equal(me.billing.canTrial, false)
    assert.equal(me.billing.commitmentEndsAt, addMonths(new Date(sub.start_date * 1000), 12).toISOString())
    // duplicate event: idempotent
    assert.equal((await (await sendWebhook(app, { id: 'evt_1', type: 'checkout.session.completed', data: { object: { mode: 'subscription', customer: s.customer } } })).json()).duplicate, true)
    // deleted → no access
    sub.status = 'canceled'
    await sendWebhook(app, { id: 'evt_2', type: 'customer.subscription.deleted', data: { object: sub } })
    assert.equal((await c.get('/api/artists')).status, 402)
  } finally { await app.close() }
})

test('cancelling a monthly plan inside the commitment ends it after month 12; resume undoes it', async () => {
  const stripe = fakeStripe()
  const app = await startApp(env, { stripeClient: stripe })
  try {
    const c = await app.client().login('user@x.com')
    const start = Math.floor(Date.UTC(2026, 8, 15, 12) / 1000)   // 15 Sep 2026
    await subscribe(app, stripe, c, 'pro', 'month', { start_date: start })
    const r = await (await c.post('/billing/cancel', {})).json()
    assert.equal(r.success, true)
    assert.equal(r.commitment, true)
    const upd = stripe.state.updates.at(-1).params
    assert.equal(upd.cancel_at, Math.floor(Date.UTC(2027, 8, 15, 12) / 1000))
    assert.equal(upd.proration_behavior, 'none')
    assert.equal(r.endsAt, '2027-09-15T12:00:00.000Z')
    let me = (await (await c.get('/api/me')).json()).user
    assert.equal(me.billing.endsAt, '2027-09-15T12:00:00.000Z')
    assert.equal((await c.get('/api/artists')).status, 200)   // still has access until then

    await c.post('/billing/resume', {})
    assert.equal(stripe.state.updates.at(-1).params.cancel_at, '')
    me = (await (await c.get('/api/me')).json()).user
    assert.equal(me.billing.endsAt, null)
  } finally { await app.close() }
})

test('after the commitment, or on yearly plans, cancel = at period end', async () => {
  const stripe = fakeStripe()
  const app = await startApp(env, { stripeClient: stripe })
  try {
    const old = await app.client().login('old@x.com')
    const longAgo = Math.floor(Date.now() / 1000) - 400 * 86400
    await subscribe(app, stripe, old, 'starter', 'month', { start_date: longAgo })
    await old.post('/billing/cancel', {})
    assert.deepEqual(stripe.state.updates.at(-1).params, { cancel_at_period_end: true })

    const yearly = await app.client().login('yearly@x.com')
    await subscribe(app, stripe, yearly, 'starter', 'year')
    assert.equal((await (await yearly.get('/api/me')).json()).user.billing.inCommitment, false)
    await yearly.post('/billing/cancel', {})
    assert.deepEqual(stripe.state.updates.at(-1).params, { cancel_at_period_end: true })
  } finally { await app.close() }
})

test('upgrade Starter → Pro keeps the interval; portal uses the no-cancel configuration', async () => {
  const stripe = fakeStripe()
  const app = await startApp(env, { stripeClient: stripe })
  try {
    const c = await app.client().login('user@x.com')
    await subscribe(app, stripe, c, 'starter', 'year')
    const r = await (await c.post('/billing/upgrade', {})).json()
    assert.equal(r.success, true)
    const upd = stripe.state.updates.at(-1).params
    assert.deepEqual(upd.items, [{ id: 'si_cus_1', price: 'price_py' }])
    assert.equal(upd.proration_behavior, 'always_invoice')
    const me = (await (await c.get('/api/me')).json()).user
    assert.equal(me.plan.key, 'pro')
    assert.equal(me.plan.dailyAutoDms, null)
    assert.equal((await (await c.post('/billing/upgrade', {})).json()).error, 'already_pro')

    const p = await (await c.post('/billing/portal', {})).json()
    assert.equal(stripe.state.portal.configuration, 'bpc_123')
    assert.equal(p.url, 'https://billing.stripe.test/portal')
    assert.equal((await (await c.post('/billing/checkout', { plan: 'pro', interval: 'month' })).json()).error, 'already_subscribed')
  } finally { await app.close() }
})

test("someone else's Checkout return grants nothing", async () => {
  const stripe = fakeStripe()
  const app = await startApp(env, { stripeClient: stripe })
  try {
    const a = await app.client().login('a@x.com')
    await a.post('/billing/checkout', { plan: 'pro', interval: 'month' })
    const s = stripe.state.sessions[0]
    stripe._sub(s.customer, 'price_pm')
    const b = await app.client().login('b@x.com')
    await b.get('/billing/return?session_id=' + s.id)
    assert.equal((await b.get('/api/artists')).status, 402)
  } finally { await app.close() }
})

test('daily DM quota: Starter stops at 10, release gives one back, Pro is unlimited', async () => {
  const stripe = fakeStripe()
  const app = await startApp(env, { stripeClient: stripe })
  try {
    const c = await app.client().login('starter@x.com')
    await subscribe(app, stripe, c, 'starter', 'month')
    const { token } = await (await c.post('/api/ext/pair', {})).json()
    const ext = (path, body) => fetch(app.base + '/ext/v1' + path, {
      method: body ? 'POST' : 'GET', headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    }).then(r => r.json())

    const results = []
    for (let i = 0; i < 11; i++) results.push(await ext('/quota/claim', { tz: -120 }))
    assert.deepEqual(results.map(r => r.ok), [...Array(10).fill(true), false])
    assert.equal(results[9].remaining, 0)
    assert.equal(results[10].error, 'daily_limit')
    assert.deepEqual((await ext('/quota?tz=-120')), { success: true, plan: 'starter', day: results[0].day, used: 10, limit: 10, remaining: 0 })
    await ext('/quota/release', { day: results[0].day })
    assert.equal((await ext('/quota/claim', { tz: -120 })).ok, true)
    assert.equal((await (await c.get('/api/quota?tz=-120')).json()).used, 10)

    const pro = await app.client().login('pro@x.com')
    await subscribe(app, stripe, pro, 'pro', 'month')
    const { token: t2 } = await (await pro.post('/api/ext/pair', {})).json()
    for (let i = 0; i < 25; i++) {
      const r = await fetch(app.base + '/ext/v1/quota/claim', { method: 'POST', headers: { authorization: 'Bearer ' + t2, 'content-type': 'application/json' }, body: '{}' }).then(r => r.json())
      assert.equal(r.ok, true)
      assert.equal(r.remaining, null)
    }
  } finally { await app.close() }
})

test('stripe-setup creates products, 4 EUR prices, a no-cancel portal and the webhook — idempotently', async () => {
  const db = { products: [], prices: [], configs: [], hooks: [] }
  let n = 0
  const id = p => `${p}_${++n}`
  const fake = {
    products: {
      list: async () => ({ data: db.products }),
      create: async p => { const x = { id: id('prod'), active: true, ...p }; db.products.push(x); return x },
    },
    prices: {
      list: async ({ lookup_keys }) => ({ data: db.prices.filter(p => lookup_keys.includes(p.lookup_key)) }),
      create: async p => {
        if (p.transfer_lookup_key) db.prices.forEach(x => { if (x.lookup_key === p.lookup_key) x.lookup_key = null })
        const x = { id: id('price'), active: true, ...p }; db.prices.push(x); return x
      },
    },
    billingPortal: { configurations: {
      list: async () => ({ data: db.configs }),
      create: async p => { const x = { id: id('bpc'), ...p }; db.configs.push(x); return x },
      update: async (cid, p) => Object.assign(db.configs.find(c => c.id === cid), p),
    } },
    webhookEndpoints: {
      list: async () => ({ data: db.hooks }),
      create: async p => { const x = { id: id('we'), secret: 'whsec_new', ...p }; db.hooks.push(x); return x },
      update: async (hid, p) => Object.assign(db.hooks.find(h => h.id === hid), p),
    },
  }
  const quiet = () => {}
  const first = await setup(fake, { url: 'https://app.test', webhook: true, log: quiet })
  assert.equal(db.products.length, 2)
  assert.equal(db.prices.length, 4)
  const byKey = Object.fromEntries(db.prices.map(p => [p.lookup_key, p]))
  assert.equal(byKey.ao_pro_yearly.unit_amount, 16320)
  assert.equal(byKey.ao_starter_yearly.unit_amount, 6720)
  assert.equal(byKey.ao_starter_monthly.recurring.interval, 'month')
  assert.equal(byKey.ao_pro_monthly.currency, 'eur')
  assert.equal(byKey.ao_pro_monthly.tax_behavior, 'inclusive')
  assert.equal(db.products[0].tax_code, 'txcd_10103001')
  assert.equal(db.configs[0].features.subscription_cancel.enabled, false)
  assert.equal(db.configs[0].features.subscription_update.enabled, false)
  assert.equal(db.configs[0].business_profile.privacy_policy_url, 'https://app.test/privacy')
  assert.equal(first.webhookSecret, 'whsec_new')
  assert.equal(db.hooks[0].url, 'https://app.test/billing/webhook')

  const second = await setup(fake, { url: 'https://app.test', webhook: true, log: quiet })
  assert.equal(db.products.length, 2)
  assert.equal(db.prices.length, 4)
  assert.equal(db.configs.length, 1)
  assert.equal(db.hooks.length, 1)
  assert.equal(second.webhookSecret, null)
  assert.equal(second.portalConfiguration, first.portalConfiguration)
})
