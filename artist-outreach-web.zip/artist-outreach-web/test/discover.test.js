// /api/discover end to end against a simulated Spotify.
//
// The engine runs its queries inside page.evaluate(fn, args). Here the "page"
// runs fn in Node and the global fetch answers like Spotify's GraphQL and
// Instagram's API for a made-up graph. That way the real pipeline (BFS,
// verification pools, SSE stream, saved pools, seen artists, votes, turns) is
// tested without a network.

const test = require('node:test')
const assert = require('node:assert/strict')
const { startApp } = require('./helpers')

const N = 80
const idOf = i => `art${String(i).padStart(3, '0')}`
const idxOf = id => parseInt(id.slice(3), 10)
const related = i => [1, 2, 3, 5, 8, 13, 21].map(k => idOf((i + k) % N))

function artistUnion(i) {
  const id = idOf(i)
  return {
    __typename: 'Artist', id, uri: `spotify:artist:${id}`,
    profile: { name: `Artist ${i}`, externalLinks: { items: i % 2 === 0 ? [{ name: 'INSTAGRAM', url: `https://instagram.com/${id}` }] : [] } },
    stats: { monthlyListeners: Math.round(3_000_000 / (i + 1)), followers: 10, topCities: { items: [{ city: 'Madrid', country: 'ES' }] } },
    visuals: { avatarImage: { sources: [{ url: `https://img/${id}.jpg`, width: 640 }] } },
    headerImage: null,
    discography: { latest: { name: 'Single', date: { year: 2026, month: 8, day: 1 } } },
    relatedContent: { relatedArtists: { items: related(i).map(rid => ({ id: rid, uri: `spotify:artist:${rid}`, profile: { name: `Artist ${idxOf(rid)}` }, visuals: { avatarImage: { sources: [] } } })) } },
  }
}

const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } })
const realFetch = globalThis.fetch
let spotifyCalls = 0, igCalls = 0

globalThis.fetch = async (input, init) => {
  const url = typeof input === 'string' ? input : input.url
  if (url.startsWith('https://api-partner.spotify.com/pathfinder/v2/query')) {
    spotifyCalls++
    const body = JSON.parse(init.body)
    if (body.operationName === 'queryArtistOverview') {
      const id = body.variables.uri.split(':')[2]
      const i = idxOf(id)
      return Number.isInteger(i) && i >= 0 && i < N ? json({ data: { artistUnion: artistUnion(i) } }) : json({ data: { artistUnion: null } })
    }
    if (body.operationName === 'searchArtists') {
      return json({ data: { searchV2: { artists: { items: [{ data: artistUnion(0) }] } } } })
    }
    return json({}, 400)
  }
  if (url.startsWith('https://www.instagram.com/api/v1/users/web_profile_info/')) {
    igCalls++
    const u = new URL(url).searchParams.get('username')
    // IG followers proportional to listeners, as in real life.
    return json({ data: { user: { edge_followed_by: { count: Math.round(3_000_000 / (idxOf(u) + 1) / 100) } } } })
  }
  if (/^https?:\/\/(127\.0\.0\.1|localhost)/.test(url)) return realFetch(input, init)
  return new Response('nope', { status: 404 })
}

function fakeSpotify() {
  const page = {
    evaluate: async (fn, arg) => fn(arg),
    context: () => ({ newPage: async () => page }),
    close: async () => {},
    isClosed: () => false,
    waitForTimeout: ms => new Promise(r => setTimeout(r, ms)),
    goto: async () => { throw new Error('no browser in tests') },
    url: () => 'about:blank',
  }
  return { browser: { close: async () => {} }, context: null, page, token: 't', clientToken: 'c',
    shaMap: { queryArtistOverview: 'sha1', searchArtists: 'sha2' }, expiry: Date.now() + 3600_000 }
}

// Reads the SSE until 'done' (or until the server closes it).
async function discover(client, params) {
  const res = await client.get('/api/discover?' + new URLSearchParams(params))
  assert.equal(res.status, 200)
  const reader = res.body.getReader()
  const dec = new TextDecoder()
  let buf = ''
  const events = []
  for (;;) {
    const { value, done } = await reader.read()
    if (done) break
    buf += dec.decode(value, { stream: true })
    let i
    while ((i = buf.indexOf('\n\n')) >= 0) {
      const chunk = buf.slice(0, i); buf = buf.slice(i + 2)
      if (chunk.startsWith('data: ')) events.push(JSON.parse(chunk.slice(6)))
    }
    if (events.some(e => e.type === 'done' || e.type === 'error')) { reader.cancel().catch(() => {}); break }
  }
  return { events, artists: events.filter(e => e.type === 'artist').map(e => e.artist), done: events.find(e => e.type === 'done') }
}

const env = { GOOGLE_SEARCH: '0', MAX_CONCURRENT_CRAWLS: '1' }

test('a full crawl: stream, Instagram, saved pool and per-user seen artists', async () => {
  const app = await startApp(env)
  app.engine._setSpotifyForTests(fakeSpotify())
  try {
    const a = await app.client().login('a@x.com')
    const r = await discover(a, { artistId: idOf(0), artistName: 'Artist 0', sessionId: 's1' })
    assert.ok(r.done, 'ends with done')
    assert.ok(r.artists.length >= 30, `artistas: ${r.artists.length}`)
    const ids = r.artists.map(x => x.id)
    assert.equal(new Set(ids).size, ids.length, 'no duplicates')
    assert.ok(!ids.includes(idOf(0)), 'the reference artist is not shown')
    // only the ones with Instagram come out (odd ones don't link it and Google is off)
    assert.ok(r.artists.every(x => x.instagram && Number.isInteger(x.igFollowers)))
    assert.ok(spotifyCalls > 0 && igCalls > 0)

    // the pool is saved for this user
    await new Promise(res => setTimeout(res, 300))
    const pool = await (await a.get(`/api/pool?refId=${idOf(0)}`)).json()
    assert.equal(pool.artists.length, r.artists.length)

    // B doesn't see A's pool
    const b = await app.client().login('b@x.com')
    assert.equal((await (await b.get(`/api/pool?refId=${idOf(0)}`)).json()).artists.length, 0)

    // seen: what A marks doesn't come back to A, but it does to B
    const hide = ids.slice(0, 10)
    await a.post('/api/seen', { ids: hide })
    const again = await discover(a, { artistId: idOf(0), sessionId: 's2' })
    assert.ok(again.artists.every(x => !hide.includes(x.id)))
    const forB = await discover(b, { artistId: idOf(0), sessionId: 's3' })
    assert.ok(hide.some(id => forB.artists.map(x => x.id).includes(id)))

    // IG follower filter on the server
    const narrow = await discover(b, { artistId: idOf(0), sessionId: 's4', igMin: '300', igMax: '1000' })
    assert.ok(narrow.artists.length > 0)
    assert.ok(narrow.artists.every(x => x.igFollowers >= 300 && x.igFollowers <= 1000))
  } finally { await app.close() }
})

test("votes: they reorder, are saved in the database and are each user's own", async () => {
  const app = await startApp(env)
  app.engine._setSpotifyForTests(fakeSpotify())
  try {
    const a = await app.client().login('a@x.com')
    const r = await discover(a, { artistId: idOf(0), sessionId: 'v1' })
    const poolIds = r.artists.map(x => x.id)
    const fb = await (await a.post('/api/feedback', { sessionId: 'v1', artistId: poolIds[0], action: 'save', poolIds })).json()
    assert.equal(fb.success, true)
    assert.equal(fb.affinitySeeds, 1)
    assert.ok(Object.keys(fb.affinity).length > 0, 'the vote reaches the pool')

    await a.post('/api/session-reset', { sessionId: 'v1' })
    await new Promise(res => setTimeout(res, 200))
    const { rows } = await app.db.query(`select u.email, length(a.blob) as n from affinity a join users u on u.id = a.user_id`)
    assert.equal(rows.length, 1)
    assert.equal(rows[0].email, 'a@x.com')

    // B starts without votes
    const b = await app.client().login('b@x.com')
    const fbB = await (await b.post('/api/feedback', { sessionId: 'v2', artistId: poolIds[1], action: 'not-similar', poolIds })).json()
    assert.equal(fbB.affinitySeeds, 1)
  } finally { await app.close() }
})

test('turns: with MAX_CONCURRENT_CRAWLS=1 the second search waits and finishes', async () => {
  const app = await startApp(env)
  app.engine._setSpotifyForTests(fakeSpotify())
  try {
    const a = await app.client().login('a@x.com')
    const b = await app.client().login('b@x.com')
    const [ra, rb] = await Promise.all([
      discover(a, { artistId: idOf(0), sessionId: 'c1' }),
      discover(b, { artistId: idOf(5), sessionId: 'c2' }),
    ])
    assert.ok(ra.done && rb.done)
    assert.ok(ra.artists.length > 0 && rb.artists.length > 0)
    const waited = [ra, rb].some(r => r.events.some(e => e.type === 'progress' && e.waiting))
    assert.ok(waited, 'one of the two had to wait its turn')
    assert.equal(app.engine.status().crawls.active, 0)
  } finally { await app.close() }
})

test("a new search by the same user stops the previous one", async () => {
  const app = await startApp({ GOOGLE_SEARCH: '0', MAX_CONCURRENT_CRAWLS: '3' })
  app.engine._setSpotifyForTests(fakeSpotify())
  try {
    const a = await app.client().login('a@x.com')
    const first = discover(a, { artistId: idOf(0), sessionId: 'x1' })
    await new Promise(res => setTimeout(res, 150))
    const second = await discover(a, { artistId: idOf(7), sessionId: 'x2' })
    const r1 = await first
    assert.ok(r1.done?.superseded || r1.done, 'the first one ends')
    assert.ok(second.done && !second.done.superseded)
    await new Promise(res => setTimeout(res, 100))
    assert.equal(app.engine.status().crawls.active, 0)
  } finally { await app.close() }
})
