const test = require('node:test')
const assert = require('node:assert/strict')
const { startApp } = require('./helpers')

const bearer = (app, token) => ({
  get: p => fetch(app.base + '/ext/v1' + p, { headers: { authorization: 'Bearer ' + token } }),
  post: (p, body) => fetch(app.base + '/ext/v1' + p, {
    method: 'POST', headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json', origin: 'chrome-extension://abc' }, body: JSON.stringify(body),
  }),
})

async function seed(c) {
  const save = a => c.post('/api/artists', { id: a, name: 'Artist ' + a, url: 'u', followers: 500, instagram: `https://www.instagram.com/${a}_ig/` })
  await save('a'); await save('b'); await save('c')
  await c.post('/api/artists', { id: 'noig', name: 'No IG', url: 'u', followers: 1 })
  const f = await (await c.post('/api/folders', { name: 'Melodic' })).json()
  await c.post('/api/artists/move', { ids: ['c'], folderId: f.folder.id })
  return f.folder
}

test('pair and read prospects with the token', async () => {
  const app = await startApp()
  try {
    const c = await app.client().login('edu@x.com')
    const folder = await seed(c)

    assert.equal((await bearer(app, 'x'.repeat(40)).get('/me')).status, 401)
    const pair = await (await c.post('/api/ext/pair', { label: 'Chrome' })).json()
    assert.equal(pair.success, true)
    assert.equal(pair.origin, app.base)
    const ext = bearer(app, pair.token)

    const me = await (await ext.get('/me')).json()
    assert.equal(me.user.email, 'edu@x.com')
    // open CORS (auth by Bearer, not by cookie)
    const pre = await fetch(app.base + '/ext/v1/prospects', { method: 'OPTIONS', headers: { origin: 'chrome-extension://abc' } })
    assert.equal(pre.status, 204)
    assert.equal(pre.headers.get('access-control-allow-origin'), '*')

    const all = await (await ext.get('/prospects?status=pending')).json()
    assert.deepEqual(all.prospects.map(p => p.handle).sort(), ['a_ig', 'b_ig', 'c_ig'])
    const inFolder = await (await ext.get(`/prospects?status=pending&folder=${folder.id}`)).json()
    assert.deepEqual(inFolder.prospects.map(p => p.id), ['c'])
    assert.deepEqual((await (await ext.get('/folders')).json()).folders.map(f => f.name), ['Melodic'])

    // revoke from the web
    await c.post('/api/ext/revoke-all', {})
    assert.equal((await ext.get('/me')).status, 401)
  } finally { await app.close() }
})

test('events: sent marks contacted, replied wins, a late sent does not go backwards', async () => {
  const app = await startApp()
  try {
    const c = await app.client().login('edu@x.com')
    await seed(c)
    const { token } = await (await c.post('/api/ext/pair', {})).json()
    const ext = bearer(app, token)
    const t0 = '2026-10-01T10:00:00.000Z'
    let r = await (await ext.post('/events', { events: [
      { handle: '@A_ig', state: 'sent', at: t0, campaign: 'Oct' },
      { prospectId: 'b', handle: 'b_ig', state: 'failed', at: t0, error: 'no message button' },
      { handle: 'ghost', state: 'sent', at: t0 },
      { handle: 'a_ig', state: 'bogus' },
    ] })).json()
    assert.deepEqual(r, { success: true, updated: 2, unknown: 1 })

    let list = (await (await c.get('/api/artists')).json()).artists
    const a = list.find(x => x.id === 'a'), b = list.find(x => x.id === 'b')
    assert.equal(a.status, 'contacted')
    assert.equal(a.contacted_at, t0)
    assert.equal(a.outreach_state, 'sent')
    assert.equal(b.status, 'saved')
    assert.equal(b.outreach_state, 'failed')
    assert.equal(b.outreach_error, 'no message button')

    await ext.post('/events', { events: [{ handle: 'a_ig', state: 'replied', at: '2026-10-02T10:00:00.000Z' }] })
    await ext.post('/events', { events: [{ handle: 'a_ig', state: 'sent', at: '2026-10-03T10:00:00.000Z' }] })
    list = (await (await c.get('/api/artists')).json()).artists
    const a2 = list.find(x => x.id === 'a')
    assert.equal(a2.outreach_state, 'replied')
    assert.equal(a2.replied_at, '2026-10-02T10:00:00.000Z')
    assert.equal(a2.contacted_at, t0)

    const st = await (await c.get('/api/ext/status')).json()
    assert.equal(st.tokens, 1)
    assert.equal(st.events.sent, 3)
  } finally { await app.close() }
})

test("one user's token cannot see another user's data", async () => {
  const app = await startApp()
  try {
    const a = await app.client().login('a@x.com')
    await seed(a)
    const b = await app.client().login('b@x.com')
    const { token } = await (await b.post('/api/ext/pair', {})).json()
    const ext = bearer(app, token)
    assert.deepEqual((await (await ext.get('/prospects?status=all')).json()).prospects, [])
    const r = await (await ext.post('/events', { events: [{ prospectId: 'a', handle: 'a_ig', state: 'sent' }] })).json()
    assert.deepEqual(r, { success: true, updated: 0, unknown: 1 })
    const aList = (await (await a.get('/api/artists')).json()).artists
    assert.equal(aList.find(x => x.id === 'a').status, 'saved')
  } finally { await app.close() }
})

test('follower counts from the extension reach the shared cache', async () => {
  const app = await startApp({ IG_SERVER_LOOKUPS: '0' })
  try {
    const c = await app.client().login('a@x.com')
    const { token } = await (await c.post('/api/ext/pair', {})).json()
    const r = await (await bearer(app, token).post('/ig-followers', { results: { 'https://www.instagram.com/foo/': 1234, 'bad/handle': 5, bar: -1 } })).json()
    assert.equal(r.stored, 1)
    // another user benefits: the server answers from the cache without asking Instagram
    const other = await app.client().login('b@x.com')
    const batch = await (await other.post('/api/ig-batch', { urls: ['https://www.instagram.com/foo/', 'https://www.instagram.com/unknown/'] })).json()
    assert.deepEqual(batch.results, { 'https://www.instagram.com/foo/': 1234, 'https://www.instagram.com/unknown/': null })
    // and from the web (cookie)
    const w = await (await other.post('/api/ig-report', { results: { 'https://www.instagram.com/baz/': 99 } })).json()
    assert.equal(w.stored, 1)
  } finally { await app.close() }
})
