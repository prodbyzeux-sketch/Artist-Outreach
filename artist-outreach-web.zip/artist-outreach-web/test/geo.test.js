const { test } = require('node:test')
const assert = require('node:assert')
const fs = require('fs')
const path = require('path')
const { parseTopCities, matchesCountry } = require('../server/lib/geo')

const stats = items => ({ monthlyListeners: 139, topCities: { items } })
const city = (city, country, numberOfListeners) => ({ city, country, region: 'XX', numberOfListeners })

// ─── parseTopCities ───────────────────────────────────────────────────────────

test('takes the first city for display and every country for filtering', () => {
  const g = parseTopCities(stats([
    city('Lagos', 'NG', 6), city('Seattle', 'US', 4), city('Brooklyn', 'US', 3),
    city('Calgary', 'CA', 3), city('Virginia Beach', 'US', 3)
  ]))
  assert.deepStrictEqual(g.topCity, { city: 'Lagos', country: 'NG' })
  assert.deepStrictEqual(g.countries, ['NG', 'US', 'CA'], 'deduplicated, first-seen order')
})

test('missing city data yields empty, never null-shaped junk', () => {
  for (const input of [stats([]), { monthlyListeners: 5 }, {}, null, undefined]) {
    const g = parseTopCities(input)
    assert.strictEqual(g.topCity, null)
    assert.deepStrictEqual(g.countries, [])
  }
})

test('entries without a country are dropped, not stored as empty codes', () => {
  const g = parseTopCities(stats([city('Nowhere', null, 9), city('Lima', 'PE', 4)]))
  assert.deepStrictEqual(g.topCity, { city: 'Lima', country: 'PE' })
  assert.deepStrictEqual(g.countries, ['PE'])
})

test('a city name without a country is not a display candidate', () => {
  const g = parseTopCities(stats([city(null, 'US', 9)]))
  assert.strictEqual(g.topCity, null, 'a chip reading "undefined" is worse than no chip')
  assert.deepStrictEqual(g.countries, ['US'])
})

// ─── matchesCountry ───────────────────────────────────────────────────────────
//
// The rule that matters: absence of data is not evidence of mismatch. Same
// principle the IG follower filter follows (pending vs out-of-range).

test('an artist with no city data passes every country filter', () => {
  for (const a of [{ countries: [] }, { countries: null }, {}]) {
    assert.strictEqual(matchesCountry(a, 'US'), true, 'silently vanishing is the bug')
  }
})

test('matches on ANY top city, not only the first', () => {
  const zayzayy = { countries: ['NG', 'US', 'CA'] }
  assert.strictEqual(matchesCountry(zayzayy, 'US'), true, 'a Lagos top city does not make him Nigerian')
  assert.strictEqual(matchesCountry(zayzayy, 'NG'), true)
  assert.strictEqual(matchesCountry(zayzayy, 'PE'), false)
})

test('no selected country means no filtering at all', () => {
  for (const none of ['', null, undefined]) {
    assert.strictEqual(matchesCountry({ countries: ['PE'] }, none), true)
  }
})

// ─── the duplicated copies inside page.evaluate ───────────────────────────────
//
// Node functions are invisible inside page.evaluate, so both crawl parsers carry
// their own copy of this logic (same reason bannerOf is duplicated). Forgetting
// one is silent: that parser just stops producing cities. Structural check —
// behaviour itself is covered above and end-to-end by a live crawl.

test('every in-page parser carries the cities copy', () => {
  // bannerOf is the marker: it exists ONLY as an in-evaluate duplicate, one per
  // crawl parser. Every place that needed its own banner helper needs its own
  // cities helper for exactly the same reason.
  const src = fs.readFileSync(path.join(__dirname, '..', 'server', 'engine', 'engine.js'), 'utf8')
  const count = needle => src.split(needle).length - 1
  const banners = count('const bannerOf =')
  assert.ok(banners >= 2, `expected the deep and mini crawl parsers, found ${banners}`)
  assert.strictEqual(count('const citiesOf ='), banners,
    'an in-page parser without its cities copy silently stops producing cities')
})
