const { test } = require('node:test')
const assert = require('node:assert/strict')
const { isBlockPage, searchPages, worthSearching, createGoogleGate, BLOCK_COOLDOWN_MS } = require('../server/lib/googleGate')

const RANGE = { active: true, min: 1000, max: 50000 }

test('worthSearching: without a listener filter everyone is searched', () => {
  assert.equal(worthSearching(60_000_000, { active: false, min: 0, max: 50000 }), true)
  assert.equal(worthSearching(500, {}), true)
})

test('worthSearching: inside the requested range, it is searched', () => {
  assert.equal(worthSearching(1000, RANGE), true, 'the lower edge is in')
  assert.equal(worthSearching(20_000, RANGE), true)
  assert.equal(worthSearching(50_000, RANGE), true, 'the upper edge is in')
})

// It is the crawl's dominant cost and the client drops them when filtering: the
// search would buy nothing.
test('worthSearching: outside the range no search is spent', () => {
  assert.equal(worthSearching(60_000_000, RANGE), false)
  assert.equal(worthSearching(50_001, RANGE), false)
  assert.equal(worthSearching(999, RANGE), false)
})

// The same principle as the freshness tier and IG's absent-vs-unverified:
// missing data is no proof it's useless.
test('worthSearching: without listener data nobody is penalised', () => {
  assert.equal(worthSearching(0, RANGE), true)
  assert.equal(worthSearching(null, RANGE), true)
  assert.equal(worthSearching(undefined, RANGE), true)
})

test("isBlockPage: Google's captcha page is recognised", () => {
  assert.equal(isBlockPage('https://www.google.com/sorry/index?continue=https://www.google.com/search%3Fq%3Dx'), true)
  assert.equal(isBlockPage('https://google.com/sorry/'), true)
})

test('isBlockPage: a normal results page is not', () => {
  assert.equal(isBlockPage('https://www.google.com/search?q=%22Yaeji%22+musician+instagram&num=5'), false)
  assert.equal(isBlockPage(''), false)
  assert.equal(isBlockPage(null), false)
})

// The block belongs to the SEARCH ENGINE, not the query: an artist URL with
// "/sorry/" in its name can't switch off the whole pool.
test('isBlockPage: it only counts if the block comes from google', () => {
  assert.equal(isBlockPage('https://www.instagram.com/sorry/'), false)
  assert.equal(isBlockPage('https://example.com/sorry/index'), false)
})

test('searchPages: a modest machine opens fewer tabs than a big one', () => {
  assert.equal(searchPages(2), 2)
  assert.equal(searchPages(4), 2)
  assert.equal(searchPages(8), 4)
  assert.equal(searchPages(16), 7)
})

// Every tab is a Chromium renderer process: not just one (there'd be no
// parallelism) nor as many as cores (measured: seven ate 89% of the CPU).
test('searchPages: never below 2 or above 7, whatever happens', () => {
  assert.equal(searchPages(1), 2)
  assert.equal(searchPages(0), 2)
  assert.equal(searchPages(64), 7)
  assert.equal(searchPages(undefined), 2)
})

test('the gate starts open', () => {
  const gate = createGoogleGate({ now: () => 1000 })
  assert.equal(gate.blocked(), false)
})

test('seeing the captcha closes the gate', () => {
  let t = 1000
  const gate = createGoogleGate({ now: () => t, cooldownMs: 500 })
  gate.block()
  assert.equal(gate.blocked(), true)
})

test('the gate reopens on its own after the cooldown', () => {
  let t = 1000
  const gate = createGoogleGate({ now: () => t, cooldownMs: 500 })
  gate.block()
  t = 1499
  assert.equal(gate.blocked(), true, 'a millisecond before it is still closed')
  t = 1500
  assert.equal(gate.blocked(), false, 'once the time is up it tries again')
})

// Without this a whole crawl logs one warning per search: hundreds of them, and
// the log stops being useful to see what happened.
test('closing is only announced the first time, not once per search', () => {
  let t = 1000
  const gate = createGoogleGate({ now: () => t, cooldownMs: 500 })
  assert.equal(gate.block(), true, 'the first one announces it')
  assert.equal(gate.block(), false, 'the next ones are not')
  assert.equal(gate.block(), false)
})

test('once the gate reopens, a new block is announced again', () => {
  let t = 1000
  const gate = createGoogleGate({ now: () => t, cooldownMs: 500 })
  gate.block()
  t = 2000
  assert.equal(gate.blocked(), false)
  assert.equal(gate.block(), true, 'it is a new episode and deserves its log line')
})

test('the default cooldown is measured in minutes, not seconds', () => {
  assert.ok(BLOCK_COOLDOWN_MS >= 10 * 60 * 1000)
})
