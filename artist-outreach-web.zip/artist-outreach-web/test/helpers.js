// Boots the whole app (Express + in-memory PGlite) on a free port and gives an
// HTTP client with cookies. No real Google, Stripe or Spotify.

const net = require('net')
const { createApp } = require('../server/index')
const { loadConfig } = require('../server/config')
const { createDb } = require('../server/db')

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer()
    s.listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)) })
    s.on('error', reject)
  })
}

async function startApp(env = {}, opts = {}) {
  const port = await freePort()
  const config = loadConfig({
    DEV_LOGIN: '1',
    PORT: String(port),
    PUBLIC_URL: `http://127.0.0.1:${port}`,
    SPOTIFY_BOOTSTRAP_ON_START: '0',
    ...env,
  })
  const db = await createDb({ memory: true })
  const quiet = () => {}
  const { app, engine } = await createApp({ config, db, log: opts.log || quiet, ...opts })
  const server = await new Promise(r => { const s = app.listen(port, '127.0.0.1', () => r(s)) })
  const base = `http://127.0.0.1:${port}`
  return {
    base, config, db, engine, server,
    async close() { server.closeAllConnections?.(); await new Promise(r => server.close(r)); await db.close() },
    client: () => makeClient(base),
  }
}

function makeClient(base) {
  const jar = new Map()
  const store = res => {
    const set = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : []
    for (const c of set) {
      const [pair] = c.split(';')
      const i = pair.indexOf('=')
      const k = pair.slice(0, i), v = pair.slice(i + 1)
      if (/Max-Age=0/i.test(c) || v === '') jar.delete(k)
      else jar.set(k, v)
    }
  }
  const cookie = () => [...jar].map(([k, v]) => `${k}=${v}`).join('; ')
  const req = async (method, path, { body, headers = {}, redirect = 'manual' } = {}) => {
    const res = await fetch(base + path, {
      method,
      redirect,
      headers: {
        ...(jar.size ? { cookie: cookie() } : {}),
        ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
        ...(method !== 'GET' ? { origin: base } : {}),
        ...headers,
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
    store(res)
    return res
  }
  return {
    jar,
    get: (p, o) => req('GET', p, o),
    post: (p, body, o = {}) => req('POST', p, { ...o, body }),
    patch: (p, body, o = {}) => req('PATCH', p, { ...o, body }),
    del: (p, o) => req('DELETE', p, o),
    json: async (method, p, body) => (await req(method, p, { body })).json(),
    async login(email) {
      const r = await req('GET', `/auth/dev?email=${encodeURIComponent(email)}`)
      if (r.status !== 302) throw new Error('dev login failed ' + r.status)
      return this
    },
  }
}

module.exports = { startApp, freePort }
