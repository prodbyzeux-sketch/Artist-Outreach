const { test } = require('node:test')
const assert = require('node:assert/strict')
const { isRateLimited, createIgGate, IG_COOLDOWN_MS } = require('../server/lib/igGate')

test('isRateLimited: 429 is the answer to the limit', () => {
  assert.equal(isRateLimited(429), true)
})

// Instagram also cuts off sessionless traffic that looks automated with
// 401/403; only 429 was measured, the other two are in out of caution.
test('isRateLimited: the sessionless cut-off also counts', () => {
  assert.equal(isRateLimited(401), true)
  assert.equal(isRateLimited(403), true)
})

// 404 means "that user doesn't exist" and has its own path (search again on
// Google). Closing the gate on it would leave the crawl without verification
// because of a handle mistyped on Spotify.
test('isRateLimited: a non-existent user is not a limit', () => {
  assert.equal(isRateLimited(404), false)
  assert.equal(isRateLimited(200), false)
  assert.equal(isRateLimited(500), false)
  assert.equal(isRateLimited(undefined), false)
})

test('the gate starts open', () => {
  const gate = createIgGate({ now: () => 1000 })
  assert.equal(gate.blocked(), false)
})

test('seeing the limit closes the gate', () => {
  const gate = createIgGate({ now: () => 1000, cooldownMs: 500 })
  gate.block()
  assert.equal(gate.blocked(), true)
})

test('the gate reopens on its own after the cooldown', () => {
  let t = 1000
  const gate = createIgGate({ now: () => t, cooldownMs: 500 })
  gate.block()
  t = 1499
  assert.equal(gate.blocked(), true, 'a millisecond before it is still closed')
  t = 1500
  assert.equal(gate.blocked(), false, 'once the time is up it is tried again')
})

// A crawl fires hundreds of verifications: without this the log fills with one
// line per artist and stops being useful to see what happened.
test('closing is only announced the first time in each episode', () => {
  let t = 1000
  const gate = createIgGate({ now: () => t, cooldownMs: 500 })
  assert.equal(gate.block(), true, 'the first one announces it')
  assert.equal(gate.block(), false, 'the next ones are not')
  t = 2000
  assert.equal(gate.blocked(), false)
  assert.equal(gate.block(), true, 'new episode, new line')
})

// Measured on 2026-08-13 after a real crawl: the 429 was still there at 0, 30
// and 60 seconds. A cooldown of seconds would waste requests again for nothing.
test('the default cooldown is measured in minutes, not seconds', () => {
  assert.ok(IG_COOLDOWN_MS >= 2 * 60 * 1000)
})
