const { test } = require('node:test')
const assert = require('node:assert/strict')
const { igUsername } = require('../server/lib/igProfile')

test('the handle comes out of the Spotify link', () => {
  assert.equal(igUsername('https://instagram.com/varg2tm'), 'varg2tm')
  assert.equal(igUsername('https://www.instagram.com/varg2tm/'), 'varg2tm')
  assert.equal(igUsername('https://www.instagram.com/Varg2TM/?hl=es'), 'varg2tm')
  assert.equal(igUsername('@varg2tm'), 'varg2tm')
})

test("Instagram's real alphabet includes dots and underscores", () => {
  assert.equal(igUsername('https://instagram.com/maul.prod'), 'maul.prod')
  assert.equal(igUsername('https://instagram.com/_1ruka'), '_1ruka')
})

test('URL parameters are not part of the handle', () => {
  assert.equal(igUsername('https://instagram.com/alguien?next=https://otro.sitio'), 'alguien')
})

// The link is set by Spotify, i.e. it comes from outside: whatever isn't a
// profile can't end up inside a URL this program builds. A single path segment
// = a profile; two segments is already a post, a reel or plain junk.
test('what is not a profile does not pass', () => {
  assert.equal(igUsername('https://instagram.com/con espacio'), null)
  assert.equal(igUsername('https://instagram.com/x/../../etc/passwd'), null)
  assert.equal(igUsername('https://instagram.com/p/CxYz123/'), null)
  assert.equal(igUsername('https://instagram.com/' + 'a'.repeat(31)), null)
})

test('no link, no handle', () => {
  assert.equal(igUsername(''), null)
  assert.equal(igUsername(null), null)
  assert.equal(igUsername(undefined), null)
  assert.equal(igUsername('https://instagram.com/'), null)
})
