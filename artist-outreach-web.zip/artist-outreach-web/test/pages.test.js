// The pages around the app (sign-in, billing, legal) and the extension download.

const test = require('node:test')
const assert = require('node:assert/strict')
const zlib = require('zlib')
const { startApp } = require('./helpers')
const extensionPack = require('../server/extensionPack')

// A small zip reader: enough to list a zip's files and read some of them.
function readZip(buf) {
  let eocd = -1
  for (let i = buf.length - 22; i >= 0; i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break }
  assert.ok(eocd >= 0, 'end of central directory found')
  const count = buf.readUInt16LE(eocd + 10)
  let p = buf.readUInt32LE(eocd + 16)
  const files = new Map()
  for (let n = 0; n < count; n++) {
    assert.equal(buf.readUInt32LE(p), 0x02014b50, 'central directory entry')
    const method = buf.readUInt16LE(p + 10)
    const crc = buf.readUInt32LE(p + 16)
    const size = buf.readUInt32LE(p + 20)
    const nameLen = buf.readUInt16LE(p + 28)
    const extraLen = buf.readUInt16LE(p + 30)
    const commentLen = buf.readUInt16LE(p + 32)
    const local = buf.readUInt32LE(p + 42)
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen)
    const localNameLen = buf.readUInt16LE(local + 26)
    const localExtraLen = buf.readUInt16LE(local + 28)
    const start = local + 30 + localNameLen + localExtraLen
    const raw = buf.subarray(start, start + size)
    files.set(name, () => {
      const data = method === 8 ? zlib.inflateRawSync(raw) : raw
      assert.equal(extensionPack.crc32(data), crc, `crc of ${name}`)
      return data
    })
    p += 46 + nameLen + extraLen + commentLen
  }
  return files
}

test('sign-in, billing and legal pages are in English', async () => {
  const app = await startApp({ LEGAL_COMPANY_NAME: 'Acme Music SL', LEGAL_CONTACT_EMAIL: 'hello@acme.test', LEGAL_ADDRESS: 'Calle Mayor 1, Madrid' })
  try {
    const login = await (await fetch(app.base + '/login')).text()
    assert.match(login, /Continue with Google/)
    assert.match(login, /href="\/terms"/)
    assert.match(login, /href="\/privacy"/)
    assert.doesNotMatch(login, /Continuar|Entrar|Cerrar/)

    const terms = await (await fetch(app.base + '/terms')).text()
    assert.match(terms, /Terms of Service/)
    assert.match(terms, /Acme Music SL/)
    assert.match(terms, /12-month minimum commitment/)
    assert.match(terms, /€67\.20 per year/)
    assert.match(terms, /€163\.20 per year/)
    assert.doesNotMatch(terms, /\{\{/)

    const privacy = await (await fetch(app.base + '/privacy')).text()
    assert.match(privacy, /Privacy Policy/)
    assert.match(privacy, /hello@acme\.test/)
    assert.doesNotMatch(privacy, /\{\{/)

    // /billing needs a session; the page itself is static English.
    const anon = await app.client().get('/billing')
    assert.equal(anon.status, 302)
    const c = await app.client().login('edu@x.com')
    const billing = await (await c.get('/billing')).text()
    assert.match(billing, /Plan &amp; billing/)
    assert.match(billing, /Choose your plan/)
    assert.doesNotMatch(billing, /Suscrib|Gestionar|Cancelad/)
  } finally { await app.close() }
})

test('the extension download is a zip patched for this server', async () => {
  const app = await startApp()
  try {
    const anon = await app.client().get(app.config.extension.downloadUrl)
    assert.equal(anon.status, 302, 'only for signed-in users')

    const c = await app.client().login('edu@x.com')
    const me = await (await c.get('/api/me')).json()
    assert.equal(me.extension.downloadUrl, '/downloads/artist-outreach-extension.zip')
    assert.equal(me.extension.storeUrl, null)

    const res = await c.get(app.config.extension.downloadUrl)
    assert.equal(res.status, 200)
    assert.equal(res.headers.get('content-type'), 'application/zip')
    assert.match(res.headers.get('content-disposition'), /artist-outreach-extension-\d+\.\d+\.\d+\.zip/)
    const files = readZip(Buffer.from(await res.arrayBuffer()))
    const names = [...files.keys()]

    // One top folder, which is what "Load unpacked" wants.
    assert.ok(names.every(n => n.startsWith('artist-outreach-extension/')))
    const file = n => files.get('artist-outreach-extension/' + n)
    for (const need of ['manifest.json', 'platform/config.js', 'platform/bridge.js', 'outreach/src/app.html', 'crm/page/crm.html', 'sw.js']) {
      assert.ok(file(need), `${need} is in the zip`)
    }
    // No tests, docs, dev tools or the local daemon.
    assert.ok(!names.some(n => /\/test\/|\.md$|package\.json$|crm\/bridge\/|set-origin\.mjs$/.test(n)), names.filter(n => /test|\.md$/.test(n)).join(','))

    const manifest = JSON.parse(file('manifest.json')().toString('utf8'))
    assert.equal(manifest.name, 'Artist Outreach')
    const bridge = manifest.content_scripts.find(cs => cs.js.includes('platform/bridge.js'))
    assert.deepEqual(bridge.matches, [`${app.base}/*`])
    assert.ok(manifest.host_permissions.includes(`${app.base}/*`))
    const war = manifest.web_accessible_resources.find(w => w.resources.includes('outreach/src/app.html'))
    assert.deepEqual(war.matches, [`${app.base}/*`], 'only this origin may embed Outreach and Inbox')

    const config = file('platform/config.js')().toString('utf8')
    assert.match(config, new RegExp(`PLATFORM_ORIGINS = \\[\\s*"${app.base.replace(/[.]/g, '\\.')}",\\s*\\]`))
  } finally { await app.close() }
})

test('a production origin replaces the development ones in the download', () => {
  const { zip } = extensionPack.packExtension('https://app.artistoutreach.example')
  const files = readZip(zip)
  const manifest = JSON.parse(files.get('artist-outreach-extension/manifest.json')().toString('utf8'))
  const bridge = manifest.content_scripts.find(cs => cs.js.includes('platform/bridge.js'))
  assert.deepEqual(bridge.matches, ['https://app.artistoutreach.example/*'])
  assert.ok(!manifest.host_permissions.some(p => p.startsWith('http://localhost:3456')), 'no localhost in a production download')
  const config = files.get('artist-outreach-extension/platform/config.js')().toString('utf8')
  assert.match(config, /"https:\/\/app\.artistoutreach\.example"/)
  assert.doesNotMatch(config, /localhost:3456/)
})
