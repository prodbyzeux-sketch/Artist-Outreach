const { test } = require('node:test')
const assert = require('node:assert')
const { packArtist, unpackArtist, mergePool, POOL_MAX } = require('../server/lib/poolStore')

const art = (over = {}) => ({
  id: '3TVXtAsR1Inumwj472S9r4', name: 'Drake', image: 'https://i.scdn.co/image/abc123',
  banner: 'https://i.scdn.co/image/hdr999', url: 'https://open.spotify.com/artist/3TVXtAsR1Inumwj472S9r4',
  followers: 5000, monthlyListeners: 5000, instagram: 'https://instagram.com/drake',
  igFollowers: 1200, source: 'spotify', genres: [],
  latestRelease: { year: 2026, month: 6, name: 'Some EP' }, ...over
})

// ─── pack / unpack ────────────────────────────────────────────────────────────

test('unpack(pack(x)) keeps every field the cards render', () => {
  const back = unpackArtist(packArtist(art()))
  const a = art()
  for (const k of ['id', 'name', 'image', 'banner', 'followers', 'monthlyListeners',
                   'instagram', 'igFollowers', 'url']) {
    assert.deepStrictEqual(back[k], a[k], `field ${k} lost`)
  }
  assert.deepStrictEqual(back.latestRelease, a.latestRelease)
})

test('pack drops what can be derived instead of storing it', () => {
  const packed = packArtist(art())
  assert.ok(!('url' in packed), 'the Spotify url is a template over the id')
  assert.strictEqual(unpackArtist(packed).url, art().url)
})

test('pack survives the sparse artists the crawl really produces', () => {
  const bare = { id: 'x1', name: 'Nobody' }
  const back = unpackArtist(packArtist(bare))
  assert.strictEqual(back.id, 'x1')
  assert.strictEqual(back.name, 'Nobody')
  assert.strictEqual(back.instagram, null)
  assert.strictEqual(back.latestRelease, null)
  assert.strictEqual(back.igFollowers, null)
})

test('pack keeps a pending IG artist distinguishable from a verified zero', () => {
  // null = never checked (client re-verifies), 0 = checked and really zero.
  assert.strictEqual(unpackArtist(packArtist(art({ igFollowers: null }))).igFollowers, null)
  assert.strictEqual(unpackArtist(packArtist(art({ igFollowers: 0 }))).igFollowers, 0)
})

// ─── audience cities ──────────────────────────────────────────────────────────

test('pack round-trips the top city and every audience country', () => {
  const back = unpackArtist(packArtist(art({
    topCity: { city: 'Lagos', country: 'NG' }, countries: ['NG', 'US', 'CA']
  })))
  assert.deepStrictEqual(back.topCity, { city: 'Lagos', country: 'NG' })
  assert.deepStrictEqual(back.countries, ['NG', 'US', 'CA'])
})

test('pools written before cities existed still open', () => {
  // No migration: an old file simply has no c/k keys.
  const back = unpackArtist({ i: 'x1', n: 'Old Pool Artist', l: 900 })
  assert.strictEqual(back.topCity, null)
  assert.deepStrictEqual(back.countries, [])
})

test('a city name containing the separator survives the round trip', () => {
  const back = unpackArtist(packArtist(art({
    topCity: { city: 'Pipe|Town', country: 'US' }, countries: ['US']
  })))
  assert.deepStrictEqual(back.topCity, { city: 'Pipe|Town', country: 'US' })
})

test('mergePool does not let a re-crawl without cities erase known ones', () => {
  const known = art({ id: 'a', topCity: { city: 'Lima', country: 'PE' }, countries: ['PE'] })
  const out = mergePool([known], [art({ id: 'a', topCity: null, countries: [] })])
  assert.deepStrictEqual(out[0].topCity, { city: 'Lima', country: 'PE' })
  assert.deepStrictEqual(out[0].countries, ['PE'])
})

// ─── mergePool ────────────────────────────────────────────────────────────────
// A re-collection ADDS to the pool; it must never duplicate nor lose what the
// previous run found — that is the whole point of storing results.

test('mergePool appends new artists and keeps the old ones', () => {
  const out = mergePool([art({ id: 'a' })], [art({ id: 'b' })])
  assert.deepStrictEqual(out.map(a => a.id), ['a', 'b'])
})

test('mergePool refreshes an existing artist instead of duplicating it', () => {
  const out = mergePool([art({ id: 'a', igFollowers: null })], [art({ id: 'a', igFollowers: 999 })])
  assert.strictEqual(out.length, 1)
  assert.strictEqual(out[0].igFollowers, 999)
})

test('mergePool does not let a later empty value erase a known one', () => {
  // The re-crawl streams the same artist before IG verification: keeping the
  // fresher null would blank a number the user already saw.
  const out = mergePool([art({ id: 'a', igFollowers: 999 })], [art({ id: 'a', igFollowers: null })])
  assert.strictEqual(out[0].igFollowers, 999)
})

test('mergePool caps the pool at POOL_MAX, dropping the oldest', () => {
  const old = Array.from({ length: POOL_MAX }, (_, i) => art({ id: 'old' + i }))
  const out = mergePool(old, [art({ id: 'fresh' })])
  assert.strictEqual(out.length, POOL_MAX)
  assert.strictEqual(out.at(-1).id, 'fresh')
  assert.strictEqual(out.find(a => a.id === 'old0'), undefined, 'oldest goes first')
})

test('mergePool ignores entries without an id', () => {
  const out = mergePool([], [art({ id: 'a' }), { name: 'no id' }, null])
  assert.deepStrictEqual(out.map(a => a.id), ['a'])
})
