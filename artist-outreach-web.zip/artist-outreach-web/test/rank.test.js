const { test } = require('node:test')
const assert = require('node:assert')
const { rankPool } = require('../server/lib/rank')
const { NEG_GATE, AFFINITY_FLOOR } = require('../server/lib/affinity')

const A = (id, tier, listeners = 1000) => ({ id, _tier: tier, monthlyListeners: listeners })
const score = pairs => new Map(pairs)

// ─── no signal: the freshness tier rules ─────────────────────────────────────

test('rankPool without signal orders by tier and gates nothing', () => {
  const pool = [A('dorm', 2), A('hot', 0), A('mid', 1)]
  // residue below the floor — mathematically present, semantically nothing
  const s = score([['dorm', -5e-5], ['hot', 2e-5]])
  const { ranked, gated } = rankPool(pool, s)
  assert.deepStrictEqual(ranked.map(a => a.id), ['hot', 'mid', 'dorm'])
  assert.strictEqual(gated.length, 0, 'residue must never gate anyone')
})

test('rankPool without any score map keeps tier order', () => {
  const { ranked } = rankPool([A('b', 1), A('a', 0)], null)
  assert.deepStrictEqual(ranked.map(a => a.id), ['a', 'b'])
})

// ─── with signal: taste beats the tier ───────────────────────────────────────

test('rankPool lets taste beat the tier when the difference is real', () => {
  const pool = [A('hot-meh', 0), A('mid-loved', 1)]
  const s = score([['mid-loved', 2e-2], ['hot-meh', 1e-4]])
  const { ranked } = rankPool(pool, s)
  assert.strictEqual(ranked[0].id, 'mid-loved',
    'a strong sound match must outrank mere release freshness')
})

test('rankPool falls back to tier inside the tie band', () => {
  const pool = [A('mid-close', 1), A('hot-close', 0)]
  // both within 5% of the maximum → a taste tie, the tier decides
  const s = score([['mid-close', 1.00e-2], ['hot-close', 0.98e-2]])
  const { ranked } = rankPool(pool, s)
  assert.strictEqual(ranked[0].id, 'hot-close')
})

test('rankPool big-listeners fallback only breaks full ties when asked', () => {
  const pool = [A('small', 1, 100), A('big', 1, 900000)]
  assert.strictEqual(rankPool(pool, null, true).ranked[0].id, 'big')
  assert.strictEqual(rankPool(pool, null, false).ranked[0].id, 'small', 'without the flag the arrival order is kept')
})

// ─── the scissors: what was learnt as bad isn't shown ────────────────────────

test('rankPool gates the inner ring of an explicit dislike', () => {
  const pool = [A('fine', 1), A('dislike-ring', 1)]
  const s = score([['fine', 2e-2], ['dislike-ring', NEG_GATE * 2]])
  const { ranked, gated } = rankPool(pool, s)
  assert.deepStrictEqual(gated.map(a => a.id), ['dislike-ring'])
  assert.deepStrictEqual(ranked.map(a => a.id), ['fine'])
})

test('rankPool does NOT gate a skip-scale ripple', () => {
  // Calibration: a skip weighs -0.15 and its wave one hop away is around -4e-3;
  // the scissors only cut the inner ring of an explicit not-similar (-1).
  const pool = [A('fine', 1), A('skipped-near', 1)]
  const s = score([['fine', 2e-2], ['skipped-near', -4e-3]])
  const { ranked, gated } = rankPool(pool, s)
  assert.strictEqual(gated.length, 0)
  assert.strictEqual(ranked.length, 2)
  assert.strictEqual(ranked.at(-1).id, 'skipped-near', 'ordenado al fondo, no cortado')
})

test('rankPool never gates when everything is sub-floor noise', () => {
  // With nothing above the floor the scale is noise: cutting by noise would be
  // the same mistake as sorting by it.
  const pool = [A('x', 1), A('y', 1)]
  const s = score([['x', 6e-5], ['y', -8e-5]])
  assert.strictEqual(rankPool(pool, s).gated.length, 0)
})

test('rankPool gates in a pool reached ONLY by negative signal', () => {
  // "Everything here is stuck to what you rejected" is a full-fledged signal:
  // the inner ring is cut even if no positive reaches it.
  const pool = [A('ring', 1), A('far', 1)]
  const s = score([['ring', NEG_GATE * 2], ['far', -2e-5]])
  const { ranked, gated } = rankPool(pool, s)
  assert.deepStrictEqual(gated.map(a => a.id), ['ring'])
  assert.deepStrictEqual(ranked.map(a => a.id), ['far'])
})

// sanity check of the constants that calibrate the scissors
test('gate sits between a skip ripple and a dislike inner ring', () => {
  assert.ok(NEG_GATE < -4e-3, 'skip ripple must survive')
  assert.ok(NEG_GATE > -0.1, 'dislike inner ring must not')
  assert.ok(Math.abs(NEG_GATE) > AFFINITY_FLOOR)
})
