const { test } = require('node:test')
const assert = require('node:assert')
const { releaseTier, latestReleaseOf, TIER_HOT, TIER_MID, TIER_DORMANT } = require('../server/lib/recency')

// The owner's outreach logic: an artist 1-3 months after a release is starting
// the next cycle and worth contacting FIRST; just-dropped (this month) and
// 4-12 months sit in the middle, unordered; over a year silent = likely
// dormant, contact last. Spotify gives release dates at month precision.

const now = new Date(2026, 7, 3)   // 2026-08-03, month is 0-based
const rel = (year, month) => ({ year, month, name: 'x' })

test('releaseTier: 1-3 months since release is the hot tier', () => {
  assert.strictEqual(releaseTier(rel(2026, 7), now), TIER_HOT)   // 1 month ago
  assert.strictEqual(releaseTier(rel(2026, 6), now), TIER_HOT)
  assert.strictEqual(releaseTier(rel(2026, 5), now), TIER_HOT)   // 3 months ago
})

test('releaseTier: released this month is mid, not hot', () => {
  assert.strictEqual(releaseTier(rel(2026, 8), now), TIER_MID)
})

test('releaseTier: 4-12 months is mid', () => {
  assert.strictEqual(releaseTier(rel(2026, 4), now), TIER_MID)    // 4 months
  assert.strictEqual(releaseTier(rel(2025, 8), now), TIER_MID)    // exactly 12
})

test('releaseTier: over a year silent is the dormant tier', () => {
  assert.strictEqual(releaseTier(rel(2025, 7), now), TIER_DORMANT)   // 13 months
  assert.strictEqual(releaseTier(rel(2020, 1), now), TIER_DORMANT)
})

test('releaseTier: missing data is mid — absence of data is not evidence of dormancy', () => {
  assert.strictEqual(releaseTier(null, now), TIER_MID)
  assert.strictEqual(releaseTier({}, now), TIER_MID)
  assert.strictEqual(releaseTier(rel(null, null), now), TIER_MID)
})

test('releaseTier: year-only dates get the benefit of the doubt', () => {
  // Month unknown → assume December: only clearly-old years go dormant.
  assert.strictEqual(releaseTier(rel(2025, null), now), TIER_MID)      // Dec 2025 → 8 months
  assert.strictEqual(releaseTier(rel(2024, null), now), TIER_DORMANT)  // Dec 2024 → 20 months
})

test('releaseTier: garbage future dates fall to mid, never crash', () => {
  assert.strictEqual(releaseTier(rel(2030, 1), now), TIER_MID)
})

test('tiers are ordered for direct use as sort keys', () => {
  assert.ok(TIER_HOT < TIER_MID && TIER_MID < TIER_DORMANT)
})

// latestReleaseOf — shapes taken from live queryArtistOverview payloads.
// singles/albums/compilations wrap each entry in releases.items; latest and
// popularReleasesAlbums carry the album object directly.
const album = (year, month, name) => ({ name, date: { year, month, day: 1, precision: 'DAY' } })
const wrapped = (...albums) => ({ items: albums.map(a => ({ releases: { items: [a] } })) })

test('latestReleaseOf: takes discography.latest when Spotify serves it', () => {
  const disco = { latest: album(2026, 7, 'too many times'), singles: wrapped(album(2026, 7, 'too many times'), album(2025, 1, 'old')) }
  assert.deepStrictEqual(latestReleaseOf(disco), { year: 2026, month: 7, name: 'too many times' })
})

// The bug this exists for: measured on live payloads, latest comes back null
// for every artist whose newest release is not recent — 61% of a crawl.
test('latestReleaseOf: falls back to the release lists when latest is null', () => {
  const disco = { latest: null, singles: wrapped(album(2025, 10, 'Get your money'), album(2025, 6, 'older')) }
  assert.deepStrictEqual(latestReleaseOf(disco), { year: 2025, month: 10, name: 'Get your money' })
})

test('latestReleaseOf: newest wins across sections, whatever their order', () => {
  const disco = {
    latest: null,
    singles: wrapped(album(2024, 9, 'single')),
    albums: wrapped(album(2024, 11, 'last laugh')),
    compilations: wrapped(album(2019, 3, 'comp')),
    popularReleasesAlbums: { items: [album(2022, 2, 'popular one')] }
  }
  assert.deepStrictEqual(latestReleaseOf(disco), { year: 2024, month: 11, name: 'last laugh' })
})

test('latestReleaseOf: same year → later month wins', () => {
  const disco = { latest: null, singles: wrapped(album(2025, 1, 'jan'), album(2025, 5, 'may')) }
  assert.strictEqual(latestReleaseOf(disco).month, 5)
})

test('latestReleaseOf: year-only dates keep the year and null the month', () => {
  const disco = { latest: null, albums: wrapped({ name: 'anthology', date: { year: 2023, precision: 'YEAR' } }) }
  assert.deepStrictEqual(latestReleaseOf(disco), { year: 2023, month: null, name: 'anthology' })
})

test('latestReleaseOf: entries without a year are ignored, never crash', () => {
  const disco = { latest: null, singles: wrapped({ name: 'dateless' }, album(2022, 4, 'real')) }
  assert.deepStrictEqual(latestReleaseOf(disco), { year: 2022, month: 4, name: 'real' })
})

test('latestReleaseOf: nothing releasable → null, so the tier stays mid', () => {
  assert.strictEqual(latestReleaseOf(null), null)
  assert.strictEqual(latestReleaseOf({}), null)
  assert.strictEqual(latestReleaseOf({ latest: null, singles: { items: [] } }), null)
  assert.strictEqual(latestReleaseOf({ singles: wrapped({ name: 'dateless' }) }), null)
})
