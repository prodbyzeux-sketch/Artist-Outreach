const { test } = require('node:test')
const assert = require('node:assert')
const { orderSeeds } = require('../server/lib/seeds')
const { AFFINITY_FLOOR } = require('../server/lib/affinity')

// Hard rule (v2.0.3 bug): this ORDERS, it never discards. The expansion pool
// always holds every node; filtering here starves the BFS of seeds and the
// search returns zero.

const rng = () => 0.5   // deterministic: always the middle of the bucket
const opts = (o = {}) => ({ listFilterActive: false, listMin: 0, listMax: 5e6, rng, ...o })
const A = (id, ml) => ({ id, monthlyListeners: ml })

test('orderSeeds mixed sampling reaches beyond the smallest artists', () => {
  const pool = Array.from({ length: 30 }, (_, i) => A('a' + i, i * 1000))
  const seeds = orderSeeds(pool, opts())
  assert.strictEqual(seeds.length, 4)
  // Legacy draws 3 small + 1 mid + 1 big and then caps at 4, so the big draw
  // is normally discarded. Reaching the mid bucket is the real contract: the
  // sampling must not collapse onto the four smallest artists.
  assert.ok(seeds.some(s => s.monthlyListeners >= 15000))
})

test('orderSeeds draws every seed from the range when the filter is on', () => {
  const pool = [
    A('big', 900000),
    A('in-1', 5000), A('in-2', 6000), A('in-3', 7000), A('in-4', 8000)
  ]
  const seeds = orderSeeds(pool, opts({ listFilterActive: true, listMin: 1000, listMax: 10000 }))
  assert.strictEqual(seeds.length, 4)
  assert.ok(seeds.every(s => s.monthlyListeners <= 10000))
})

test('orderSeeds never invents or drops candidates', () => {
  const pool = [A('a', 1), A('b', 2), A('c', 3)]
  const seeds = orderSeeds(pool, opts())
  assert.ok(seeds.length <= 4)
  seeds.forEach(s => assert.ok(pool.includes(s), 'seed must come from the pool'))
  assert.strictEqual(new Set(seeds.map(s => s.id)).size, seeds.length, 'no duplicates')
})

test('orderSeeds returns empty only for an empty pool', () => {
  assert.deepStrictEqual(orderSeeds([], opts()), [])
  assert.strictEqual(orderSeeds([A('only', 5)], opts()).length, 1)
})

// ─── compass slot ─────────────────────────────────────────────────────────────
// With votes in the global pool the walk should EXPLORE toward what the owner
// approves, not just rank it after the fact. One seed slot goes to the
// highest-affinity unexpanded artist; the walk stays an ordering — nothing is
// ever pruned, and without signal the behaviour is exactly the old one.

test('compass slot expands the top-affinity artist even outside the listener range', () => {
  const pool = [
    A('loved-hub', 900000),                                 // way above listMax
    ...Array.from({ length: 20 }, (_, i) => A('micro' + i, 100 + i))
  ]
  const score = new Map([['loved-hub', 0.02], ['micro3', 0.001]])
  const seeds = orderSeeds(pool, opts({ listFilterActive: true, listMin: 0, listMax: 50000, score }))
  assert.strictEqual(seeds[0].id, 'loved-hub', 'the range must not blind the compass — bridges matter')
  assert.strictEqual(seeds.length, 4)
  assert.ok(seeds.slice(1).every(s => s.monthlyListeners <= 50000), 'only ONE slot goes to the compass')
})

test('compass slot ignores scores at or below the floor', () => {
  const pool = [A('a', 100), A('b', 200), A('c', 300), A('d', 400)]
  const score = new Map([['d', AFFINITY_FLOOR]])   // residue, not signal
  const withScore = orderSeeds(pool, opts({ score }))
  const without = orderSeeds(pool, opts())
  assert.deepStrictEqual(withScore.map(s => s.id).sort(), without.map(s => s.id).sort())
})

test('compass slot never expands a disliked region', () => {
  const pool = [A('hated', 100), A('x', 200), A('y', 300)]
  const seeds = orderSeeds(pool, opts({ score: new Map([['hated', -0.5]]) }))
  assert.notStrictEqual(seeds[0].id, 'hated', 'a strong negative is not a reason to EXPAND there first')
})

test('compass pick is not duplicated by the other draws', () => {
  const pool = [A('best', 100), A('b', 200), A('c', 300)]
  const seeds = orderSeeds(pool, opts({ score: new Map([['best', 0.1]]) }))
  assert.strictEqual(new Set(seeds.map(s => s.id)).size, seeds.length)
})

test('orderSeeds does not starve when the filter matches nobody', () => {
  // Nobody inside the range: legacy falls through to mixed sampling instead
  // of returning nothing. If this returns [], the BFS dies and search is zero.
  const pool = [A('a', 9e6), A('b', 8e6), A('c', 7e6)]
  const seeds = orderSeeds(pool, opts({ listFilterActive: true, listMin: 10, listMax: 1000 }))
  assert.ok(seeds.length > 0, 'must fall back instead of starving the frontier')
})
