const test = require('node:test')
const assert = require('node:assert/strict')
const { createDb } = require('../server/db')
const { createUserStore } = require('../server/engine/userStore')

async function setup() {
  const db = await createDb({ memory: true })
  await db.query(`insert into users (id, email) values ('u1', 'a@x.com'), ('u2', 'b@x.com')`)
  return { db, store: createUserStore(db) }
}

const artist = (id, extra = {}) => ({
  id, name: 'Artist ' + id, url: `https://open.spotify.com/artist/${id}`, followers: 1000,
  image: 'img', instagram: `https://www.instagram.com/${id}_ig/`, ...extra,
})

test('save: new on top, existing updated in place (like the desktop)', async () => {
  const { store } = await setup()
  await store.saveArtist('u1', artist('a'))
  await store.saveArtist('u1', artist('b'))
  await store.saveArtist('u1', { ...artist('a'), name: 'A renamed' })
  const list = await store.listArtists('u1')
  assert.deepEqual(list.map(r => r.id), ['b', 'a'])
  assert.equal(list[1].name, 'A renamed')
  assert.equal(list[1].instagram_handle, '@a_ig')
  assert.equal(list[1].status, 'saved')
})

test('each user only sees their own', async () => {
  const { store } = await setup()
  await store.saveArtist('u1', artist('a'))
  await store.saveArtist('u2', artist('z'))
  assert.deepEqual((await store.listArtists('u1')).map(r => r.id), ['a'])
  assert.deepEqual((await store.listArtists('u2')).map(r => r.id), ['z'])
  assert.equal(await store.bulkDelete('u2', ['a']), 0)
  assert.equal((await store.listArtists('u1')).length, 1)
})

test('bulk: repeated ids in the batch do not break the upsert', async () => {
  const { store } = await setup()
  const r = await store.bulkSave('u1', [artist('a'), artist('b'), { ...artist('a'), name: 'dup' }], 'Ref')
  assert.deepEqual(r, { added: 2, updated: 0 })
  const list = await store.listArtists('u1')
  assert.equal(list.find(x => x.id === 'a').name, 'dup')
  assert.equal(list[0].reference_artist, 'Ref')
  const r2 = await store.bulkSave('u1', [artist('a'), artist('c')], 'Ref')
  assert.deepEqual(r2, { added: 1, updated: 1 })
})

test('bulk-status: contacted sets the date; undo restores the original (null)', async () => {
  const { store } = await setup()
  await store.bulkSave('u1', [artist('a'), artist('b')])
  assert.equal(await store.bulkStatus('u1', ['a', 'b'], 'contacted'), 2)
  let a = await store.getArtist('u1', 'a')
  assert.equal(a.status, 'contacted')
  assert.ok(a.contacted_at)
  await store.bulkStatus('u1', ['a'], 'saved', null)
  a = await store.getArtist('u1', 'a')
  assert.equal(a.status, 'saved')
  assert.equal(a.contacted_at, null)
  assert.equal((await store.listArtists('u1', { status: 'contacted' })).length, 1)
})

test('patch only lets allow-listed fields be touched', async () => {
  const { store } = await setup()
  await store.saveArtist('u1', artist('a'))
  await store.patchArtist('u1', 'a', { notes: 'hola', name: 'hack', status: 'contacted' })
  const a = await store.getArtist('u1', 'a')
  assert.equal(a.notes, 'hola')
  assert.equal(a.status, 'contacted')
  assert.equal(a.name, 'Artist a')
})

test('folders: move, unknown folder, deleting leaves them unfiled', async () => {
  const { store } = await setup()
  await store.bulkSave('u1', [artist('a'), artist('b')])
  const f = await store.createFolder('u1', 'Trap')
  assert.equal(await store.moveArtists('u1', ['a'], f.id), 1)
  assert.equal((await store.getArtist('u1', 'a')).folder_id, f.id)
  await assert.rejects(() => store.moveArtists('u1', ['a'], 'nope'), /unknown folder/)
  // another user's folder doesn't work either
  const other = await store.createFolder('u2', 'X')
  await assert.rejects(() => store.moveArtists('u1', ['a'], other.id), /unknown folder/)
  await store.deleteFolder('u1', f.id)
  assert.equal((await store.getArtist('u1', 'a')).folder_id, null)
  assert.deepEqual(await store.listFolders('u1'), [])
})

test('seen: add, forget, reset', async () => {
  const { store } = await setup()
  assert.deepEqual(await store.addSeen('u1', ['a', 'b', 'a', '']), { added: 2, total: 2 })
  assert.deepEqual(await store.addSeen('u1', ['b', 'c']), { added: 1, total: 3 })
  assert.equal(await store.forgetSeen('u1', ['a']), 2)
  assert.deepEqual((await store.seenIds('u1')).sort(), ['b', 'c'])
  assert.equal(await store.resetSeen('u1'), 2)
  assert.equal(await store.countSeen('u1'), 0)
})

test('stats counts "today" in the user\'s time zone', async () => {
  const { store } = await setup()
  await store.saveArtist('u1', artist('a'))
  await store.bulkStatus('u1', ['a'], 'contacted')
  const s = await store.stats('u1', new Date().getTimezoneOffset())
  assert.deepEqual(s, { saved: 1, contacted: 1 })
})

test('prospects for the extension: only with Instagram, by status/folder', async () => {
  const { store } = await setup()
  await store.bulkSave('u1', [artist('a'), artist('b'), artist('c', { instagram: null })])
  const f = await store.createFolder('u1', 'F')
  await store.moveArtists('u1', ['b'], f.id)
  await store.bulkStatus('u1', ['a'], 'contacted')
  assert.deepEqual((await store.prospectsForOutreach('u1', { status: 'pending' })).map(r => r.id), ['b'])
  assert.deepEqual((await store.prospectsForOutreach('u1', { status: 'contacted' })).map(r => r.id), ['a'])
  assert.deepEqual((await store.prospectsForOutreach('u1', { status: 'saved' })).map(r => r.id).sort(), ['a', 'b'])
  assert.deepEqual((await store.prospectsForOutreach('u1', { status: 'saved', folderId: 'none' })).map(r => r.id), ['a'])
  assert.deepEqual((await store.prospectsForOutreach('u1', { status: 'saved', folderId: f.id })).map(r => r.id), ['b'])
  assert.equal((await store.findByHandle('u1', 'b_ig')).id, 'b')
})

test('per-user config', async () => {
  const { store } = await setup()
  assert.deepEqual(await store.getConfig('u1'), {})
  await store.setConfig('u1', { spMin: 10 })
  assert.deepEqual(await store.getConfig('u1'), { spMin: 10 })
  assert.deepEqual(await store.getConfig('u2'), {})
})
